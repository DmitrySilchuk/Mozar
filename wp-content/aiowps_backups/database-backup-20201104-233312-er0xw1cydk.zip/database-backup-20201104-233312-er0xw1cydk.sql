-- All In One WP Security & Firewall 4.4.4
-- MySQL dump
-- 2020-11-04 20:33:12

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id` (`claim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_actionscheduler_actions` VALUES("6","action_scheduler/migration_hook","complete","2020-11-04 19:44:45","2020-11-04 19:44:45","[]","O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1604519085;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1604519085;}","1","1","2020-11-04 19:44:56","2020-11-04 22:44:56","0","");
INSERT INTO `wp_actionscheduler_actions` VALUES("7","action_scheduler/migration_hook","canceled","2020-11-04 19:44:45","2020-11-04 19:44:45","[]","O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1604519085;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1604519085;}","2","0","2020-11-04 19:44:55","2020-11-04 22:44:55","0","");


DROP TABLE IF EXISTS `wp_actionscheduler_claims`;

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_actionscheduler_groups`;

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_actionscheduler_groups` VALUES("1","action-scheduler-migration");
INSERT INTO `wp_actionscheduler_groups` VALUES("2","action-scheduler-migration");


DROP TABLE IF EXISTS `wp_actionscheduler_logs`;

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_actionscheduler_logs` VALUES("1","6","действие создано","2020-11-04 19:43:46","2020-11-04 19:43:46");
INSERT INTO `wp_actionscheduler_logs` VALUES("2","7","действие создано","2020-11-04 19:43:46","2020-11-04 19:43:46");
INSERT INTO `wp_actionscheduler_logs` VALUES("3","6","действие началось через Async Request","2020-11-04 19:44:56","2020-11-04 19:44:56");
INSERT INTO `wp_actionscheduler_logs` VALUES("4","7","действие отменено","2020-11-04 19:44:56","2020-11-04 19:44:56");
INSERT INTO `wp_actionscheduler_logs` VALUES("5","6","действие завершено через Async Request","2020-11-04 19:44:56","2020-11-04 19:44:56");
INSERT INTO `wp_actionscheduler_logs` VALUES("6","7","действие игнорируется через Async Request","2020-11-04 19:44:56","2020-11-04 19:44:56");


DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `logout_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_comments` VALUES("1","1","Автор комментария","wapuu@wordpress.example","https://wordpress.org/","","2020-11-04 22:09:18","2020-11-04 19:09:18","Привет! Это комментарий.
Чтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.
Аватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.","0","1","","comment","0","0");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=435 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://mozar.loc","yes");
INSERT INTO `wp_options` VALUES("2","home","http://mozar.loc","yes");
INSERT INTO `wp_options` VALUES("3","blogname","mozar","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","Ещё один сайт на WordPress","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","dimisiusis@gmail.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:6:{i:0;s:31:\"query-monitor/query-monitor.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:22:\"cyr3lat/cyr-to-lat.php\";i:3;s:21:\"imsanity/imsanity.php\";i:4;s:27:\"woocommerce/woocommerce.php\";i:5;s:24:\"wordpress-seo/wp-seo.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","3","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","","no");
INSERT INTO `wp_options` VALUES("40","template","twentytwenty","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","twentytwenty","yes");
INSERT INTO `wp_options` VALUES("42","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("43","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("44","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("45","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("46","db_version","48748","yes");
INSERT INTO `wp_options` VALUES("47","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("48","upload_path","","yes");
INSERT INTO `wp_options` VALUES("49","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("50","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("51","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("52","tag_base","","yes");
INSERT INTO `wp_options` VALUES("53","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("54","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("55","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("56","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("57","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("59","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("60","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("61","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("62","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("63","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("64","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("65","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("66","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("67","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("68","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("69","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("70","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("71","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("72","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("73","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("74","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("75","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("76","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("77","widget_text","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("78","widget_rss","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("79","uninstall_plugins","a:0:{}","no");
INSERT INTO `wp_options` VALUES("80","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("81","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("82","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("83","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("84","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("85","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("86","site_icon","0","yes");
INSERT INTO `wp_options` VALUES("87","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("88","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("89","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp_options` VALUES("90","show_comments_cookies_opt_in","1","yes");
INSERT INTO `wp_options` VALUES("91","admin_email_lifespan","1620068952","yes");
INSERT INTO `wp_options` VALUES("92","disallowed_keys","","no");
INSERT INTO `wp_options` VALUES("93","comment_previously_approved","1","yes");
INSERT INTO `wp_options` VALUES("94","auto_plugin_theme_update_emails","a:0:{}","no");
INSERT INTO `wp_options` VALUES("95","initial_db_version","48748","yes");
INSERT INTO `wp_options` VALUES("96","wp_user_roles","a:9:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:115:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:38:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;s:23:\"view_site_health_checks\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("97","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES("98","WPLANG","ru_RU","yes");
INSERT INTO `wp_options` VALUES("99","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("103","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("104","sidebars_widgets","a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("105","cron","a:19:{i:1604522046;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"0d04ed39571b55704c122d726248bbac\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:1:{i:0;s:7:\"WP Cron\";}s:8:\"interval\";i:60;}}}i:1604522610;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1604522620;a:1:{s:33:\"wc_admin_process_orders_milestone\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1604522631;a:1:{s:29:\"wc_admin_unsnooze_admin_notes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1604523600;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1604524161;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1604525226;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1604529810;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1604540610;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1604560161;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1604603360;a:2:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1604603376;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1604603378;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1604604426;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1604605420;a:2:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1604605424;a:1:{s:14:\"wc_admin_daily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1604606071;a:2:{s:13:\"wpseo-reindex\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:31:\"wpseo_permalink_structure_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1605815070;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:11:\"fifteendays\";s:4:\"args\";a:0:{}s:8:\"interval\";i:1296000;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("111","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("112","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("113","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("114","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("116","recovery_keys","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("118","theme_mods_twentytwenty","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"background_color\";s:3:\"fff\";}","yes");
INSERT INTO `wp_options` VALUES("127","_site_transient_timeout_browser_a92675e43a1d9b9035385d5a92823f70","1605121777","no");
INSERT INTO `wp_options` VALUES("128","_site_transient_browser_a92675e43a1d9b9035385d5a92823f70","a:10:{s:4:\"name\";s:5:\"Opera\";s:7:\"version\";s:13:\"72.0.3815.186\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:22:\"https://www.opera.com/\";s:7:\"img_src\";s:42:\"http://s.w.org/images/browsers/opera.png?1\";s:11:\"img_src_ssl\";s:43:\"https://s.w.org/images/browsers/opera.png?1\";s:15:\"current_version\";s:5:\"12.18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("129","_site_transient_timeout_php_check_a5b4d2808570efd012607394df5c6fa9","1605121778","no");
INSERT INTO `wp_options` VALUES("130","_site_transient_php_check_a5b4d2808570efd012607394df5c6fa9","a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wp_options` VALUES("132","_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e","1604560181","no");
INSERT INTO `wp_options` VALUES("133","_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e","a:4:{s:9:\"sandboxed\";b:0;s:5:\"error\";N;s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:2:{i:0;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:77:\"Discussion: Introduction to Contributing to the WordPress Open Source Project\";s:3:\"url\";s:68:\"https://www.meetup.com/learn-wordpress-discussions/events/274257974/\";s:6:\"meetup\";s:27:\"Learn WordPress Discussions\";s:10:\"meetup_url\";s:51:\"https://www.meetup.com/learn-wordpress-discussions/\";s:4:\"date\";s:19:\"2020-11-05 08:00:00\";s:8:\"end_date\";s:19:\"2020-11-05 09:00:00\";s:20:\"start_unix_timestamp\";i:1604592000;s:18:\"end_unix_timestamp\";i:1604595600;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"US\";s:8:\"latitude\";d:37.779998779297;s:9:\"longitude\";d:-122.41999816895;}}i:1;a:10:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:23:\"WordCamp Finland Online\";s:3:\"url\";s:34:\"https://finland.wordcamp.org/2020/\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2020-11-12 12:00:00\";s:8:\"end_date\";s:19:\"2020-11-12 12:00:00\";s:20:\"start_unix_timestamp\";i:1605175200;s:18:\"end_unix_timestamp\";i:1605175200;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"FI\";s:8:\"latitude\";d:61.92411;s:9:\"longitude\";d:25.7481511;}}}}","no");
INSERT INTO `wp_options` VALUES("134","can_compress_scripts","1","no");
INSERT INTO `wp_options` VALUES("135","_transient_timeout_feed_126d1ca39d75da07beec8b892738427b","1604560182","no");
INSERT INTO `wp_options` VALUES("136","_transient_feed_126d1ca39d75da07beec8b892738427b","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Блог | WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://ru.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Русский\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Oct 2020 07:46:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"ru-RU\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.6-beta3-49496\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Ежегодный опрос пользователей и разработчиков WordPress 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ru.wordpress.org/news/2020/10/2020-annual-survey/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Oct 2020 07:22:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2223\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:743:\"Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. В этом году мы также предлагаем пройти вам этот опрос как и в прошлом году, предлагаются и другие языки &#8212; французский, немецкий, испанский и японский. Сбор данных осуществляется в полном соответствии с политикой конфиденциальности WordPress.org: все данные будут анонимизированы и не будут ассоциироваться [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4609:\"
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img loading=\"lazy\" width=\"768\" height=\"342\" src=\"https://ru.wordpress.org/files/2019/11/image-12-1.png\" alt=\"\" class=\"wp-image-2145 size-full\" srcset=\"https://ru.wordpress.org/files/2019/11/image-12-1.png 768w, https://ru.wordpress.org/files/2019/11/image-12-1-300x134.png 300w\" sizes=\"(max-width: 768px) 100vw, 768px\" /></figure><div class=\"wp-block-media-text__content\">
<p style=\"font-size:18px\">Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. </p>
</div></div>



<p>В этом году мы также предлагаем пройти вам этот опрос</p>



<div class=\"wp-block-buttons aligncenter\">
<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-black-color has-text-color has-background\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-russian\" style=\"border-radius:2px;background:linear-gradient(135deg,rgb(202,248,128) 0%,rgb(114,207,182) 81%)\" target=\"_blank\" rel=\"noreferrer noopener\">На русском</a></div>



<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link has-text-color\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-english\" style=\"border-radius:2px;color:#ba0c49\" target=\"_blank\" rel=\"noreferrer noopener\">On english</a></div>
</div>



<p>как и в прошлом году, предлагаются и другие языки &#8212; <a rel=\"noreferrer noopener\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-french\" target=\"_blank\">французский</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-german\" target=\"_blank\" rel=\"noreferrer noopener\">немецкий</a>, <a rel=\"noreferrer noopener\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-spanish\" target=\"_blank\">испанский</a> и <a rel=\"noreferrer noopener\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-japanese\" target=\"_blank\">японский</a>.</p>



<p>Сбор данных осуществляется в полном соответствии с <a rel=\"noreferrer noopener\" href=\"https://ru.wordpress.org/about/privacy/\" target=\"_blank\">политикой конфиденциальности WordPress.org</a>: все данные будут анонимизированы и не будут ассоциироваться с IP-адресами и адресами e-mail.</p>



<p>Как и в прошлом году, опрос 2020 года будет продвигаться с помощью баннера на WordPress.org, а также энтузиастами WordPress. </p>



<p>Каждый из переведённых опросов будет продвигаться с помощью баннеров на соответствующих локализованных сайтах WordPress.org. Пожалуйста, поощряйте и  стимулируйте своих друзей  и подписчиков социальных сетей тоже принять участие в опросе!</p>



<p>Для того, чтобы Ваш опыт работы с WordPress был представлен в результатах опроса 2020 года… не откладывайте! Опрос будет доступен для прохождения в течении 6 недель после даты публикации.</p>



<p>Также предлагаются результаты опроса за прошлый год в сравнении с результатами с 2015 года (некоторые результаты ранее не были опубликованы).</p>



<div class=\"wp-block-buttons\">
<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://docs.google.com/presentation/d/1FI7eEvSB5SHTSILIBpwOmH9rBffgD6mFnnqSkrEScYo/edit\" target=\"_blank\" rel=\"noreferrer noopener\">Посмотреть слайды (Google Docs)</a></div>
</div>



<div class=\"wp-block-buttons\">
<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-white-color has-text-color has-background\" href=\"https://www.dropbox.com/sh/bq62sficymopgos/AAA-wx73cDviVG84NSCTgjNDa?dl=0\" style=\"background-color:#005586\" target=\"_blank\" rel=\"noreferrer noopener\">Скачать презентацию (PDF, PPTX)</a></div>
</div>



<p class=\"has-white-color has-text-color\"></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"Mini WordPress Translation Day 2020 — Переводим WordPress вместе!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"https://ru.wordpress.org/news/2020/09/wptd2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 28 Sep 2020 09:33:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:4:\"WPTD\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2192\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:635:\"3 октября 2020 в 12:00 по Москве на YouTube пройдет стрим c Денисом Янчевским по переводу плагинов и тем для WordPress на русский язык. Планируемая продолжительность мероприятия — 3 часа. Присоединиться к стриму Перевод — отличный шанс внести свой вклад в развитие WordPress. Для участия не обязательно быть разработчиком и безупречно знать английский язык — [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6677:\"
<div class=\"wp-block-image\"><figure class=\"aligncenter size-large\"><a href=\"https://www.youtube.com/watch?v=RMcDQvlBRSM\"><img loading=\"lazy\" width=\"1024\" height=\"538\" src=\"https://ru.wordpress.org/files/2020/09/Translation-Day-banner-1024x538.jpg\" alt=\"\" class=\"wp-image-2211\" srcset=\"https://ru.wordpress.org/files/2020/09/Translation-Day-banner-1024x538.jpg 1024w, https://ru.wordpress.org/files/2020/09/Translation-Day-banner-300x158.jpg 300w, https://ru.wordpress.org/files/2020/09/Translation-Day-banner-768x403.jpg 768w, https://ru.wordpress.org/files/2020/09/Translation-Day-banner.jpg 1281w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /></a></figure></div>



<p>3 октября 2020 в 12:00 по Москве на YouTube пройдет стрим c <a rel=\"noreferrer noopener\" href=\"https://profiles.wordpress.org/denisco/\" data-type=\"URL\" data-id=\"https://profiles.wordpress.org/denisco/\" target=\"_blank\">Денисом Янчевским</a> по переводу плагинов и тем для WordPress на русский язык. Планируемая продолжительность мероприятия — 3 часа.</p>



<p><a rel=\"noreferrer noopener\" href=\"https://www.youtube.com/watch?v=RMcDQvlBRSM\" data-type=\"URL\" data-id=\"https://www.youtube.com/watch?v=RMcDQvlBRSM\" target=\"_blank\">Присоединиться к стриму</a></p>



<p>Перевод — отличный шанс внести свой вклад в развитие WordPress. Для участия не обязательно быть разработчиком и безупречно знать английский язык — достаточно базовых знаний и желания учиться. Это также позволит пообщаться с единомышленниками и узнать новые темы и плагины.</p>



<p>Стримы проходят в дружеской атмосфере, с возможностью пообщаться в чате или голосом. Плагины и темы для перевода можно предложить в комментариях к стриму. На данный момент проведено <a href=\"https://ru.wordpress.org/team/category/%D1%81%D1%82%D1%80%D0%B8%D0%BC%D1%8B/\" data-type=\"URL\" data-id=\"https://ru.wordpress.org/team/category/%D1%81%D1%82%D1%80%D0%B8%D0%BC%D1%8B/\" target=\"_blank\" rel=\"noreferrer noopener\">более 20 стримов</a> и переведено несколько десятков плагинов (в том числе Gutenberg). Наиболее активные участники получили статус редакторов переводов с возможностью переводить плагины и темы без дополнительной проверки и проверять переводы других участников.</p>



<p><a rel=\"noreferrer noopener\" href=\"https://www.youtube.com/watch?v=RMcDQvlBRSM\" target=\"_blank\">Присоединиться к стриму</a></p>



<p>Для координации и обсуждения вопросов можно воспользоваться:</p>



<ul><li>каналом <code>translations</code> в <a rel=\"noreferrer noopener\" href=\"https://ruwp.slack.com/\" target=\"_blank\">Slack-группе русскоязычного сообщества WordPress</a> (при регистрации введите адрес вида <code>username@chat.wordpress.org</code>, где <code>username</code> — ваш логин на WordPress.org).</li><li>группой по <a rel=\"noreferrer noopener\" href=\"https://t.me/wp_translate\" data-type=\"URL\" data-id=\"https://t.me/wp_translate\" target=\"_blank\">переводам WordPress в Telegram</a>.</li></ul>



<p>Чтобы составить представление о мероприятии, можно посмотреть один из последних стримов по <a href=\"https://www.youtube.com/watch?v=DJunP3WvZOU\" data-type=\"URL\" data-id=\"https://www.youtube.com/watch?v=DJunP3WvZOU\" target=\"_blank\" rel=\"noreferrer noopener\">этой ссылке</a>.</p>



<p><strong>Полезные ресурсы</strong></p>



<ul><li><a href=\"https://ru.wordpress.org/team/handbook/translations/\" target=\"_blank\" rel=\"noreferrer noopener\">Как перевести тему или плагин?</a></li><li><a rel=\"noreferrer noopener\" href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.A1.D1.82.D0.B8.D0.BB.D1.8C_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.D0.B0\" target=\"_blank\">Рекомендации по стилю перевода</a></li><li><a rel=\"noreferrer noopener\" href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.9A.D0.B0.D0.BA_.D1.81.D0.B4.D0.B5.D0.BB.D0.B0.D1.82.D1.8C_.D1.85.D0.BE.D1.80.D0.BE.D1.88.D0.B8.D0.B9_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.3F\" target=\"_blank\">Как сделать хороший перевод</a></li><li><a rel=\"noreferrer noopener\" href=\"https://translate.wordpress.org/locale/ru/default/glossary\" target=\"_blank\">Словарь терминов</a></li><li><a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/polyglots/handbook/about/get-involved/first-steps/\" target=\"_blank\">Первые шаги переводчика</a></li><li><a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/polyglots/handbook/tools/glotpress-translate-wordpress-org/\" target=\"_blank\">Как работать с сайтом translate.wordpress.org (GlotPress)</a></li></ul>



<p><em><strong>Mini WordPress Translation Day 2020</strong> — это серия онлайн-мероприятий, которые пройдут с 28 сентября по 4 октября 2020 во множестве стран мира и приурочено к <a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/polyglots/2020/09/09/lets-celebrate-international-translation-day-together/\" target=\"_blank\">празднованию всемирного Дня переводчика</a>. Если вы уверенно владеете английским языком, присоединяйтесь к глобальному сообществу <a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/chat/\" target=\"_blank\">WordPress в Slack</a> и заходите на канал <a rel=\"noreferrer noopener\" href=\"https://wordpress.slack.com/messages/polyglots\" target=\"_blank\">#polyglots</a> в течение всей недели, чтобы познакомиться с коллегами со всего мира.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"Yoast SEO: Ищем русскоязычных блогеров\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:201:\"https://ru.wordpress.org/news/2020/05/yoast-seo-%d0%b8%d1%89%d0%b5%d0%bc-%d1%80%d1%83%d1%81%d1%81%d0%ba%d0%be%d1%8f%d0%b7%d1%8b%d1%87%d0%bd%d1%8b%d1%85-%d0%b1%d0%bb%d0%be%d0%b3%d0%b5%d1%80%d0%be%d0%b2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 17 May 2020 10:19:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2176\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:677:\"Два года назад в популярном плагине Yoast SEO появилась&#160;поддержка русского языка&#160;при анализе текста. В ближайших версиях плагина планируется улучшить морфологию для более полной поддержки различных словоформ. Ищем блогеров из русскоязычного сообщества, желающих опробовать эту функцию и, возможно, написать о ней 🙂 Кому интересно — пишите в теме на форуме. Спасибо!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Sergey Biryukov\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1013:\"
<p>Два года назад в популярном плагине Yoast SEO появилась&nbsp;<a href=\"https://yoast.com/yoast-seo-7-5/\">поддержка русского языка</a>&nbsp;при анализе текста.</p>



<p>В ближайших версиях плагина планируется улучшить морфологию для более полной поддержки различных словоформ.</p>



<p>Ищем блогеров из русскоязычного сообщества, желающих опробовать эту функцию и, возможно, написать о ней <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>Кому интересно — пишите в <a href=\"https://ru.wordpress.org/support/topic/yoast-seo-ищем-русскоязычных-блогеров/\">теме на форуме</a>. Спасибо!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"Прием заявок на выступление на WordCamp Moscow 2020 открыт!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:239:\"https://ru.wordpress.org/news/2020/03/%d0%bf%d1%80%d0%b8%d0%b5%d0%bc-%d0%b7%d0%b0%d1%8f%d0%b2%d0%be%d0%ba-%d0%bd%d0%b0-%d0%b2%d1%8b%d1%81%d1%82%d1%83%d0%bf%d0%bb%d0%b5%d0%bd%d0%b8%d0%b5-%d0%bd%d0%b0-wordcamp-moscow-2020-%d0%be%d1%82%d0%ba/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Mar 2020 16:29:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2168\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:727:\"Ознакомиться с подробностями и подать заявку можно по ссылке: https://2020.moscow.wordcamp.org/call-for-speakers/ Прием заявок от спикеров будет идти до 20 апреля или до момента формирования расписания. Решение по каждой заявке будет отправлено в ответном письме до 1-го мая. Быть опытным спикером не обязательно, гораздо важнее разбираться в теме и желание поделиться опытом и знаниями. Сомневаетесь? Ознакомьтесь с [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1147:\"
<p>Ознакомиться с подробностями и подать заявку можно по ссылке: <a href=\"https://2020.moscow.wordcamp.org/call-for-speakers/\">https://2020.moscow.wordcamp.org/call-for-speakers/</a></p>



<p>Прием заявок от спикеров будет идти до 20 апреля или до момента формирования расписания. Решение по каждой заявке будет отправлено в ответном письме до 1-го мая.</p>



<p>Быть опытным спикером не обязательно, гораздо важнее разбираться в теме и желание поделиться опытом и знаниями. Сомневаетесь? <a href=\"https://2020.moscow.wordcamp.org/10-reasons-to-become-a-speaker-at-wordcamp/\" target=\"_blank\" rel=\"noreferrer noopener\">Ознакомьтесь с 10 причинами стать спикером</a>.</p>



<p>Любые вопросы можно задать по адресу <a href=\"mailto:moscow@wordcamp.org\">moscow@wordcamp.org</a>.</p>



<p></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"Продажа билетов на WordCamp Moscow 2020 уже открыта!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:220:\"https://ru.wordpress.org/news/2020/03/%d0%bf%d1%80%d0%be%d0%b4%d0%b0%d0%b6%d0%b0-%d0%b1%d0%b8%d0%bb%d0%b5%d1%82%d0%be%d0%b2-%d0%bd%d0%b0-wordcamp-moscow-2020-%d1%83%d0%b6%d0%b5-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d1%82%d0%b0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Mar 2020 07:00:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2160\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:652:\"Приобрести билет Вы можете на странице регистрации мероприятия. Конференции WordCamp в Москве проводятся c 2013 года и обычно в последний месяц лета на площадке Digital October. Мы решили нарушить традицию и провести мероприятие в другое время и на новом месте. На этот раз технопарк «ФизТехПарк» радушно встретит всех участников 30-го мая! На конференции будет два [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2370:\"
<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"1024\" height=\"273\" src=\"https://ru.wordpress.org/files/2020/03/Frame-4-1024x273.jpg\" alt=\"\" class=\"wp-image-2164\" srcset=\"https://ru.wordpress.org/files/2020/03/Frame-4-1024x273.jpg 1024w, https://ru.wordpress.org/files/2020/03/Frame-4-300x80.jpg 300w, https://ru.wordpress.org/files/2020/03/Frame-4-768x205.jpg 768w, https://ru.wordpress.org/files/2020/03/Frame-4.jpg 1200w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /></figure>



<p>Приобрести билет Вы можете на странице <a rel=\"noreferrer noopener\" href=\"https://2020.moscow.wordcamp.org/tickets/\" target=\"_blank\">регистрации</a> мероприятия.</p>



<p>Конференции WordCamp в Москве проводятся c 2013 года и обычно в последний месяц лета на площадке Digital October. Мы решили нарушить традицию и провести мероприятие в другое время и на новом месте. На этот раз технопарк «ФизТехПарк» радушно встретит всех участников 30-го мая!</p>



<p>На конференции будет два потока. Вы сможете посетить основной поток из 10-11 докладов в Главном зале и участвовать в 2-3 мастер-классах в Малом зале. Также будет организован хелпдеск, где вы сможете задать вопросы и проконсультироваться у профессиональных разработчиков по поводу своих сайтов и проектов в течение дня.</p>



<p>WordCamp это ключевое событие года для WordPress-сообщества в Москве и за ее пределами. Наша задача сделать конференцию яркой, запоминающейся и максимально полезной для каждого участника.</p>



<p>Приобрести билет Вы можете на странице <a href=\"https://2020.moscow.wordcamp.org/tickets/\" target=\"_blank\" rel=\"noreferrer noopener\">регистрации</a> мероприятия.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Ежегодный опрос пользователей и разработчиков WordPress 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ru.wordpress.org/news/2019/11/2019-annual-survey/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 03 Nov 2019 08:53:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2141\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:721:\"Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. В этом году мы рады предложить вам опрос не только на английском, но и на русском языке (также были добавлены испанский, французский, немецкий и японский). Опрос будет проводиться в течении четырех недель, результаты будут опубликованы в английском блоге WordPress.org. Сбор данных осуществляется в [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3146:\"
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img loading=\"lazy\" width=\"768\" height=\"342\" src=\"https://ru.wordpress.org/files/2019/11/image-12-1.png\" alt=\"\" class=\"wp-image-2145 size-full\" srcset=\"https://ru.wordpress.org/files/2019/11/image-12-1.png 768w, https://ru.wordpress.org/files/2019/11/image-12-1-300x134.png 300w\" sizes=\"(max-width: 768px) 100vw, 768px\" /></figure><div class=\"wp-block-media-text__content\">
<p style=\"font-size:18px\">Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. </p>
</div></div>



<p>В этом году мы рады предложить вам опрос не только <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-english\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"на английском (opens in a new tab)\">на английском</a>, но и на русском языке (также были добавлены <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-spanish\">испанский</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-french\">французский</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-german\">немецкий</a> и <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-japanese\">японский</a>). Опрос будет проводиться в течении четырех недель, результаты будут опубликованы в <a rel=\"noreferrer noopener\" aria-label=\"английском блоге WordPress.org (opens in a new tab)\" href=\"https://wordpress.org/news/\" target=\"_blank\">английском блоге WordPress.org</a>.</p>



<p>Сбор данных осуществляется в полном соответствии с <a href=\"https://ru.wordpress.org/about/privacy/\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"политикой конфиденциальности WordPress.org (opens in a new tab)\">политикой конфиденциальности WordPress.org</a>: все данные будут анонимизированы и не будут ассоциироваться с IP-адресами и адресами e-mail.</p>



<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-very-light-gray-color has-vivid-cyan-blue-background-color has-text-color has-background\" href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-russian\">Пройти опрос</a></div>



<p>Если вы ответите, что принимали участие в жизни сообщества или сделали что-либо для WordPress, то вам будет предложен дополнительный опрос для участников сообщества. Каждый из опросов займет примерно 5 минут.</p>



<p>Дополнение: опрос был продлён до 16 декабря.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"Конференция WordCamp Санкт-Петербург 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://ru.wordpress.org/news/2019/08/wordcamp-saint-petersburg-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Aug 2019 09:07:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2119\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:443:\"Второй WordCamp в Санкт-Петербурге пройдет 28 сентября. Для ознакомления с подробностями о мероприятии, а также если вы хотите стать спикером или волонтёром, посетите сайт: https://2019.saintpetersburg.wordcamp.org/ Заказ билетов на мероприятие доступен уже сегодня!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1525:\"
<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://2019.saintpetersburg.wordcamp.org/files/2019/08/b46860.png\" alt=\"\" /></figure></div>



<p>Второй WordCamp в Санкт-Петербурге пройдет 28 сентября. Для ознакомления с подробностями о мероприятии, а также если вы хотите стать спикером или волонтёром, посетите сайт: <a rel=\"noreferrer noopener\" aria-label=\"https://2019.saintpetersburg.wordcamp.org/ (opens in a new tab)\" href=\"https://2019.saintpetersburg.wordcamp.org/\" target=\"_blank\">https://2019.saintpetersburg.wordcamp.org/</a></p>



<figure class=\"wp-block-image\"><img loading=\"lazy\" width=\"1024\" height=\"629\" src=\"https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-1024x629.jpg\" alt=\"\" class=\"wp-image-2125\" srcset=\"https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-1024x629.jpg 1024w, https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-300x184.jpg 300w, https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-768x472.jpg 768w, https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2.jpg 1680w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /><figcaption>Конференция пройдет в пространстве коворкинга &#171;Ясная Поляна&#187; ул. Льва Толстого 1-3</figcaption></figure>



<p>Заказ билетов на мероприятие доступен уже сегодня!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"WordPress Translation Day 4 — Санкт-Петербург\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:152:\"https://ru.wordpress.org/news/2019/05/wordpress-translation-day-4-%d1%81%d0%b0%d0%bd%d0%ba%d1%82-%d0%bf%d0%b5%d1%82%d0%b5%d1%80%d0%b1%d1%83%d1%80%d0%b3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 May 2019 11:53:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2099\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:685:\"Друзья! Ни для кого не секрет, что 11-го мая проходит всемирный суточный марафон перевода WordPress. В рамках https://wptranslationday.org/ в Петербурге очная часть пройдет по адресу 9-я Советская, 18 (пространство funhouse, цоколь) с 12.00 до 21.00. Вход свободный в любое время. В программе &#8212; философия WordPress полиглотов, инструктаж, практическая часть, где мы переводим непереведенные плагины, темы, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1476:\"
<p>Друзья! Ни для кого не секрет, что 11-го мая проходит всемирный суточный марафон перевода WordPress. В рамках <a href=\"https://wptranslationday.org/\">https://wptranslationday.org/</a>  в Петербурге очная часть <a href=\"https://www.meetup.com/St-Petersburg-WordPress-Meetup/events/261316455/\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"пройдет (opens in a new tab)\">пройдет</a> по адресу 9-я Советская, 18  (пространство funhouse, цоколь) с 12.00 до 21.00. Вход свободный в любое  время.</p>



<p>В программе &#8212; философия WordPress полиглотов, инструктаж,  практическая часть, где мы переводим непереведенные плагины, темы, и  т.д. Заочно можно участвовать присоединившись в Телеграм-группу @wcspb  <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>Берем свои ноутбуки, знание русского языка (и немного английского), и отличное настроение!</p>



<p>Полиглоты, лингвисты, программисты объединяйтесь!</p>



<p></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"WP Moscow #6. Собственная тема на Elementor, кейс по WordPress + React JS\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:222:\"https://ru.wordpress.org/news/2019/02/wp-moscow-6-%d1%81%d0%be%d0%b1%d1%81%d1%82%d0%b2%d0%b5%d0%bd%d0%bd%d0%b0%d1%8f-%d1%82%d0%b5%d0%bc%d0%b0-%d0%bd%d0%b0-elementor-%d0%ba%d0%b5%d0%b9%d1%81-%d0%bf%d0%be-wordpress-react-js/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Feb 2019 05:10:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2081\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:563:\"Очередной митап по WordPress состоится в четверг 28 февраля. Запланировано два доклада: «Создание собственной темы для WordPress сайта при помощи плагина Elementor»Леонид Лукин «Как сделать впечатляющий промо-сайт на WordPress + React JS. Разбор кейса.»Андрей Панферов Вход свободной по предварительной регистрации. Начало в 19.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:742:\"
<p>Очередной митап по WordPress состоится в четверг 28 февраля.</p>



<p>Запланировано два доклада:</p>



<p><strong>«Создание собственной темы для WordPress сайта при помощи плагина Elementor»</strong><br>Леонид Лукин</p>



<p><strong>«Как сделать впечатляющий промо-сайт на WordPress + React JS. Разбор кейса.»</strong><br>Андрей Панферов</p>



<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/wordpress-moscow/events/258755820/\">предварительной регистрации</a>.</p>



<p>Начало в 19.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WP Moscow #5 | Тонкости продаж, Gutenberg и ACF\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:157:\"https://ru.wordpress.org/news/2019/01/wp-moscow-5-%d1%82%d0%be%d0%bd%d0%ba%d0%be%d1%81%d1%82%d0%b8-%d0%bf%d1%80%d0%be%d0%b4%d0%b0%d0%b6-gutenberg-%d0%b8-acf/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Jan 2019 16:14:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2074\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:424:\"Очередной митап по WordPress состоится в четверг 31 января. Запланировано два доклада: «Как продавать услуги по разработке сайтов»Андрей Панферов «ACF PRO + Gutenberg»Николай Миронов Вход свободной по предварительной регистрации. Начало в 19.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:603:\"
<p>Очередной митап по WordPress состоится в четверг 31 января.</p>



<p>Запланировано два доклада:</p>



<p><strong>«Как продавать услуги по разработке сайтов»</strong><br>Андрей Панферов</p>



<p><strong>«ACF PRO + Gutenberg»</strong><br>Николай Миронов</p>



<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/wordpress-moscow/events/258124643/\">предварительной регистрации</a>.</p>



<p>Начало в 19.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://ru.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Wed, 04 Nov 2020 19:09:42 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Wed, 04 Nov 2020 18:59:47 GMT\";s:4:\"link\";s:61:\"<https://ru.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20200501142607\";}","no");
INSERT INTO `wp_options` VALUES("137","_transient_timeout_feed_mod_126d1ca39d75da07beec8b892738427b","1604560182","no");
INSERT INTO `wp_options` VALUES("138","_transient_feed_mod_126d1ca39d75da07beec8b892738427b","1604516982","no");
INSERT INTO `wp_options` VALUES("139","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1604560185","no");
INSERT INTO `wp_options` VALUES("140","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:122:\"WPTavern: WordPress 5.6 to Add UI for Enabling Major Version Auto-Updates, Contributors Discuss Adding a Filter to Hide It\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=107214\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:287:\"https://wptavern.com/wordpress-5-6-to-add-ui-for-enabling-major-version-auto-updates-contributors-discuss-adding-a-filter-to-hide-it?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-5-6-to-add-ui-for-enabling-major-version-auto-updates-contributors-discuss-adding-a-filter-to-hide-it\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4409:\"<p>WordPress 5.6 is set to add <a href=\"https://make.wordpress.org/core/2020/11/02/introducing-auto-updates-interface-for-core-major-versions-in-wordpress-5-6/\">a UI that allows users to opt into auto-updates for major versions</a> of core. Previously, developers could turn these updates on by setting the&nbsp;<code>WP_AUTO_UPDATE_CORE</code>&nbsp;constant to&nbsp;<code>true</code>&nbsp;or by using the&nbsp;<code>allow_major_auto_core_updates</code>&nbsp;filter. Version 5.6 exposes this setting in the UI to make it more accessible for users. </p>



<img />



<p>Jb Audras posted a <a href=\"https://make.wordpress.org/core/2020/11/02/introducing-auto-updates-interface-for-core-major-versions-in-wordpress-5-6/\">dev note</a> on the feature yesterday with instructions for how developers can extend it to add more options.</p>



<p>A previous version of this UI specified that the setting refers to major versions: </p>



<blockquote class=\"wp-block-quote\"><p>Keep my site up-to-date with regular feature updates (major versions).</p></blockquote>



<p>This was <a href=\"https://core.trac.wordpress.org/changeset/49285\">changed</a> 11 days ago to remove the wording that tells users which versions the setting controls. </p>



<p>&ldquo;The idea was to make the wording more general, and maybe easier to understand,&rdquo; Jb Audras said. &ldquo;As minor updates are already automatically updated (since 3.7), new users may not understand what is behind the &lsquo;major versions&rsquo; term.&rdquo;</p>



<p>This new wording makes the setting unclear. Users may not understand what &ldquo;major versions&rdquo; are but &ldquo;feature updates&rdquo; is even less clear. Does it include updates to existing features? Or only the introduction of brand new features? A better option might be to link &ldquo;major versions&rdquo; to documentation on HelpHub.</p>



<p>In the current climate, where <a href=\"https://wptavern.com/wordpress-2019-survey-results-show-professionals-slow-to-adopt-block-editor-2020-survey-now-open\">positive sentiment regarding auto-updates is declining</a>, shipping the new UI with a nebulous term like &ldquo;feature updates&rdquo; is not going to inspire as much confidence as explicitly identifying what updates the setting controls.</p>



<p>Audras said he is open to having the wording changed but that so far those testing the beta don&rsquo;t seem to have a problem with it. String freeze is scheduled for November 10, and after that no more wording updates can be committed. </p>



<p>Contributors are also discussing adding a filter that would allow developers to <a href=\"https://core.trac.wordpress.org/ticket/51698\">hide the auto-updates UI for major versions</a>. Mike Schroder noted that this would be especially useful for hosting companies that are handling updates in a different way. Some developers or agencies may want to use the filter to prevent their clients from turning auto-updates on for major versions.</p>



<p>Core Committer Jonathan Desrosiers <a href=\"https://core.trac.wordpress.org/ticket/51698#comment:5\">said</a> he is not in favor of using a filter to hide the UI on a page that is not likely to be accessed by users who have the ability to update core:</p>



<blockquote class=\"wp-block-quote\"><p>If that change is made (disabling the form when the constant is defined or&nbsp;<code>allow_major_auto_core_updates</code>&nbsp;filter is used), then I am not sure the UI should ever be hidden. As raised by&nbsp;<a href=\"https://profiles.wordpress.org/aaroncampbell\">@aaroncampbell</a>&nbsp;in today&rsquo;s weekly meeting, the update page is only accessible to those with the&nbsp;<code>update_core</code>&nbsp;capability (trusted users). While there may be valid use cases for wholesale hiding the new feature, I haven&rsquo;t seen one yet. To me, disabling the form and explaining why the form cannot be used to update the desired behavior is more valuable to the site owner, as they would be better equipped to make an adjustment.</p></blockquote>



<p>If you want to contribute to the conversation, check out the <a href=\"https://make.wordpress.org/core/2020/11/02/introducing-auto-updates-interface-for-core-major-versions-in-wordpress-5-6/\">dev note</a> on the new auto-updates interface for major versions and the Trac <a href=\"https://core.trac.wordpress.org/ticket/51698\">ticket</a> for a filer that would hide the UI.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Nov 2020 23:32:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:103:\"WPTavern: Automattic Releases Spearhead, a Seedlet Child Theme Aimed at Podcasters and Content Creators\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=107225\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:249:\"https://wptavern.com/automattic-releases-spearhead-a-seedlet-child-theme-aimed-at-podcasters-and-content-creators?utm_source=rss&utm_medium=rss&utm_campaign=automattic-releases-spearhead-a-seedlet-child-theme-aimed-at-podcasters-and-content-creators\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5128:\"<img />Spearhead theme blog/posts page.



<p class=\"has-drop-cap\">Last Thursday, Automattic announced its <a href=\"https://wordpress.com/blog/2020/10/29/spearhead/\">new Spearhead theme</a> to WordPress.com users, which primarily focuses on podcasters. However, the team has marketed it toward content creators in general. It is a child theme of the company&rsquo;s recently-released <a href=\"https://wptavern.com/exploring-seedlet-automattics-block-first-wordpress-theme\">Seedlet theme</a>. Cece Yu originally created the design for the <a href=\"https://spearhead.co/\">Spearhead</a> podcast, which is currently in use on the website.</p>



<p>Spearhead is not just a theme for WordPress.com users. Self-hosted WordPress users can expect availability in the future. &ldquo;Adding Spearhead to the themes directory is on our to-do list,&rdquo; said Jeff Ong, a designer at Automattic. &ldquo;Just haven&rsquo;t gotten round to it yet.&rdquo;</p>



<p>For self-hosted users who want to give the child theme a spin right now, Automattic hosts all of its free themes in a <a href=\"https://github.com/Automattic/themes\">GitHub mono-repository</a>. The Spearhead theme is located in its own <code>/spearhead</code> sub-directory.</p>



<p>The announcement post said that the theme is fully block powered. This would be better reworded to say that it is a block-first WordPress theme. When full-site editing lands in core WordPress, we can start saying that themes are fully powered by blocks. Until then, it is just the content that is made of blocks. And, Spearhead&rsquo;s parent theme is a prime example of a solid block-first theme. I imagine it will be the springboard of many upcoming themes from Automattic&rsquo;s theme designers, whether that is in the form of a building child themes or using it as a starter.</p>



<p>Given Spearhead&rsquo;s podcast roots, the development team wrote a small function to locate an Audio block from the post content and present it on the blog and other archive-type pages below the excerpt. In the past, this sort of feature was difficult to achieve because of little-to-no standardization on audio output. However, the block system makes it possible with just a few lines of code.</p>



<h2>Automatic Dark Mode Support</h2>



<img />Light vs. dark modes based on OS settings.



<p class=\"has-drop-cap\">One of the more interesting aspects of Spearhead is its support for users who are browsing the web in dark mode. This setting is located in various locations based on the user&rsquo;s operating system. However, when enabled by the user, the theme automatically detects this and switches its color scheme.</p>



<p>This system uses the <code>prefers-color-scheme</code> <a href=\"https://developer.mozilla.org/en-US/docs/Web/CSS/@media/prefers-color-scheme\">CSS media feature</a> to style for dark mode. This feature is generally <a href=\"https://caniuse.com/?search=prefers-color-scheme\">supported</a> by most modern web browsers. For browsers and operating systems without dark/light mode support, users will see the default light color scheme for the theme.</p>



<p>I generally prefer light color schemes, but this is one of the few dark color schemes that is at least comparable or maybe better than the light one. Far too often, I find dark schemes unreadable for long-form content, but the development team took care to select a palette that works well for whatever the site visitor chooses.</p>



<h2>Custom Block Patterns</h2>



<img />Inserting the Podcast Links block pattern.



<p class=\"has-drop-cap\">Spearhead removes the three patterns registered by the Seedlet parent theme. It then registers four of its own patterns:</p>



<ul><li>Related Posts</li><li>Archive Page</li><li>Podcast Links</li><li>Podcast Links List</li></ul>



<p>The Related Posts pattern requires the Jetpack plugin to be installed. Currently, the theme does not check if the plugin is active before registering the pattern. Presumably, this is because Jetpack features are available on all WordPress.com sites. However, the development team will need to address this before submitting it to the WordPress.org theme directory.</p>



<p>The Archive pattern allows users to create an archive page on their site. It displays a search form, the latest posts, and the site&rsquo;s categories. It is not quite as fully featured as a complete archive plugin. However, it does replace what is often the traditional archive page template shipped with many themes. The use of a pattern is a nice shift that gives users more flexibility to change the output than what is possible with page templates. </p>



<p>It will be interesting to see if more theme authors follow suit and reevaluate their theme&rsquo;s page templates. Transitioning to a block pattern may be a better option in many cases.</p>



<p>The Podcast Links pattern outputs a Navigation block with links to sites that host podcasts. End-users will want to update the link URLs. The Podcast Links List pattern is similar. Surprisingly, it is not actually a list. It is a paragraph of links and does not have the same prefix text.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Nov 2020 22:24:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"WPTavern: WordPress 2019 Survey Results Show Professionals Slow to Adopt Block Editor, 2020 Survey Now Open\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106946\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:257:\"https://wptavern.com/wordpress-2019-survey-results-show-professionals-slow-to-adopt-block-editor-2020-survey-now-open?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-2019-survey-results-show-professionals-slow-to-adopt-block-editor-2020-survey-now-open\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7439:\"<p>WordPress has opened its <a href=\"https://wordpress.org/news/2020/10/take-the-2020-wordpress-annual-survey-and-view-the-2019-results/\">2020 Annual Survey</a>, a short set of questions designed to collect more information on how different groups of people are using the software. It takes approximately 5 minutes to complete and all data is anonymized. </p>



<p>WordPress Executive Director Josepha Haden Chomphosy <a href=\"https://twitter.com/JosephaHaden/status/1321227911462936576\">said</a> she uses the results from the survey to inform her plans and recommendations all year long. In addition to providing valuable information for WordPress&rsquo; leadership, the results will also be shared with the wider community. </p>



<p>The Community Team has prepared a report with results from the 2015 and 2019 surveys, which had not been previously published. The <a href=\"https://docs.google.com/presentation/d/1FI7eEvSB5SHTSILIBpwOmH9rBffgD6mFnnqSkrEScYo/edit\">2019 results</a> are summarized in a set of Google slides and are also <a href=\"https://www.dropbox.com/sh/bq62sficymopgos/AAA-wx73cDviVG84NSCTgjNDa?dl=0\">available as a PDF or PPT</a>. </p>



<p>Despite 2019 being the first year that the survey was translated into five different languages, it only received 6,203 respondents, as compared to nearly 46,000 in 2015. The highest number of responses came from Europe (62%) and Asia (12%), while North American engagement has declined drastically to just 10%. Unchanged from previous years, most WordPress users identify as male (79%).</p>



<h2>2019 NPS Results: Detractors are Steadily Shrinking</h2>



<p>The 164-page report has a lot of information to digest but one of the highlights is the Net Promoter Score (NPS). It is a loyalty metric derived from users&rsquo; responses to the question of how likely they are to recommend WordPress to friends, colleagues, or clients. It provides an informal measurement of user satisfaction or perception.</p>



<p>WordPress&rsquo; 2019 NPS was 54, an increase from previous scores of 50 and 52. Promoters remain static while Detractors are steadily shrinking. This score, however, is skewed towards representing those who have a favorable enough opinion of WordPress to take the time to respond to the survey. The software&rsquo;s truest detractors have likely already moved on to following other tech communities and may be underrepresented in the NPS score.</p>



<img />



<p>More than 75% of respondents have been using WordPress for three years or more. Results indicated the project&rsquo;s open source community is an important driver for why people use the software:</p>



<blockquote class=\"wp-block-quote\"><p>&ldquo;Nearly six-in-ten (59%) of survey respondents choose WordPress because it&rsquo;s what they know best. Half (50%) say they enjoy its open source community. Nearly half (48%) say WordPress has the features they need.&rdquo;</p></blockquote>



<p>This indicates that the WordPress community provides a factor of &ldquo;stickiness&rdquo; equal to that of the features the software offers. Improving and maintaining a healthy community is an important consideration for user retention, since a user sticking with WordPress is just as important as attracting new users. </p>



<h2>CMS Usage on the Rise Among Professionals, Blogging Is Declining</h2>



<p>The 2019 survey found that 76% of professionals are using WordPress as a  CMS, with slightly higher numbers (79%) for the WordPress Company Pros segment (those who work for a company that designs/develops websites). Blogging usage among professionals is consistently declining. </p>



<img />



<p>In the segment of respondents reporting as Users, blogging is also on the decline, with 49% using WordPress as a personal blog in 2019 vs. 63% in previous years (2015-2017).</p>



<h2>WordPress Professionals Slow to Adopt the Block Editor</h2>



<p>One noteworthy section in the 2019 results includes data on block editor adoption. When asked &ldquo;Which editor do you currently use?&rdquo;, 53% of respondents who identified as professionals said they are using the Classic Editor. This indicates the block editor is still finding its footing among professionals. An increasing percentage of these professionals are also self-employed (44% in 2019 vs 36% in 2016).</p>



<p>Another question asked, &ldquo;Have you or your team built blocks for the new editor?&rdquo; Less than half of those using the new editor confirmed they have new blocks added for using it, and 17% were not sure. If more than half of professionals have yet to adopt the new editor, it seems the market for block-based products has a great deal of room to grow.</p>



<img />



<p>Block editor adoption among Users could be as low as 36% or as high as 56%, but a large portion of users (20%) are unsure which editor they are using. This is not a bad thing, as most new users will have no prior knowledge of the Classic editor. Results from the 2020 survey should be useful for tracking adoption of the block editor over a longer period of time since its debut in WordPress 5.0 (2018.)</p>



<img />



<p>Attendance at WordPress community events, such as meetups and WordCamps, seemed to be on the rise, as well as submitting bug reports and contributing to documentation. However, 2019 saw a sharp decline in the percentage of those who report having created their own theme (61% to 42%) or plugin (50% to 38%), when compared with previous years. The percentage of core contributors (5%) has remained steady. This might mean that creating themes and plugins is becoming more difficult or less rewarding, or perhaps the survey attracted more of a different type of user than it did in previous years. There are any number of explanations but this may be a trend to continue watching.</p>



<img />



<h2>WordPress Users Remain Uneasy about Auto-Updates, Positive Sentiment is Declining</h2>



<p>In light of the incident last week where <a href=\"https://wptavern.com/wordpress-auto-update-system-misfires-updating-live-sites-to-an-alpha-release\">WordPress&rsquo; auto-update system misfired</a>, updating live sites to an alpha version, the survey includes valuable data about how users are feeling about this feature. The data from 2019 indicates that positive sentiments regarding auto-updates were already on the decline since 2015. </p>



<img />



<p>Those reporting that they loved auto-updates declined from 41% to 35%. The percentage of those who would like to see auto-updates for major releases of WordPress declined from 24% to 15%. Positive sentiment regarding theme and plugin auto-updates also decreased. Meanwhile, awareness of auto-updates increased in 2019, and slightly more users reported the feature makes them nervous or that they hate it.</p>



<p>These are just a few major highlights from the 2019 survey results, but the report includes much more detailed data regarding contributor satisfaction, time spent contributing, contributors&rsquo; experiences, and other topics. Check out all the summaries in the Google docs <a href=\"https://docs.google.com/presentation/d/1FI7eEvSB5SHTSILIBpwOmH9rBffgD6mFnnqSkrEScYo/edit#slide=id.g71a4c4edc6_3_232\">presentation</a>, and make sure to <a href=\"https://wordpress.org/news/2020/10/take-the-2020-wordpress-annual-survey-and-view-the-2019-results/\">take the 2020 survey</a> to improve the representation of WordPress users this year. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Nov 2020 23:12:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"WPTavern: Full-Site Editing Is Not the End of Artistic WordPress Themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106872\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:187:\"https://wptavern.com/full-site-editing-is-not-the-end-of-artistic-wordpress-themes?utm_source=rss&utm_medium=rss&utm_campaign=full-site-editing-is-not-the-end-of-artistic-wordpress-themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7258:\"<blockquote class=\"wp-block-quote\"><p>These plain canvas-like themes have until now been a choice for those who prefer it (those who like to design their own thing), but this article makes it sound like these types of themes should be the only choice in the future of WP.</p><p>This is worrisome to me as a non-designer who looks for themes specifically based on things like attractive button styles.</p><p>FSE sounds bad for people like me, who aren&rsquo;t artistic, can&rsquo;t coordinate colors, and want themes to do the artistic stuff.</p></blockquote>



<p>This was the <a href=\"https://wptavern.com/q-first-fse-wordpress-theme-now-live#comment-350166\">response by a Tavern reader</a> named Isabel on the recent <a href=\"https://wptavern.com/q-first-fse-wordpress-theme-now-live\">coverage of the Q theme</a>, an experimental project for the upcoming full-site editing (FSE) feature of WordPress. More specifically, she was worried about a thought that Ari Stathopoulos, the theme designer, had made asking that theme authors not get too opinionated with their default styles for things like buttons and so on. His view seemed to lean more toward creating open and customizable themes. However, it is not the only valid opinion on what themes should look like.</p>



<p>This is not much different than what we have experienced over the previous decade or more. Some theme authors build open canvasses for users to customize. Other theme authors build intricately-designed layouts with unique textures, shapes, and forms.</p>



<p>This is not going to change when FSE lands in core WordPress. Themes are merely the expression of the designer&rsquo;s vision for what a site could look like, and not all theme authors think about design in the same ways.</p>



<p>The Q theme is meant as a starting point or testbed for FSE. There will be many open-canvas themes. These types of themes are already wildly popular, particularly when used in conjunction with a page builder. Astra has over a million installs. Hello Elementor has surpassed 400,000. GeneratePress has over 300,000. There is big money in this segment of the theme market. FSE will undoubtedly help to increase the competition.</p>



<p>However, that is not all that themers are giving us. The recently-released <a href=\"https://wordpress.org/themes/photofocus/\">PhotoFocus</a> theme by Catch Themes is on the upward trend, inching its way into the popular themes list on WordPress.org. And, there are hundreds of other options that go beyond the plain ol&rsquo; open, black-text-on-white-background themes built for customization by the end-user.</p>



<p>I simply do not see the current trends shifting too much. Yes, those trends already lean heavily toward open-canvas themes.  FSE will allow developers to build those types of themes for core WordPress instead of page builders much more easily. </p>



<p>However, this is also an opportunity for those who want to experiment with more artistry to do so.</p>



<p>Stathopoulos did say:</p>



<blockquote class=\"wp-block-quote\"><p>It&rsquo;s tempting to add extremely opinionated styles, for buttons for example, but more and more things get added every day to the editor like a border-radius setting for buttons.</p></blockquote>



<p>But, we must put that into the context of his followup remarks:</p>



<blockquote class=\"wp-block-quote\"><p>Theme authors should avoid the trap of designing an FSE theme having in mind what the editor currently does. Instead, theme authors should strive to build something having in mind a vision of what the editor will eventually become.</p></blockquote>



<p>He is not saying that every theme needs to be plain and boring. He is not saying that theme authors should be reluctant to put a unique spin on the Button block, for example. He is saying that theme authors need to evaluate how they approach design based on what block options are available for end-users.</p>



<p>Buttons are a good example of this. With the border-radius option that allows end-users to control rounded corners for buttons, he means that theme authors should not overwrite border-radius styles in their CSS. Users should have the <em>option</em> to control it if they want. He is also talking about using the eventual Global Styles system to set up defaults. If theme authors want rounded buttons by default, they should use the system that WordPress provides rather than writing the CSS. He wants theme authors to be aware of the current block options and styles while preparing for new options in the future.</p>



<p>This upcoming era of theming changes how theme authors work with the system. It does not mean they cannot branch out in terms of design.</p>



<p>Here&rsquo;s where the block editor project makes things more interesting for those users who want things like &ldquo;attractive button styles&rdquo; but lack some of the artistic skills expected from the theme&rsquo;s designer. The block system is set up for unlimited variations on what themes can provide to end-users.</p>



<p>Sticking with the Button block example, users can already see two block styles named Fill and Outline in WordPress as shown in the following screenshot.</p>



<img />Using the Outline block style.



<p>Theme authors can add all sorts of style variations today, and some have already done so. Block styles offer a lot of variety, and WordPress allows users to further customize these if they wish to do so.</p>



<p>WordPress also offers two different block patterns that utilize the Buttons block. They are basic two and three-button layouts. However, theme authors can use the Patterns API to create any number of layout options using buttons.</p>



<img />Inserting the &ldquo;two buttons&rdquo; block pattern into the editor.



<p>Stathopoulos&rsquo;s comments on not being too opinionated should also be taken in the context of the upcoming Global Styles system, which is currently being tested in the Gutenberg plugin. This system allows theme authors to set up global, default options for everything. They can also drill down and set up default options for individual blocks. For example, a theme author can set a default background gradient, rounded corners, and any other options available for the Button block. These default options can span the width of the spectrum, from a simple and understated square button to a rounded button with a vibrant gradient background and a drop-shadow. The more block options that WordPress&rsquo;s editor offers in the future, the more flexible theme authors can be with their designs.</p>



<img />Experimental, per-block global styles in the site editor (feature not finished).



<p>Isabel&rsquo;s concern is valid. It is tough to keep up with all the changes happening and those that are on the feature list of the future. The Gutenberg project moves fast, and when we write about features or experimental themes, it is easy to overlook some of those questions that the average user might have.</p>



<p>To put some users&rsquo; minds at ease, future WordPress themes will undoubtedly offer a breadth of artistic designs that are suitable for all sorts of websites. Designers and non-designers alike should look forward to the months and years ahead.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Nov 2020 22:12:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.6 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9234\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/11/wordpress-5-6-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5120:\"<p>WordPress 5.6 Beta 3 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so we recommend that you run this version on a test site.</p>



<p>You can test the WordPress 5.6 beta in two ways:</p>



<ul><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option).</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.6-beta3.zip\">download the beta here&nbsp;(zip)</a>.</li></ul>



<p>The current target for the final release is December 8, 2020. This is just&nbsp;<strong>five weeks away</strong>, so your help is needed to ensure this release is tested properly.</p>



<p>Thank you to all of the contributors that tested the&nbsp;<a href=\"https://wordpress.org/news/2020/10/wordpress-5-6-beta-2/\">beta 2&nbsp;</a>development release and provided feedback. Testing for bugs is an important part of polishing each release and a great way to contribute to WordPress.</p>



<h2><strong>Some Highlights</strong></h2>



<p>Since&nbsp;beta 2,&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/query?status=closed&changetime=10%2F28%2F2020..11%2F03%2F2020&milestone=5.6&group=component&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">20 bugs</a>&nbsp;have been fixed. Here is a summary of a few changes included in beta 3:</p>



<ul><li>Added block patterns for Twenty Twenty (see&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/51098\">#51098</a>) and Twenty Nineteen (see&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/51099\">#51099</a>) themes.</li><li>Added theme support for navigation-widgets (see&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/51445\">#51445</a>).</li><li>Fixed incorrect slashes in the URL if the parent is empty for REST API (see&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/44745\">#44745</a>).</li><li>Added a test to Site Health to verify that the&nbsp;<code>Authorization</code>&nbsp;header is working as expected for Application Passwords (see&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/51638\">#51638</a>).</li><li>10 additional bugs fixed in the block editor (see&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://github.com/WordPress/gutenberg/pull/26588\">#26588</a>).</li></ul>



<p>To see all of the features for each Gutenberg release in detail, check out the release posts:&nbsp;<a href=\"https://make.wordpress.org/core/2020/07/22/whats-new-in-gutenberg-july-22/\">8.6</a>,&nbsp;<a href=\"https://make.wordpress.org/core/2020/08/05/whats-new-in-gutenberg-august-5/\">8.7</a>,&nbsp;<a href=\"https://make.wordpress.org/core/2020/08/19/whats-new-in-gutenberg-august-19/\">8.8</a>,&nbsp;<a href=\"https://make.wordpress.org/core/2020/09/03/whats-new-in-gutenberg-2-september/\">8.9</a>,&nbsp;<a href=\"https://make.wordpress.org/core/2020/09/16/whats-new-in-gutenberg-16-september/\">9.0</a>,&nbsp;<a href=\"https://make.wordpress.org/core/2020/10/01/whats-new-in-gutenberg-30-september/\">9.1</a>, <a href=\"https://make.wordpress.org/core/2020/10/21/whats-new-in-gutenberg-21-october/\">9.2</a>, and <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v9.3.0-rc.1\">9.3</a>.</p>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.6 has lots of refinements to the developer experience as well. To keep up, subscribe to the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;and pay special attention to the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-6+dev-notes/\">developers’ notes</a>&nbsp;for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>,&nbsp;where you can also find a list of&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=new&milestone=5.6&group=component&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">known bugs</a>.</p>



<p><em>Props to <a href=\"https://profiles.wordpress.org/hellofromtonya/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>hellofromtonya</a> for help and <a href=\"https://profiles.wordpress.org/chanthaboune/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>chanthaboune</a>  for final review.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Nov 2020 21:23:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Chloe Bringmann\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"WordPress.org blog: The Month in WordPress: October 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9225\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2020/11/the-month-in-wordpress-october-2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:11859:\"<p>October 2020 was a notable month for WordPress lovers, thanks to the release of several products and updates. Read on to keep up with all the latest news!</p>



<hr class=\"wp-block-separator\" />



<h2>The 2020 WordPress Annual Survey is out</h2>



<p>The team published the <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-english\">2020 WordPress Annual survey</a> —&nbsp; to help those who build WordPress to understand more about our software usage and our contributors’ experience. The Annual Survey will be open for at least 6 weeks and is available in <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-french\">French</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-german\">German</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-japanese\">Japanese</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-russian\">Russian</a>, and <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-spanish\">Spanish</a>. The survey results (once complete) will be posted on <a href=\"https://wordpress.org/news/\">WordPress.org/news</a>. The<a href=\"https://wordpress.org/news/2020/10/take-the-2020-wordpress-annual-survey-and-view-the-2019-results/\"> 2019 survey results</a> have also been released and can now be viewed as <a href=\"https://docs.google.com/presentation/d/1FI7eEvSB5SHTSILIBpwOmH9rBffgD6mFnnqSkrEScYo/edit\">slides</a> or downloaded in <a href=\"https://www.dropbox.com/sh/bq62sficymopgos/AAA-wx73cDviVG84NSCTgjNDa?dl=0\">PDF format</a>.&nbsp;</p>



<h2>WordPress Translation celebrations spanned four weeks</h2>



<p>The last week of September and most of October were focused on recruiting and encouraging polyglot contributors to the WordPress translation project. What was originally envisioned as a single-day event lasted 24 days! The Polyglots and Marketing Teams are exploring how future mini-events can be supported to continue building the momentum. Recordings of the live talks and interviews with contributors are available <a href=\"https://www.youtube.com/playlist?list=PLCVEqsAbLfffK5WzOT9BhPsh82HgM8vj1\">on YouTube</a>. Write-ups from the different events are <a href=\"https://wptranslationday.org/\">on the WPTranslationDay website</a>. </p>



<p>Want to help WordPress speak your own language? Follow <a href=\"https://make.wordpress.org/polyglots\">the Polyglots team blog</a> and join the <a href=\"https://wordpress.slack.com/archives/C02RP50LK\">#polyglots</a> channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.&nbsp;</p>



<h2>WordPress maintenance and beta releases</h2>



<p>The Core team released <a href=\"https://make.wordpress.org/core/2020/10/30/wordpress-5-5-3-release-some-technical-details/\">WordPress 5.5.3 on Oct. 31</a>, following the release of Version <a href=\"https://wordpress.org/news/2020/10/wordpress-5-5-2-security-and-maintenance-release/\">5.5.2 on Oct. 29</a>. Both releases fix several bugs and security issues with WordPress. You can update to the latest version directly from your WordPress dashboard or <a href=\"https://wordpress.org/download/\">download</a> it now from WordPress.org.&nbsp; The team also released WordPress 5.6 <a href=\"https://wordpress.org/news/2020/10/wordpress-5-6-beta-1/\">Beta 1</a> on Oct. 20, followed by <a href=\"https://wordpress.org/news/2020/10/wordpress-5-6-beta-2/\">Beta 2 </a>on Oct. 27. When ready, the final release will include improvements to the editor, auto-updates for major releases, PHP 8 support, and the Twenty Twenty One theme. You can test the Beta versions by <a href=\"https://wordpress.org/wordpress-5.6-beta2.zip\">downloading them from WordPress.org</a> or using the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin.<br /></p>



<p>Want to be involved in the next release? Follow WordPress 5.6 updates on the <a href=\"https://make.wordpress.org/core/5-6/\">development cycle</a> and sign-up for the <a href=\"https://make.wordpress.org/core/2020/10/22/code-review-commit-office-hours-for-5-6/\">code review/commit office hours</a>. You can help build WordPress Core by following<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a> and joining the <a href=\"https://wordpress.slack.com/archives/C02RQBWTW\">#core</a> channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>. If you would like to help out with WordPress 5.6 outreach, contact the <a href=\"https://make.wordpress.org/marketing/\">WordPress Marketing team</a> on the <a href=\"https://wordpress.slack.com/archives/C0GKJ7TFA\">#marketing</a> channel.</p>



<h2>Gutenberg 9.2 is released</h2>



<p><a href=\"https://make.wordpress.org/core/2020/10/21/whats-new-in-gutenberg-21-october/\">Version 9.2</a> of the Gutenberg plugin came out on Oct. 21. This release offers support for video subtitles, the ability to transform selected blocks into the columns block, background patterns in cover blocks, along with several exciting features such as improvements to the widget screen, as well as bug fixes. You can find out more about the Gutenberg roadmap in the <a href=\"https://make.wordpress.org/core/2020/10/01/whats-next-in-gutenberg-october/\">What’s next in Gutenberg blog post</a>.</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the #core-editor channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Learn WordPress is gearing up for launch</h2>



<p>The <a href=\"https://learn.wordpress.org/\">Learn WordPress</a> initiative, which offers <a href=\"https://learn.wordpress.org/workshops/\">WordPress video workshops</a> followed by <a href=\"https://www.meetup.com/learn-wordpress-discussions/\">interactive discussions</a>, is aiming to put out two courses by the end of the year as part of its full launch. The team is working on creating courses and is requesting feedback from community members on the <a href=\"https://make.wordpress.org/community/2020/10/23/learn-wordpress-course-planning/\">planned list of courses</a>.<br /><br />Want to contribute to Learn WordPress? You can now submit a <a href=\"https://learn.wordpress.org/workshop-presenter-application/\">workshop application</a> (submissions in non-English languages are welcome), apply to become a <a href=\"https://learn.wordpress.org/discussion-group-leader-application/\">discussion group leader</a>, organize <a href=\"https://make.wordpress.org/community/handbook/virtual-events/organize-learn-wordpress-discussion-groups-for-your-wordpress-meetup/\">discussions for your local WordPress meetup group</a>, or <a href=\"https://make.wordpress.org/training/2020/10/14/call-for-screenshots-contributors/\">update screenshots</a> on existing <a href=\"https://learn.wordpress.org/lesson-plans/\">lesson plans</a>.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>The <a href=\"https://make.wordpress.org/updates/2020/10/20/quarterly-updates-q3-2020/\">Q3 2020 update</a> from the WordPress project is now out!</li><li>The <a href=\"https://make.wordpress.org/marketing/\">WordPress Marketing team</a> has put together a list of <a href=\"https://github.com/wpmarketingteam/WP5.5\">WordPress 5.5 marketing resources</a> consisting of video presentations, slides, questions &amp; answers, social media posts, and more &#8211; aimed at both developers and non-developers. The team has also prepared a list of <a href=\"https://www.youtube.com/playlist?list=PLCVEqsAbLffcS1Rx-COZ5CZBOmXZJEe6k\">captioned screen-recordings</a> in several languages to aid new contributors. Contact the team on the <a href=\"https://wordpress.slack.com/archives/C0GKJ7TFA\">#marketing</a> channel if you would like to contribute to these and upcoming projects.&nbsp;</li><li>The <a href=\"https://make.wordpress.org/core\">WordPress Core team</a> has <a href=\"https://make.wordpress.org/core/2020/09/23/proposal-rest-api-authentication-application-passwords/\">announced a proposal</a> to introduce application passwords for REST API integrations.</li><li>Five online WordCamps took place in October: <a href=\"https://2020.rochester.wordcamp.org/\">WordCamp Rochester, NY</a>, <a href=\"https://austin.wordcamp.org/2020/\">WordCamp Austin, TX</a>, <a href=\"https://2020.italia.wordcamp.org/\">WordCamp Italia Online</a>, <a href=\"https://la.wordcamp.org/2020/\">WordCamp Los Angeles, CA</a>, and <a href=\"https://bulgaria.wordcamp.org/2020/\">WordCamp Bulgaria Online</a>. You can find livestream recaps of these camps on their websites. The camps are also in the process of uploading their videos to <a href=\"https://wordpress.tv/\">WordPress.tv</a>. Check out the <a href=\"https://central.wordcamp.org/schedule/\">WordCamp Schedule</a> to catch up with upcoming online WordCamps.</li><li>Contributor teams have started work on <a href=\"https://make.wordpress.org/core/2020/10/22/twenty-twenty-one-dark-mode-discussion/\">adding dark mode support for the Twenty Twenty One theme</a>. Additionally, the development of the <a href=\"https://make.wordpress.org/themes/2020/10/23/developing-the-full-site-editing-version-of-twenty-twenty-one/\">Full Site Editing version of Twenty Twenty One</a> has also kicked-off in the <a href=\"https://github.com/WordPress/theme-experiments/tree/master/twentytwentyone-blocks\">Theme Experiments GitHub repository</a>.</li><li><a href=\"https://buddypress.org/2020/10/buddypress-7-0-0-beta1/\">BuddyPress 7.0 beta</a>, which comes with new administration screens, blocks, and improved CLI support &#8211; is now available!&nbsp;</li><li>The Core team is <a href=\"https://make.wordpress.org/core/2020/10/06/revisiting-starter-content-on-org-and-beyond/\">revisiting starter content for WordPress themes</a> as part of the 5.6 release. The team also decided not to ship the widgets screen in WordPress 5.6 and have started discussions on <a href=\"https://make.wordpress.org/core/2020/10/29/discussion-align-the-wordpress-release-cycle-with-the-industry-standard/\">aligning the WordPress release cycle with industry standards</a>.</li><li>WordPress Accessibility enthusiasts all over the world joined hands for the first ever 24 hour <a href=\"https://wpaccessibilityday.org/\">WP Accessibility day</a> event on Oct. 2. You can find the recorded livestream of the event on its <a href=\"https://www.youtube.com/channel/UCes9XCUZd51CAigbBEGlfNg/featured?view_as=subscriber\">YouTube channel</a>.</li><li>The <a href=\"https://make.wordpress.org/meta\">Meta</a> team has <a href=\"https://make.wordpress.org/meta/2020/10/27/block-pattern-directory-ideas-and-discussion/\">kicked off a discussion</a> on setting up a <a href=\"https://developer.wordpress.org/block-editor/developers/block-api/block-patterns/\">Block pattern</a> directory (similar to the <a href=\"https://wordpress.org/support/article/block-directory/\">existing block directory</a>).&nbsp;</li><li>The <a href=\"https://make.wordpress.org/themes\">Themes</a> team has published a post clarifying <a href=\"https://make.wordpress.org/themes/2020/10/07/block-based-themes-and-wordpress-5-6/\">how Block based themes will work with WordPress 5.6</a>. Check out the <a href=\"https://developer.wordpress.org/block-editor/tutorials/block-based-themes/\">block-based theme tutorial</a> and its <a href=\"https://github.com/WordPress/gutenberg/blob/master/docs/designers-developers/developers/themes/block-based-themes.md\">documentation</a> to learn how to build block-based themes.&nbsp;</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Nov 2020 18:14:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"WPTavern: WordPress Auto-Update System Misfires, Updating Live Sites to an Alpha Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=107076\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:219:\"https://wptavern.com/wordpress-auto-update-system-misfires-updating-live-sites-to-an-alpha-release?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-auto-update-system-misfires-updating-live-sites-to-an-alpha-release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6634:\"<p>WordPress&rsquo; Core systems team had an eventful Friday when an error in the auto-update system caused sites to update to WordPress 5.5.3-alpha-49449, including live production sites with no auto-update constants defined. </p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">I just had a random production site auto-update itself to <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> 5.5.3-alpha &#128552; Anyone else seeing this?</p>&mdash; Mark Root-Wiley (@MRWweb) <a href=\"https://twitter.com/MRWweb/status/1322199942333526018?ref_src=twsrc%5Etfw\">October 30, 2020</a></blockquote>
</div>



<p>Those who received an email about the update logged into their sites to see the message:&nbsp;&ldquo;BETA TESTERS: This site is set up to install updates of future beta versions automatically.&rdquo;&nbsp;</p>



<p>Shaun Rieman logged the first ticket about <a href=\"https://core.trac.wordpress.org/ticket/51679\">sites being updated to 5.5.3-alpha-49449</a>, which was also incidentally his first WordPress trac ticket. More users and developers confirmed the issue.</p>



<p>&ldquo;It&rsquo;s worth noting that there&rsquo;s no functional difference between 5.5.2 and 5.5.3-alpha, so there&rsquo;s no need to worry in that regard,&rdquo; core committer John Blackbourn said. </p>



<p>Sites that were accidentally updated also installed all the default themes released over the last decade, as well as Akismet. Developers will need to manually delete the bundled themes that they don&rsquo;t need.</p>



<p>In under an hour, all affected sites were automatically returned to 5.5.2, but the incident has eroded trust and damaged confidence in the auto-update system. Several commenting on the ticket asked how they can explicitly disable development updates.</p>



<p>&ldquo;The worrying thing is that a single developer can do this, seemingly without any checking or confirmation by other developers,&rdquo; UK-based developer Paul Stenning said. &ldquo;This is a serious security concern as a rogue developer could push out malicious code in an update that nobody else checks.&rdquo;</p>



<p>WordPress agency owner Rob Migchels, who had approximately 50 websites affected, tracked 18 minutes between the the trac ticket (<a href=\"https://core.trac.wordpress.org/ticket/51679\">#51679</a>) and receiving the fix. </p>



<p>&ldquo;The 5.5.3-alpha issue is a side effect of another issue that occurred on 5.5.2,&rdquo; WordPress engineer and 5.6 Triage release lead Tonya Mork said. Jake Spurlock published an official statement regarding the incident as part of the <a href=\"https://wordpress.org/news/2020/10/wordpress-5-5-3-maintenance-release/\">5.5.3 release notes</a>:</p>



<blockquote class=\"wp-block-quote\"><p>&ldquo;Earlier today &mdash; between approximately 15:30 and 16:00 UTC &mdash; the auto-update system for WordPress updated some sites from version 5.5.2 to version 5.5.3-alpha. This auto-update was due to an error in the Updates API caused by the 5.5.3 release preparations.&rdquo;</p></blockquote>



<p>Spurlock elaborated on the <a href=\"https://make.wordpress.org/core/2020/10/30/wordpress-5-5-3-release-some-technical-details/\">technical details</a> in a separate post on the WordPress development blog:</p>



<blockquote class=\"wp-block-quote\"><p>While work was being done to prepare for WordPress 5.5.3, the release team attempted to make 5.5.2 unavailable for download on WordPress.org to limit the spread of the issue noted in the section above, as the error only affected fresh installations. This action resulted in some installations being updated to a pre-release &ldquo;5.5.3-alpha&rdquo; version.</p></blockquote>



<p>In a situation like this, where users who haven&rsquo;t elected to run their live sites on beta releases are getting a forced update, site owners might wonder whether this update is actually arriving from WordPress, or if the system has been hijacked. </p>



<p>Security researcher Slavco Mihajloski, who <a href=\"https://wptavern.com/loginizer-plugin-gets-forced-security-update-for-vulnerabilities-affecting-1-million-users\">commented</a> last week on the lack of transparency regarding how automatic updates are tested and performed, said this incident highlights the need for more openness surrounding the process.</p>



<p>&ldquo;Why is transparency important? Because procedure will become public and when public, the community will be able to contribute in order to improve it,&rdquo; Mihajloski said. &ldquo;At the moment it is more than obvious that this process and the whole security at WP.dot org lacks QA and QC. Each task is left to an individual or closed group. Imagine the following: what if an automatic security update could be pushed only if: &ndash; X out of Y (where X &lt; Y) authorities agree that update is fine &ndash; have a pilot update on let&rsquo;s say 100 different servers (I hope .org could afford this) where regression tests will be fired against each one. The current problems would not occur.&rdquo;</p>



<p>Automatic background updates for minor releases have saved developers thousands of hours in updating sites. A UI for allowing users to opt into automatic updates for major releases is on the roadmap for WordPress 5.6, expected in early December. </p>



<p>This particular accidental update has betrayed for many developers what was already a somewhat fragile trust in the auto-update system. It doesn&rsquo;t shore up more confidence for selling the idea of core updates when 5.6 is released, but it doesn&rsquo;t mean that auto-updates are not a good idea. WordPress.org will need to put better processes in place in order to win back users&rsquo; trust.</p>



<p>The incident affected more than 100 sites for WordPress agency owner Robert Staddon. He reports that they all displayed the &ldquo;Update now&rdquo; button with the confusing and incorrect text seen below. Staddon said the incident has not yet caused him to change his approach to allowing clients to receive auto-updates. </p>



<img />



<p>&ldquo;I was very grateful for the extraordinarily fast response time to get the problem fixed,&rdquo; Staddon said. &ldquo;However, it did shake my confidence in the WordPress auto-update process. Considering the number of websites using WordPress, a mistake of this magnitude could end up having a rather catastrophic effect around the web. I would hope that the core team would be able to evaluate how this happened and consider putting some checks in place to make sure it doesn&rsquo;t happen again.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Oct 2020 22:57:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Twenty Twenty-One Blocks Theme Launching as a Separate Project\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=107065\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:189:\"https://wptavern.com/twenty-twenty-one-blocks-theme-launching-as-a-separate-project?utm_source=rss&utm_medium=rss&utm_campaign=twenty-twenty-one-blocks-theme-launching-as-a-separate-project\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4519:\"<img />Twenty Twenty-One in the Gutenberg site editor.



<p class=\"has-drop-cap\">Last Friday, Themes Team representative Carolina Nymark announced the <a href=\"https://make.wordpress.org/themes/2020/10/23/developing-the-full-site-editing-version-of-twenty-twenty-one/\">Twenty Twenty-One Blocks </a>theme project. It is a block-based version of the Twenty Twenty-One default theme that is shipping along with WordPress 5.6. It will work with the site editor available in the Gutenberg plugin. Developers will work on the two themes as separate projects.</p>



<p>The original plan was to <a href=\"https://make.wordpress.org/core/2020/09/23/introducing-twenty-twenty-one/\">explore support for full-site editing</a> after the WordPress Beta 1 release for Twenty Twenty-One. Some had hoped that support would land in the theme itself. However, a second theme could be a better path in the long run.</p>



<p>As I wrote in my <a href=\"https://wptavern.com/first-look-at-twenty-twenty-one-wordpresss-upcoming-default-theme\">original coverage of Twenty Twenty-One</a>, it did not seem likely that full-site editing would be far enough along in development for it to be a primary feature for the theme. Since the feature will not be in WordPress 5.6, it makes sense to develop for it outside of the primary theme for the time being.</p>



<p>&ldquo;Twenty Twenty-One Blocks is an experimental theme created as an example to highlight what is possible with Full Site Editing,&rdquo; wrote Nymark in the announcement. &ldquo;The theme will need Gutenberg and the Full Site Editing experiment to be enabled. It will not be part of Core, but once complete it will be available in the theme directory.&rdquo;</p>



<p>Currently, there are no plans to integrate the two themes down the road. They will be maintained as separate projects. This sounds like a smart strategy for this theme. It will allow developers to work on the Blocks theme as a separate entity in the coming months without having to worry about potential problems with merging.</p>



<p>I am excited about this project because it means we get a somewhat official, though not technically a default, theme that supports full-site editing. Otherwise, the community would have had to wait another year for the Twenty Twenty-Two theme, which will presumably be 100% built with blocks.</p>



<p>The <a href=\"https://wptavern.com/q-first-fse-wordpress-theme-now-live\">Q theme</a> by Ari Stathopoulos, a Themes Team representative, is a little farther along at the moment. It is a solid starting point and learning tool. However, there should be a theme project coming from core WordPress developers that is leading the way for other theme authors. There is a sense of trust, particularly for first-time theme authors, when picking apart an officially-supported theme that it is built to current standards. That is why Twenty Twenty-One Blocks is important.</p>



<p>Thus far, little work has gone into the theme, much of it coming from the <a href=\"https://github.com/WordPress/theme-experiments/pull/57\">original pull request</a> to kick off development from Kjell Reigstad. The theme is currently stored in the WordPress <a href=\"https://github.com/WordPress/theme-experiments/tree/master/twentytwentyone-blocks\">Theme Experiments repository</a>. Ideally, the team will split this theme into its own GitHub repository since it will be added to the theme directory and not merely an experiment.</p>



<p>For theme authors who want to cut their teeth on building block-based themes, this would be a good place to begin taking those initial steps. Or, it will at least be a good project to follow because this is as close to an &ldquo;official&rdquo; theme that supports full-site editing that we will see for a while.</p>



<p>At this point, the theme does not do a lot. It is minimal and nowhere near a block-based equivalent of Twenty Twenty-One. However, it works as well as most other themes supporting Gutenberg&rsquo;s site editor.</p>



<p>For now, template parts do not seem to be working on the front end. However, template parts have been hit or miss in my tests for a while, sometimes seemingly working only by some randomly magical force that rears its head when I close in on the limits of my frustration &mdash; it will likely begin working immediately after publishing this post. That is often the nature of testing alpha-level software. Nevertheless, I am excited about following the development of this theme in the coming weeks and months.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Oct 2020 20:35:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"WordPress.org blog: WordPress 5.5.3 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9212\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2020/10/wordpress-5-5-3-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4116:\"<p>WordPress 5.5.3 is now available.&nbsp;</p>



<p>This maintenance release fixes an issue introduced in WordPress 5.5.2 which makes it impossible to install WordPress on a brand new website that does not have a database connection configured. This release does not affect sites where a database connection is already configured, for example, via one-click installers or an existing <code>wp-config.php</code> file.</p>



<h2>5.5.3-alpha Issue</h2>



<p>Earlier today &#8212; between approximately 15:30 and 16:00 UTC &#8212; the auto-update system for WordPress updated some sites from version 5.5.2 to version 5.5.3-alpha. This auto-update was due to an error in the Updates API caused by the 5.5.3 release preparations (<a href=\"https://wordpress.org/support/topic/wordpress-5-5-3-alpha-auto-updates/\">see more here</a>). The 5.5.3-alpha version at this point was functionally identical to 5.5.2 as no development work had been started on 5.5.3; however, the following changes may have been made to your site:</p>



<ul><li>The default “Twenty” themes installed as part of the pre-release package.</li><li>The “Akismet” plugin installed as part of the pre-release package.</li></ul>



<p>These themes and plugins were not activated and therefore remain non-functional unless you installed them previously. It is safe to delete these features should you prefer not to use them.&nbsp;</p>



<p>If you are not on 5.5.2, or have auto-updates for minor releases disabled, please manually update to the 5.5.3 version by downloading WordPress 5.5.3 or visiting Dashboard → Updates and click “Update Now.”</p>



<p>For more technical details of the issue, we’ve <a href=\"https://make.wordpress.org/core/2020/10/30/wordpress-5-5-3-release-some-technical-details/\">posted on our Core Development blog</a>.</p>



<h2>Thanks and props!</h2>



<p>Thanks to those who contributed to the 5.5.3 release: <a href=\"https://profiles.wordpress.org/audrasjb/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>audrasjb</a>, <a href=\"https://profiles.wordpress.org/barry/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>barry</a>, <a href=\"https://profiles.wordpress.org/chanthaboune/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>chanthaboune</a>, <a href=\"https://profiles.wordpress.org/cbringmann/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>cbringmann</a>, <a href=\"https://profiles.wordpress.org/clorith/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>clorith</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>davidbaumwald</a>, <a href=\"https://profiles.wordpress.org/desrosj/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>desrosj</a>, <a href=\"https://profiles.wordpress.org/hellofromtonya/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>hellofromtonya</a>, <a href=\"https://profiles.wordpress.org/jeffpaul/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>jeffpaul</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>johnbillion</a>, <a href=\"https://profiles.wordpress.org/garubi/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>garubi</a>, <a href=\"https://profiles.wordpress.org/metalandcoffee/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>metalandcoffee</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>mukesh27</a>, <a href=\"https://profiles.wordpress.org/otto42/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>otto42</a>, <a href=\"https://profiles.wordpress.org/punitsoftac/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>punitsoftac</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>sergeybiryukov</a>, <a href=\"https://profiles.wordpress.org/whyisjake/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>whyisjake</a>, and <a href=\"https://profiles.wordpress.org/xknown/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>xknown</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Oct 2020 20:25:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WordPress.org blog: WordPress 5.5.2 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9189\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2020/10/wordpress-5-5-2-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7222:\"<p>WordPress 5.5.2 is now available!</p>



<p>This security and maintenance release features <a href=\"https://core.trac.wordpress.org/query?milestone=5.5.2&group=component&col=id&col=summary&col=milestone&col=owner&col=type&col=status&col=priority&order=priority\">14 bug fixes</a> in addition to 10 security fixes. Because this is a <strong>security release</strong>, it is recommended that you update your sites immediately. All versions since WordPress 3.7 have also been updated.</p>



<p>WordPress 5.5.2 is a short-cycle security and maintenance release. The next major release will be version 5.6.</p>



<p>You can download WordPress 5.5.2 by downloading from WordPress.org, or visit your Dashboard → Updates and click Update Now.</p>



<p>If you have sites that support automatic background updates, they’ve already started the update process.</p>



<h3>Security Updates</h3>



<p>Ten security issues affect WordPress versions 5.5.1 and earlier. If you haven’t yet updated to 5.5, all WordPress versions since 3.7 have also been updated to fix the following security issues:</p>



<ul><li>Props to Alex Concha of the WordPress Security Team for their work in hardening deserialization requests.</li><li>Props to David Binovec on a fix to disable spam embeds from disabled sites on a multisite network.</li><li>Thanks to Marc Montas from Sucuri for reporting an issue that could lead to XSS from global variables.</li><li>Thanks to Justin Tran who reported an issue surrounding privilege escalation in XML-RPC. He also found and disclosed an issue around privilege escalation around post commenting via XML-RPC.</li><li>Props to Omar Ganiev who reported a method where a DoS attack could lead to RCE.</li><li>Thanks to Karim El Ouerghemmi from <a href=\"https://www.ripstech.com/\">RIPS</a> who disclosed a method to store XSS in post slugs.</li><li>Thanks to Slavco for reporting, and confirmation from Karim El Ouerghemmi, a method to bypass protected meta that could lead to arbitrary file deletion.</li><li>Thanks to Erwan LR from <a href=\"https://wpscan.com/\">WPScan</a> who responsibly disclosed a method that could lead to CSRF. </li><li>And a special thanks to <a href=\"https://profiles.wordpress.org/zieladam/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>zieladam</a> who was integral in many of the releases and patches during this release.</li></ul>



<p>Thank you to all of the reporters for <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">privately disclosing the vulnerabilities</a>. This gave the security team time to fix the vulnerabilities before WordPress sites could be attacked.</p>



<p>For more information, browse the <a href=\"https://core.trac.wordpress.org/query?milestone=5.5.2&group=component&col=id&col=summary&col=milestone&col=owner&col=type&col=status&col=priority&order=priority\">full list of changes</a> on Trac, or check out the <a href=\"https://wordpress.org/support/wordpress-version/version-5-5-2/\">version 5.5.2 HelpHub documentation page</a>.</p>



<h2>Thanks and props!</h2>



<p>The 5.5.2 release was led by <a href=\"https://profiles.wordpress.org/whyisjake/\">@whyisjake</a> and the following release squad: &nbsp;<a href=\"https://profiles.wordpress.org/audrasjb/\">@audrasjb</a>,&nbsp;<a href=\"https://profiles.wordpress.org/davidbaumwald/\">@davidbaumwald</a>,&nbsp;<a href=\"https://profiles.wordpress.org/desrosj/\">@desrosj</a>,&nbsp;<a href=\"https://profiles.wordpress.org/johnbillion/\">@johnbillion</a>, <a href=\"https://profile.wordpress.org/metalandcoffee\">@metalandcoffee</a>, <a href=\"https://profiles.wordpress.org/noisysocks\">@noisysocks</a>&nbsp;<a href=\"https://profiles.wordpress.org/planningwrite/\">@planningwrite</a>, <a href=\"https://profiles.wordpress.org/sarahricker/\">@sarahricker</a> and&nbsp;<a href=\"https://profiles.wordpress.org/sergeybiryukov/\">@sergeybiryukov</a>.</p>



<p>In addition to the security researchers and release squad members mentioned above, thank you to everyone who helped make WordPress 5.5.2 happen:</p>



<p><a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/xknown/\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/wpamitkumar/\">Amit Dudhat</a>, <a href=\"https://profiles.wordpress.org/rarst/\">Andrey &#8220;Rarst&#8221; Savchenko</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/ayeshrajans/\">Ayesh Karunaratne</a>, <a href=\"https://profiles.wordpress.org/bridgetwillard/\">bridgetwillard</a>, <a href=\"https://profiles.wordpress.org/talldanwp/\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/davisshaver/\">Davis Shaver</a>, <a href=\"https://profiles.wordpress.org/dd32/\">dd32</a>, <a href=\"https://profiles.wordpress.org/mista-flo/\">Florian TIAR</a>, <a href=\"https://profiles.wordpress.org/hareesh-pillai/\">Hareesh</a>, <a href=\"https://profiles.wordpress.org/hlashbrooke/\">Hugh Lashbrooke</a>, <a href=\"https://profiles.wordpress.org/iandunn/\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/igorradovanov/\">Igor Radovanov</a>, <a href=\"https://profiles.wordpress.org/whyisjake/\">Jake Spurlock</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/jb510/\">Jon Brown</a>, <a href=\"https://profiles.wordpress.org/joyously/\">Joy</a>, <a href=\"https://profiles.wordpress.org/jrf/\">Juliette Reinders Folmer</a>, <a href=\"https://profiles.wordpress.org/kellybleck/\">kellybleck</a>, <a href=\"https://profiles.wordpress.org/mailnew2ster/\">mailnew2ster</a>, <a href=\"https://profiles.wordpress.org/mkaz/\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/batmoo/\">Mohammad Jangda</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/paaljoachim/\">Paal Joachim Romdahl</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/regankhadgi/\">Regan Khadgi</a>, <a href=\"https://profiles.wordpress.org/noisysocks/\">Robert Anderson</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/yakimun/\">Sergey Yakimov</a>, <a href=\"https://profiles.wordpress.org/smub/\">Syed Balkhi</a>, <a href=\"https://profiles.wordpress.org/szaqal21/\">szaqal21</a>, <a href=\"https://profiles.wordpress.org/tellyworth/\">Tellyworth</a>, <a href=\"https://profiles.wordpress.org/sippis/\">Timi Wahalahti</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs/\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/itowhid06/\">Towhidul I. Chowdhury</a>, <a href=\"https://profiles.wordpress.org/vinayakanivase/\">Vinayak Anivase</a>, and <a href=\"https://profiles.wordpress.org/zieladam/\">zieladam</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Oct 2020 20:41:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Jb Audras\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: Log Into WordPress By Touch or Face ID Via the Passwordless WP Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106224\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:203:\"https://wptavern.com/log-into-wordpress-by-touch-or-face-id-via-the-passwordless-wp-plugin?utm_source=rss&utm_medium=rss&utm_campaign=log-into-wordpress-by-touch-or-face-id-via-the-passwordless-wp-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3722:\"<p class=\"has-drop-cap\">Last week, WP Busters released its first plugin titled <a href=\"https://wordpress.org/plugins/passwordless-wp/\">Passwordless WP</a>. It is a project from full-stack developer Ilya Zolotov that allows end-users to log into their WordPress websites via Touch ID, Face ID, or pin. The goal is to make accessing a site easier and more secure.</p>



<p>Zolotov built the plugin after checking his email on a public database and finding old passwords. He said he now uses a safe browser for work purposes without extensions and scripts. He also said the millions of credentials stolen or compromised every year was a motivator for building the plugin.</p>



<p>&ldquo;I like this feature of my laptop, and I am using it every day,&rdquo; he said. &ldquo;As well, I am using it to avoid entering the &lsquo;root&rsquo; password in terminal using my finger, it&rsquo;s comfortable and any sniffer can&rsquo;t capture my password.&rdquo;</p>



<p>Last year, he decided to check browser support for handling passwordless logins but was disappointed that Safari on iPhone only supported external USB keys at the time. He concluded that the technology was not ready yet.</p>



<p>&ldquo;In Apple&rsquo;s summer news, I saw the update: the platform authenticator would be available in iOS 14 and BigSur on Safari, and passwordless authentication is working in Chrome now. Also, Microsoft will release Windows Hello support. 2020 is the passwordless year. Awesome!&rdquo;</p>



<p>He then began work on developing the first version using stable cryptographic libraries and building a simple user experience. He believes the technology that allows this plugin to work will be widely supported from now on.</p>



<p>Zolotov assures users that it is a fast, secure, and certified protocol. The plugin does not store any personal data on the server or link to third-party services.</p>



<p>&ldquo;Other plugins which use SMS or Email to log in, send you code or link,&rdquo; he said when asked about how Passwordless WP differs from similar plugins. &ldquo;They make your life harder because you need to do more clicks &mdash; open email and link, unlock phone, etc. I prefer to enter a password using my manager, which uses my Touch ID.&rdquo;</p>



<p>Other plugins using the same technology do exist. <a href=\"https://wordpress.org/plugins/wp-webauthn/\">WP-WebAuthn</a>, for example, has a few additional features and has been around for about seven months.</p>



<h2>How Passwordless WP Works</h2>



<img />Logging into the site via fingerprint.



<p class=\"has-drop-cap\">The plugin requires HTTPS, unless in use in a localhost test environment. It also has a minimum requirement of PHP 7.2. Outside of that, it will work for any WordPress installation. Passwordless logins are handled on the user level, which means that each user on a WordPress site must register a token from their profile page.</p>



<p>The process is simple and takes only moments. Once on the register token screen, users merely need to click a button and choose the authentication method from their operating system.</p>



<img />Registering a token for a user account.



<p>From that point forward, when logging into the site, it is merely a matter of clicking on a username and using your Touch ID or Face ID to log in.</p>



<p>The following is a quick video of the plugin in action:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>My experience is with Google Chrome on Windows. The latest release, version 1.1.6, is working well. The previous version had an issue with a missing PHP extension in testing, but the plugin author fixed it quickly and sent out an update once I notified him of the problem.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Oct 2020 19:04:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: EditorPlus Introduces Its First Blocks and Adds a Custom Block Creator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106470\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:205:\"https://wptavern.com/editorplus-introduces-its-first-blocks-and-adds-a-custom-block-creator?utm_source=rss&utm_medium=rss&utm_campaign=editorplus-introduces-its-first-blocks-and-adds-a-custom-block-creator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7433:\"<p class=\"has-drop-cap\">In what seems to be a never-ending onslaught of new features, Munir Kamal has released some major new features to his <a href=\"https://wordpress.org/plugins/editorplus\">EditorPlus</a> plugin in the last two updates. Version 2.0, which landed earlier today, includes a set of <a href=\"https://gutenberghub.com/gutenberg-blocks-by-editorplus/\">seven new blocks</a>. The previous release showcased a <a href=\"https://gutenberghub.com/how-to-create-a-custom-wordpress-editor-block/\"><em>create-a-block</em> feature</a> that puts more customization options in the hands of end-users.</p>



<p>The block editor has fueled his creativity, and he has not run out of ideas for his block-sharing website GutenbergHub or EditorPlus plugin. Upcoming releases should see an overhaul of the UI for the plugin and a possible API for third-party developers.</p>



<p>He said he will be making sure that EditorPlus is working alongside WordPress&rsquo;s site editor when it lands in the future. Plus, eventual support of WooCommerce&rsquo;s blocks is on the table. For now, the focus is on the plugin features he has launched in recent weeks.</p>



<h2>Creating Custom Blocks</h2>



<p class=\"has-drop-cap\">With WordPress&rsquo;s core set of blocks already in the hands of users, nearly anything is already possible. These blocks essentially cover all the foundational elements of web design, such as headings, paragraphs, lists, quotes, and more. Sometimes the trick to building something unique is mixing and matching these elements to create something new. That is essentially what this new create-a-block feature is for EditorPlus.</p>



<p>Saving a custom block is simple. Users must first wrap their blocks into a core Group block. Then, from the &ldquo;more options&rdquo; menu in the block toolbar, select the &ldquo;Add to Custom Blocks&rdquo; option. The plugin will ask for a block title before saving.</p>



<img />Saving a custom block.



<p>Not to be confused with reusable blocks, which are resources that remain the same from post to post, created blocks are like any other blocks. They are accessible via the block inserter under the &ldquo;My Custom Blocks&rdquo; category.</p>



<img />Custom blocks available from the block inserter.



<p>A couple of minor details are missing that would be great additions for the long term. The first is the ability to select a custom icon for the block. Currently, all custom blocks share an icon. The second is the ability to add a preview in the block inserter.</p>



<p>Kamal built this feature so that end-users could create simple blocks for themselves. It is also a tool for developers to quickly create blocks for client websites.</p>



<p>&ldquo;For example, almost all business websites need a Testimonial block, but there is not one in core for that exact purpose,&rdquo; he said. &ldquo;Of course, you can create it using the combination of core blocks, and that&rsquo;s the way to do it. I&rsquo;ve seen many block plugins bringing such blocks like Testimonial, Team, Pricing, etc., but those can be easily created with core blocks.&rdquo;</p>



<p>He has already shown the community how far you can stretch the core blocks to create unique layouts with his <a href=\"https://wptavern.com/copy-and-paste-editor-blocks-via-gutenberghubs-block-library\">block</a> and <a href=\"https://wptavern.com/gutenberg-hub-launches-landing-page-templates-directory\">template</a> libraries. So, it is not outside the realm of possibility that users could build some of these things directly from the editor.</p>



<p>The block creator seems like it would be better handled as a block <strong>pattern</strong> creator. In essence, users are creating custom patterns, which are groupings of blocks. Kamal said that a pattern creator is on the to-do list too.</p>



<p>&ldquo;As Gutenberg has both these pieces to use for creating content/layouts, I will add both features,&rdquo; he said. &ldquo;Save as block has been added, &lsquo;save as pattern&rsquo; will be added too. It will be up to the user to use whatever way they want to according to their workflow.&rdquo;</p>



<p>I lean toward sticking with the existing pattern paradigm, a single feature that handles groups of blocks. However, it will be interesting to see what users prefer. In the long run, what matters most is that they have easy access to the tools they need to build their pages.</p>



<h2>The &ldquo;Missing&rdquo; Blocks</h2>



<img />Using the Progress Bar block in the editor.



<p class=\"has-drop-cap\">Earlier today, Kamal released what he calls the &ldquo;missing&rdquo; blocks for WordPress. These are a set of seven custom-built blocks that handle types of content not possible with the existing core blocks. In the past, he has been hesitant to create any blocks, preferring to extend the tools that WordPress provided out of the box.</p>



<p>&ldquo;My original idea and still is to extend Gutenberg for what is missing and to make it more powerful for creating beautiful designs visually without code,&rdquo; he said. &ldquo;And, after creating hundreds of templates/designs, I&rsquo;ve realized a need for some important missing blocks that are most commonly used around the website builders but missing in Gutenberg. So I am only adding those blocks in EditorPlus that are missing, must be needed to create modern designs, and can not be created using a combination of core blocks easily. For example, a tabs block, accordion block, or all other blocks added are those that fit these criteria.&rdquo;</p>



<p>The plugin includes the following new blocks:</p>



<ul><li>Tabs</li><li>Toggle/Accordion</li><li>Icon</li><li>Rating</li><li>Progress Bar</li><li>Stats/Counter</li><li>Countdown Timer</li></ul>



<p>Some of these require additional JavaScript, which is why they do not make good candidates for core WordPress. However, they are good options for plugin developers, and these are not uncommon blocks from other library-type plugins.</p>



<p>The thing that sets them apart is the integration with the plugin&rsquo;s styling system, which Kamal may be opening up to other plugin developers in a future release. The current plan is to create an independent Styles API for letting users customize any block. He has already <a href=\"https://www.facebook.com/groups/advancedwp/permalink/3597620730300115\">gotten some feedback</a> from the Advanced WP Facebook group on the idea. Much of the feedback is wishing that such a system would land in WordPress itself.</p>



<p>One interesting feature of the plugin&rsquo;s new blocks is that when clicking on a sub-element of a block, its design options are automatically triggered in the block options panel. For example, the star rating block has &ldquo;title&rdquo; and &ldquo;rating&rdquo; elements. When clicking on the title, its design options open in the sidebar, and the same happens for ratings. This is a departure from the typical organization of EditorPlus&rsquo;s design options on the core blocks, which are grouped by CSS properties. The focus is put on the individual element, and it makes it much easier to find a specific option.</p>



<p>This experimentation is a bit of a precursor to what Kamal is working on for a future update. One of his big goals is to do some cleanup of the UI &mdash; there are a lot of options in the plugin &mdash; and let users more quickly customize their blocks.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Oct 2020 21:08:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: WordPress Contributors Discuss Launching an Official Block Pattern Directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106892\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/wordpress-contributors-discuss-launching-an-official-block-pattern-directory?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-contributors-discuss-launching-an-official-block-pattern-directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5577:\"<p><a href=\"https://developer.wordpress.org/block-editor/developers/block-api/block-patterns/\">Block patterns</a> were one of the most exciting and transformative features introduced in <a href=\"https://wptavern.com/wordpress-5-5-eckstine-introduces-block-directory-block-patterns-and-automatic-updates-for-themes-and-plugins\">WordPress. 5.5</a>, giving users a giant head start on building pages by allowing them to insert sets of pre-designed blocks. Core now includes a handful of default patterns available in the block inserter but contributors are exploring the idea of expanding this small selection into a full-blown pattern directory. </p>



<p>Alex Shiels opened a <a href=\"https://make.wordpress.org/meta/2020/10/27/block-pattern-directory-ideas-and-discussion/\">discussion</a> on make.wordpress.org to get feedback on how it might be implemented. He suggested that the pattern directory would be similar to the block directory, minus the need to install plugins in the background. Community-contributed patterns could be searched and added via one-click installation from the block inserter.</p>



<p>Shiels asked for feedback on several questions, such as how block patterns could be represented in search results and how previews could accurately reflect how a pattern might appear with different themes. One of the most important considerations he raised: <em>Should the Block Pattern Directory be limited to patterns using only core blocks?</em></p>



<p>If patterns can only contain core blocks, that leaves it to third-party markets to provide patterns that include blocks from plugins. It seems more likely that block plugin developers would opt to ship their own selection of patterns inside their plugins, instead of contributing to the pattern directory. Having it open to all blocks hosted in the directory would encourage a more diverse range of patterns. Patterns requiring a non-core block might include a prompt to download it.</p>



<p>The WordPress community has already created many different unofficial pattern libraries, although the terminology can be confusing. Gutenberg Hub&rsquo;s <a href=\"https://gutenberghub.com/templates/\">template library</a> may be one of the most prominent. It provides section patterns and full page templates that users can browse and then copy the code to paste into their own sites. Jeffrey Carandang&rsquo;s &ldquo;<a href=\"https://shareablock.com/blocks/category/block-patterns/\">Share-a-Block&rdquo;</a> site also offers a selection of patterns to download.</p>



<img />



<p>WordPress.com has just <a href=\"https://wordpress.com/blog/2020/10/28/introducing-patterns/\">launched</a> its own pattern library today with more than 100 patterns pre-designed patterns available. Automattic plans to add more patterns based on user feedback and requests. This new free library will make site building easier for millions of users and also creates a strong incentive for using the block editor.</p>



<div class=\"wp-block-embed__wrapper\">
<a href=\"https://cloudup.com/cNbSASbRH10\"><img src=\"https://cldup.com/TjpGkbXaLl.gif\" alt=\"Wpcom pattern library\" width=\"1277\" height=\"1139\" /></a>
</div>



<p>Patterns leverage all the best things about the new editor. Inserting a pattern is easier than wrangling shortcodes or wading through theme options to try to get the right combination to reproduce the demo. Patterns are more approachable than page builders and don&rsquo;t require learning a new interface.</p>



<p>As the momentum around block patterns increases, I think we will see more commercial theme and block plugin creators using patterns to showcase their products and provide starter packs. It is the best way to help users understand the wide range of possibilities that the block editor enables.</p>



<p>Having an official directory of community-contributed patterns could be an interesting way for creators to cross-promote their free blocks and designs, while opening up a whole new world of design options for self-hosted WordPress users. How many times have you been shopping around for just the right WordPress theme and found that you like certain sections and layouts offered in several different themes? Patterns give you the ability to cherry pick different sections to create your own unique layout for each page/post, without having to wrestle with the limitations of your theme.  </p>



<p>The ability to browse and access community-contributed patterns directly within the editing interface may have a long list of technical challenges to solve, but it would undoubtedly put more design power into users&rsquo; hands. </p>



<p>Not everyone can take a blank canvas and artfully combine blocks to produce sophisticated designs. Putting patterns at users&rsquo; fingertips would make site building more of a delight, especially for users who are new to the block editor. It might also allow users to save their favorite patterns for future use, in the same way you can save your favorite themes and plugins.</p>



<p>The <a href=\"https://make.wordpress.org/meta/2020/10/27/block-pattern-directory-ideas-and-discussion/\">discussion</a> on WordPress.org is just getting underway. A few of the original contributors on the idea have created a <a href=\"https://github.com/WordPress/pattern-directory\">GitHub repository</a> to track and explore some of the more technical considerations&nbsp;of launching an official block patterns directory. If you have ideas to contribute on how this could be implemented or want to share other considerations, make sure to comment on the post.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Oct 2020 19:12:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:144:\"HeroPress: A Life Changing Journey With WordPress – जीवन में मिले रंग वर्डप्रेस के संग\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=3394\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"https://heropress.com/essays/a-life-changing-journey-with-wordpress/#utm_source=rss&utm_medium=rss&utm_campaign=a-life-changing-journey-with-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:24657:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2020/10/pooja_banner.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: A Life Changing Journey With WordPress\" /><p><a href=\"https://heropress.com/feed/#hindi\">वर्डप्रेसने मुझे मेरे ज़िंदगी में कुछ अलग करने का मौक़ा दिया।</a></p>
<p>One fine day, I was checking my Twitter account and suddenly, got a message from HeroPress. I was astonished after getting a message from such a huge platform. I got to share a lot with Topher while having a long chat session with him. He then asked me to write an article for HeroPress.</p>
<p>It took me a while to think about what to write as writing about technical never excites me that much. Soon, I realized that what&#8217;s better than writing my own story and telling the story about how an introvert girl from a small village of India chased her dreams and gave a direction to her life.</p>
<h3>Early Life</h3>
<p>I was born in Banera, a small village in India. After completing my primary education there, I moved to my uncle&#8217;s place in a nearby city for higher education. There I decided to become an engineer. Being from a rural background, people in my village refuse the idea of sending their girl child to another city for further studies. Fortunately, that was not the case with me because my parents are immensely supportive and loving. They&#8217;ve always encouraged me to believe in myself and fulfil my dreams. With their support, I pursued my engineering in Electronics &amp; Communication, and yes, that&#8217;s an entirely different field looking at my current profile.</p>
<h3>Introduction to Web Development</h3>
<p>Although I did my engineering in Electronics and Communication, I was not sure about having a future in this field. I was completely blank about my career and had no clue of what to do next. First, I thought about doing masters, but I was already tired of studying all those subjects. I applied for jobs, but there was no success. That was when one of my friends suggested that I should explore Web Development. The idea interested me, and then I started looking for some learning resources. Later I got an Internship as a PHP Developer. It was an unpaid internship, but still, I did it because I thought it would be an excellent opportunity to learn with real professionals.</p>
<h3>Getting Started with WordPress</h3>
<p>After doing the internship for three months, I got my first job. Before knowing WordPress, I got the chance to explore many CMS. I&#8217;d worked on Joomla, Magento and ExpressionEngine. Then my boss assigned me a small project on WordPress. At first glance, I found it very interesting. I found it surpassing and much better as compared to the other platforms I&#8217;ve worked on earlier. Its vast knowledge base made it easy for me to learn. I soon got comfortable managing WordPress, playing with plugins and themes, and started exploring it more in-depth.</p>
<p>There comes the next phase of my life. I was about to get married to Anand. He was in the same field as mine, and this helped me gain more confidence to pursue my interest. During our courtship period in 2015, he left his job and started his WordPress based Web Development Agency &#8211; WPVibes. Soon we got married, and I joined him as the first team member of WPVibes. Being part of a new startup gave me a lot of experience. I got to be involved in new processes. We started with Web Development, and soon we began exploring opportunities in plugin development. We started providing custom plugin development services as per the client&#8217;s requirement and created some free and paid plugins. We found it much more exciting and productive. Today, WPVibes is a team of 10 members.</p>
<h3>Interaction with WordPress Community</h3>
<p>I started following some WordPress based groups on Facebook, and there I got to know about WordCamps. Soon I got the opportunity to attend my first WordCamp &#8211; WordCamp Ahmedabad. There I learned how amazing WordPress Community is. WordCamp Ahmedabad has one of the best WordPress communities in India, and everyone, including organizers, attendees were so humble and welcoming. There I listened to speakers from India and abroad. Some of them shared how they got into WordPress and how WordPress has changed their lives. One of the most inspiring sessions was by Rahul Bansal. He talked about contributing to WordPress and giving back to the community. He also explained how contributing to WordPress can help you to enhance your knowledge. It inspired me to contribute to WordPress. At that time, I couldn&#8217;t manage to get involved with WordPress due to my busy schedule. The WordPress community of Ahmedabad immensely inspired us. Later, we started a WordPress meetup group in our city &#8211; Ajmer and found it a way to contribute to the community.</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/10/image3.png\"><img /></a></p>
<p>In the next WordCamp, I also attended the contribution day. Most of the contributors were inclined to contribute to Core, but I decided to choose a different path. I joined the team of WordPress TV Contributors.</p>
<p>WordPress TV is a platform where you can explore videos of WordCamp sessions. You can learn more about it here, <a href=\"https://make.wordpress.org/tv/\">https://make.wordpress.org/tv/</a>.</p>
<p>Then I started contributing to WordPress Training. WordPress Training team manages the lesson plans and prepares content to educate people about building stuff for WordPress. The training team has recently launched a new platform for learning WordPress <a href=\"https://learn.wordpress.org/\">https://learn.wordpress.org/</a> (I am a proud contributor to this platform)</p>
<p>The year 2019 came with an exciting moment in my life. I got selected as a Volunteer for WordCamp Asia in Bangkok, Thailand. This was the very first edition of WordCamp Asia. After this, I got more involved with the community. I was very excited about playing this big role, attending my first WordCamp outside India, and that too, by being a part of the volunteering team. But due to the Covid pandemic, the event got cancelled. It was quite heartbreaking. Since all bookings were already made, we (me and my husband) didn&#8217;t cancel the trip and enjoyed a vacation to Thailand.</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/10/image1.png\"><img /></a></p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/10/image2.png\"><img /></a></p>
<h3>My message to WordPress Community</h3>
<p>What I have learnt in my life is it doesn&#8217;t matter from where you come and what background you have. All that matters is your hard work and positive attitude towards life.</p>
<p>I have a message for all the WordPress lovers and also for those who are starting with WordPress. There is a huge community to help you with your learning, so start learning and try to give back to the community. It doesn&#8217;t matter if you are not comfortable with programming; there are many different ways in which you can contribute.</p>
<p>Jai WordPress!</p>
<hr />
<h1 id=\"hindi\">जीवन में मिले रंग वर्डप्रेस के संग</h1>
<p>उस दिन मैं अपना ट्विटर अकाउंट देख रही थी की तभी मुझे हीरो प्रेस की तरफ से एक संदेश आया| उसे देख कर अचम्भित रह गयी| मैं हीरोप्रेस पे बहुत से लेख पढ़ चुकी थी, तो ऐसे में अचानक से उसकी ओर से संदेश आने पर मेरा अचम्भित होना स्वाभाविक ही था| उसके बाद मेरी Topher (हीरो प्रेस के संस्थापक ) से लंबी बातचीत हुई और उसके बाद उन्होंने मुझे मेरा लेख लिखने के लिए कहा और साथ ही यह अनुरोध भी किया की मैं अपने लेख को अपनी मातृभाषा हिंदी में भी लिखुँ|</p>
<p>मुझे ये तय करने में काफी समय लगा की में इसमें क्या लिखूं| तकनीकी लेख लिखने में मेरी ख़ास रूचि नहीं थी| फिर मुझे लगा की क्यों ना इसमें खुद की कहानी ही लिखी जाए| लिखा जाए की कैसे भारत के एक छोटे से गाँव की एक अंतर्मुखी लड़की ने अपने सपनों को पूरा किया और अपने जीवन को एक दिशा दी|</p>
<h3>प्रारंभिक जीवन</h3>
<p>मेरा जन्म भारत के एक छोटे से गाँव बनेड़ा में हुआ था| मेरी प्रारंभिक शिक्षा वहीँ हुई| चूँकि हमारे गाँव में उच्च शिक्षा की कोई सुविधा नहीं थी अतः उसके लिए मुझे पास ही के शहर में</p>
<p>अपने ताऊजी के पास रहना पड़ा| उसके बाद मैने इंजीनियरिंग करने का विचार बनाया, परन्तु उसके लिए मुझे फिर किसी और शहर में जाना पड़ता| उस समय के ग्रामीण परिवेश में पढ़ाई के लिए ज्यादा दूर भेजने को सही नहीं माना जाता था, और वो भी खासकर जब बात एक लड़की की हो|</p>
<p>परन्तु मेरे मामले में मुझे मेरे माता पिता का पूरा सहयोग प्राप्त था| उन्होंने हमेशा ही मुझे आगे बढ़ने और अपने सपनों को पूरा करने के लिए प्रोत्साहित किया| उनके सहयोग से ही मैंने इलेक्ट्रॉनिक्स एंड कम्युनिकेशन (Electronics &amp; Communication Engineering ) में इंजीनियरिंग करी| जी हाँ, ये मेरे वर्तमान कार्य क्षेत्र से पूर्णता भिन्न था|</p>
<h3>वेबसाइट डवलपमेंट से मेरा परिचय</h3>
<p>जैसा की मैंने बताया की मैंने इंजीनियरिंग बिलकुल ही अलग क्षेत्र में करी थी| मैंने कभी सपने में भी नहीं सोचा था कि सेमीकंडक्टर और सर्किट की पढ़ाई करने के बाद मैं वेबसाइट बनाउंगी| पर वक्त को शायद यही मंज़ूर था| इंजीनियरिंग पूरी करने के बाद मेरे पास २ विकल्प थे, आगे की पढ़ाई (M.Tech) करूँ या फिर नौकरी की तलाश करूँ| आगे पड़ने का मेरा मन नहीं था, तो मैंने नौकरी करना ही सही समझा| परन्तु काफी प्रयास के बाद भी मुझे कोई मनमाफिक नौकरी नहीं मिली|</p>
<p>ऐसे में मेरी एक सहेली ने मुझे वेबसाइट डेवलपमेंट में हाथ आजमाने की राय दी| कॉलेज के दिनों में मैंने थोड़ी PHP और HTML, CSS पढ़ी थी, तो मैंने उसी को और गहराई से समझना शुरू किया, कुछ कोर्स भी करे| मुझे जल्द ही PHP डेवलपर के तौर पर एक इंटर्नशिप मिल गयी| इसमें मुझे कोई वेतन नहीं मिलने वाला था, पर मुझे विश्वास था कि किसी कोर्स के बजाय ये एक बेहतर मौका है कुछ सीखने का|</p>
<h3>वर्डप्रेस से मेरा जुड़ाव</h3>
<p>३ महीने की इंटर्नशिप के बाद मुझे एक नौकरी मिल गयी| वहां वर्डप्रेस पर काम करने से पहले मैंने कई दूसरे CMS पर भी काम किया, जैसे कि Joomla, Magento, Expression Engine आदि| फिर कुछ समय बाद एक प्रोजेक्ट में वर्डप्रेस पर काम करने का मौका मिला| मुझे ये काफी ज्यादा दिलचस्प लगा| इससे पहले मैंने जिन CMS पर काम किया था, उनके मुकाबले यह बेहद सुलझा हुआ लगा| इसके बारे में जो जानकारी चाहिए वो आसानी से इंटरनेट पर उपलब्ध थी जिससे मुझे इसको सीखने में बिलकुल भी कठिनाई नहीं हुई| धीरे-धीरे वर्डप्रेस चलाने में, Plugins और Themes का उपयोग करने में मेरा आत्मविश्वास बढ़ता ही गया और मैं इन सबको और भी गहराई से सीखती गयी|</p>
<p>इसके बाद मेरे जीवन का एक अगला पड़ाव आया &#8211; शादी| नवम्बर २०१५ में मेरी शादी आनन्द से हुई|</p>
<p>वह भी वेबसाइट डेवलपमेंट के क्षेत्र में ही काम कर रहा था और इससे मुझे मेरा रुचिकर काम जारी रखने में कोई भी दिक्कत नहीं हुई| हमारी शादी के कुछ समय पहले ही आनन्द ने नौकरी छोड़कर अपनी खुद की वेब डेवलपमेंट कंपनी (WPVibes) शुरू करी| इसमें भी मुख्यतः काम वर्डप्रेस पर ही था| शादी के बाद मैँ भी पहली टीम मेंबर के तौर पर कंपनी से जुड़ गयी| एक बिलकुल ही नयी कंपनी से जुड़ना एक अलग ही अनुभव होता है| आपको कई ऐसी चीजें सीखने को मिलती है जो आप एक बड़ी स्थापित कंपनी में काम करके नहीं सीख सकते| शुरुआत में हम वेबसाइट ही बनाते थे, पर जल्द ही हमने Plugin डवलपमेंट में भी संभावनाएँ तलाशना शुरू किया| हमारी क्षमता को देखते हुए यह हमें ज्यादा रोमांचक और उत्पादक लगा|</p>
<h3>वर्डप्रेस कम्युनिटी और मैं</h3>
<p>मैं फेसबुक पर वर्डप्रेस से संबंधित कुछ ग्रुप से जुड़ी| यहाँ मुझे बहुत कुछ सीखने को मिला और मुझे वर्डकेम्प (WordCamp) के बारे में भी पता पड़ा| जल्द ही मुझे मेरे पहले वर्डकेम्प &#8211; वर्डकेम्प अहमदाबाद में भाग लेने का मौका मिला| यहाँ मुझे एहसास हुआ की वर्डप्रेस समुदाय (community ) कितना जबर्दस्त है| वर्डकेम्प अहमदाबाद, भारत में होने वाले श्रेष्ठ वर्डकेम्प में से एक है|</p>
<p>यहाँ मैंने देश विदेश से आये हुए कई लोगों के वक्तव्य सुने| इनमें से सबसे ज्यादा प्रेरणादायक राहुल बंसल का वक्तव्य लगा, जिसमे उन्होंने वर्डप्रेस समुदाय को अपनी ओर से कुछ वापिस देने के बारे में (Give Back to the Community) चर्चा करी| उन्होंने यह भी बताया की किस तरह वर्डप्रेस में योगदान करना आपके लिए ज्ञानवर्धक भी साबित हो सकता है| इससे मुझे वर्डप्रेस में अपना योगदान देने की प्रेरणा मिली| हालांकि किसी कारण वश उस समय में वर्डकेम्प के Contribution Day में भाग नहीं ले पायी थी| वहां की वर्डप्रेस समुदाय से प्रेरित होकर हमने हमारे शहर अजमेर में भी वर्डप्रेस मीटअप (Meetup) की शुरुआत करी और लोगो को वर्डप्रेस से जुड़ने और इसके बारे में जानकारी देना शुरू करा| यह भी वर्डप्रेस में अपना योगदान (contribute) देने का ही एक माध्यम है|</p>
<p>अगले वर्डकेम्प में मैंने Contribution Day में भी भाग लिया| ज्यादातर योगदानकर्ताओं (Contributors) का झुकाव Core की तरफ रहता है, ऐसे में मैंने कुछ हटकर करने की सोची और वर्डकेम्प टीवी (WordPress TV) में योगदान करने के बारे में सीखा| वर्डप्रेस टीवी एक वेबसाइट है जहाँ आप पूरी दुनिया के वर्डकेम्प से जुड़े वीडियो देख सकते हैं| इसके बारे में अधिक जानकारी के लिए आप यहाँ देख सकते हैं <a href=\"https://make.wordpress.org/tv/\">https://make.wordpress.org/tv/</a></p>
<p>इसके बाद मैंने वर्डप्रेस ट्रेनिंग (WordPress Training) में भी योगदान करना शुरू करा| वर्डप्रेस ट्रेनिंग की टीम वर्डप्रेस के बारे में जागरूक और शिक्षित करने के लिए पाठ्य सामग्री तैयार करती है|</p>
<p>हाल ही में शुरू करी गयी एक वेबसाइट <a href=\"https://learn.wordpress.org/\">https://learn.wordpress.org/</a> में भी मेरा छोटा सा योगदान हैं|</p>
<p>वर्ष २०१९ मेरे लिए एक बहुत ही अच्छा मौका लेकर आया| मेरा चयन पहली बार होने वाले वर्डकेम्प एशिया २०२० (WordCamp Asia 2020) में वालंटियर के तौर पर हुआ| इसका आयोजन बैंकाक (थाईलैंड) में होने वाला था| मैं इसे लेकर काफी उत्साहित थी| ये भारत के बाहर किसी वर्डकेम्प में भाग लेने का मेरा पहले मौका था और वो भी एक वालंटियर की तरह| परन्तु कोरोना महामारी के कारण ये मात्र एक सपना ही रह गया| इसके आयोजन के कुछ दिन पहले ही इसे रद्द कर दिया गया|</p>
<p>फिर भी मैंने मेरी यात्रा रद्द नहीं करी और आनन्द के साथ थाईलैंड में कुछ दिनों की छुट्टियों के मजे लिये|</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/10/image1.png\"><img /></a></p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/10/image2.png\"><img /></a></p>
<h3>वर्डप्रेस समुदाय के लिए मेरा संदेश</h3>
<p>मैंने अपने अभी तक के जीवन से यही सीखा है की इससे कोई फर्क नहीं पड़ता की आप कहाँ से आये हैं और क्या आपकी पृष्ठभूमि रही है| यदि आप मेहनत कर सकते है और एक सकारात्मक सोच रखते है तो आप अपने रास्ते खुद बना सकते हैं|</p>
<p>सभी वर्डप्रेस के चाहने वालो और खासकर उनके लिए जो अभी वर्डप्रेस से जुड़े हैं या जुड़ना चाहते हैं उनसे मेरा यही कहना है की आगे बढ़े, आपकी मदद के लिए एक बहुत ही बड़ा समुदाय (community) है| तो भी शुरू करें और जब भी हो किसी भी तरह से अपना भी योगदान देने की कोशिश करें| जरूरी नहीं की आपको प्रोग्रामिंग आती हो, अगर आप अपने एक मित्र को वर्डप्रेस के बारे में बताते है या सिखाते हैं तो ये भी एक तरह का योगदान ही है|</p>
<p>जय वर्डप्रेस !</p>
<p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/a-life-changing-journey-with-wordpress/\">A Life Changing Journey With WordPress &#8211; जीवन में मिले रंग वर्डप्रेस के संग</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Oct 2020 02:31:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Pooja Derashri\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WordPress.org blog: Take the 2020 WordPress Annual Survey (and view the 2019 results)!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://wordpress.org/news/2020/10/take-the-2020-wordpress-annual-survey-and-view-the-2019-results/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7275:\"<p>For many years, WordPress enthusiasts have filled out an annual survey to share their experiences and feelings about WordPress. Interesting results from this survey have been shared in the annual<a href=\"https://wordpress.tv/tag/state-of-the-word/\"> State of the Word</a> address and/or here on WordPress News.&nbsp;</p>



<p>This survey helps those who build WordPress understand more about how the software is used, and by whom. The survey also helps leaders in the WordPress open source project learn more about our contributors&#8217; experience<a href=\"https://make.wordpress.org/\"></a>. &nbsp;</p>



<p>To ensure that <strong>your</strong> WordPress experience is represented in the 2020 survey results,</p>



<div class=\"wp-block-buttons aligncenter\">
<div class=\"wp-block-button is-style-fill\"><a class=\"wp-block-button__link has-vivid-cyan-blue-background-color has-background\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-english\" target=\"_blank\" rel=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-english noopener\">Take the 2020 Annual Survey! (English)</a></div>
</div>



<p>You can also take the survey in <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-french\">French</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-german\">German</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-japanese\">Japanese</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-russian\">Russian</a>, and <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-spanish\">Spanish</a>! The survey will be open for at least 6 weeks, and results will be posted on this blog.</p>



<h1>2019 Survey Results</h1>



<div class=\"wp-block-buttons aligncenter\">
<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-vivid-cyan-blue-background-color has-text-color has-background\" href=\"https://docs.google.com/presentation/d/1FI7eEvSB5SHTSILIBpwOmH9rBffgD6mFnnqSkrEScYo/edit\" target=\"_blank\" rel=\"https://docs.google.com/presentation/d/1fi7eevsb5shtsilibpwomh9rbffgd6mfnnqskrescyo/edit#slide=id.g71a4c4edc6_3_232 noopener\">View the 2019 Survey Results (Slides)</a></div>



<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link has-white-color has-vivid-cyan-blue-background-color has-text-color has-background\" href=\"https://www.dropbox.com/sh/bq62sficymopgos/AAA-wx73cDviVG84NSCTgjNDa?dl=0\" rel=\"https://www.dropbox.com/sh/bq62sficymopgos/aaa-wx73cdvivg84nsctgjnda?dl=0\">Download the 2019 Survey Results (PDF or PPT)</a></div>
</div>



<p>The 2019 survey included some new questions to better understand why people continue to use WordPress as their preferred CMS, as well as a section directed toward WordPress contributors. For the first time in 2019, this survey was translated into 5 different languages: French, German, Japanese, Russian, and Spanish.</p>



<p>The first WordPress Contributor Survey was conducted in 2015, but unfortunately the results were never published. This report includes Contributor Survey results from both 2015 and 2019.&nbsp; </p>



<h2>Survey Segments</h2>



<p>Major groups in the survey included: WordPress Professionals, WordPress Users, and Others.&nbsp;</p>



<p>The <strong>WordPress Professionals</strong> group consists of those who: work for a company that designs/develops websites; use WordPress to build websites and/or blogs for others; design or develop themes, plugins, or other custom tools for WordPress sites; or are a designer, developer, or other web professional working with WordPress.</p>



<p>This WordPress Professionals group is further divided into <strong>WordPress Company Pros</strong> (those who work for a company that designs/develops websites) and <strong>WordPress Freelancers/Hobbyists</strong> (all other professional types) subgroups.</p>



<p>The <strong>WordPress User</strong> group consists of those who: own or run a blog that is built with WordPress; own or run a website that is built with WordPress; write for or contribute to a blog/website that is built with WordPress; use WordPress for school as a teacher; use WordPress for school as a student, or are learning to build websites using WordPress.</p>



<p>The <strong>Others</strong> group consists of those who did not self-identify with any of the options provided for the question, “Which of the following best describes how you use WordPress?”</p>



<h2>2019 Survey Results Summary</h2>



<p>WordPress remains the platform of choice for future projects among those surveyed. Overwhelmingly, the reasons cited for this are that WordPress is the CMS people already know, and that the community supporting it is valuable. Professionals and users report similar levels of frustration with updates and Gutenberg. Both groups also love the ease of use they find in WordPress.</p>



<p>The number of professionals who report providing a heavily customized experience to clients has increased substantially, while at the same time the amount of time reported on creating those sites has decreased. Regardless of frustrations felt with various features, this seems to indicate that ease of use has been on the rise.</p>



<p>More details on sentiment, usage, and other interesting topics are available in the report: <a href=\"https://docs.google.com/presentation/d/1FI7eEvSB5SHTSILIBpwOmH9rBffgD6mFnnqSkrEScYo/edit#slide=id.g71a4c4edc6_3_232\">check it out!</a></p>



<h1>Before you go: take the 2020 Survey!</h1>



<p>Knowing why and how people use WordPress helps those who build WordPress to keep your needs and preferences in mind.&nbsp;</p>



<p>The survey will be open for at least 6 weeks, and results will be published on this blog. All data will be anonymized: no email addresses or IP addresses will be associated with published results. To learn more about WordPress.org’s privacy practices, check out the<a href=\"https://wordpress.org/about/privacy/\"> privacy policy</a>.</p>



<p>Like last year, the 2020 survey will be promoted via a banner on WordPress.org, as well as by WordPress enthusiasts. Each of the translated surveys will be promoted through banners on their associated localized-language WordPress.org sites. Please encourage your WordPress pals and social media followers to take the survey too!</p>



<p>To ensure your WordPress experience is represented in the 2020 survey results&#8230; don’t delay! </p>



<div class=\"wp-block-buttons aligncenter\">
<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-white-color has-vivid-cyan-blue-background-color has-text-color has-background\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-english\" rel=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-english\">Take the 2020 WordPress Annual Survey!</a></div>
</div>



<p>(Also available in <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-french\">French</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-german\">German</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-japanese\">Japanese</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-russian\">Russian</a>, and <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-spanish\">Spanish</a>!)</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 27 Oct 2020 22:44:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Andrea Middleton\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.6 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9134\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/10/wordpress-5-6-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3701:\"<p>WordPress 5.6 beta 2 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so we recommend that you run this version on a test site.</p>



<p>You can test the WordPress 5.6 beta in two ways:</p>



<ul><li>Try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (choose the “bleeding edge nightlies” option).</li><li>Or <a href=\"https://wordpress.org/wordpress-5.6-beta2.zip\">download the beta here (zip)</a>.</li></ul>



<p>WordPress 5.6 is slated for release on <a href=\"https://make.wordpress.org/core/5-6/\">December 8, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors that tested the <a href=\"https://wordpress.org/news/2020/10/wordpress-5-6-beta-1/\">beta 1</a> development release and provided feedback. Testing for bugs is an important part of polishing each release and a great way to contribute to WordPress.</p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since beta 1, <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=10%2F21%2F2020..10%2F27%2F2020&milestone=5.6&group=component&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">53 bugs</a> have been fixed. Here is a summary of a few changes included in beta 2:</p>



<ul><li>6 additional bugs have been fixed in the block editor (see <a href=\"https://github.com/WordPress/gutenberg/pull/26442\">#26442</a>).</li><li>Unified design for search forms and results across the admin (<a href=\"https://core.trac.wordpress.org/ticket/37353\">#37353</a>).</li><li>Exposed the <code>embed</code> Gutenberg block to Core (<a href=\"https://core.trac.wordpress.org/ticket/51531\">#51531</a>).</li><li>Updated Twemoji (<a href=\"https://core.trac.wordpress.org/ticket/51356\">#51356</a>), React (<a href=\"https://core.trac.wordpress.org/ticket/51505\">#51505</a>), and Akismet versions (<a href=\"https://core.trac.wordpress.org/ticket/51610\">#51610</a>).</li><li>Added accessibility improvements (among other things) to Application Passwords (<a href=\"https://core.trac.wordpress.org/ticket/51580\">#51580</a>).</li><li>Added indicator to image details for images attached to a site option (<a href=\"https://core.trac.wordpress.org/ticket/42063\">#42063</a>).</li></ul>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.6 has lots of refinements to the developer experience as well. To keep up, subscribe to the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> and pay special attention to the <a href=\"https://make.wordpress.org/core/tag/5-6+dev-notes/\">developers’ notes</a> for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>, where you can also find a list of <a href=\"https://core.trac.wordpress.org/query?status=new&milestone=5.6&group=component&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">known bugs</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 27 Oct 2020 22:02:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: Carrd-Like Theme Experiment Provides a Glimpse Into the Future of Theming\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106663\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://wptavern.com/carrd-like-theme-experiment-provides-a-glimpse-into-the-future-of-theming?utm_source=rss&utm_medium=rss&utm_campaign=carrd-like-theme-experiment-provides-a-glimpse-into-the-future-of-theming\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5308:\"<img />Carrd-like theme front page template.



<p class=\"has-drop-cap\">It is no secret that I think the future of theming with WordPress is bright, that the Gutenberg project will eventually pay off. As a former full-time theme developer, I lived through the years where there were no standards for how to build certain features. It was much like the Wild West. There were vast, unexplored territories. Each themer was setting off to find gold with the latest tricks and techniques they had learned.</p>



<p>One of the reasons I remain a fanboy of the Gutenberg project is because of experiments like the <a href=\"https://github.com/WordPress/theme-experiments/pull/56\">Two Column Landing Page</a> theme (yes, that&rsquo;s literally the theme name) that Kjell Reigstad put together in less than an hour. It is a Carrd-like layout. It is a simple one-page theme that is essentially an &ldquo;about me&rdquo; page. Under the hood, it required no custom framework or non-standard options. It simply utilized existing tools from WordPress and Gutenberg.</p>



<p>Two Column Landing Page is an unfinished product. Technically, it is a pull request that has yet to be officially merged into the <a href=\"https://github.com/WordPress/theme-experiments\">WordPress theme experiments</a> repository. Automattic Theme Wrangler Ian Stewart passed a <a href=\"https://a646a4b37deb1e8b.demo.carrd.co/\">Carrd demo link</a> along, and Reigstad pieced together a block-based version for WordPress.</p>



<p>The theme was easy to customize via the site editor, which continually improves with each release of Gutenberg (9.2 had some nice improvements with its template switcher).</p>



<img />Customized theme front page.



<p>For anyone who wants to give the theme a spin, they will need to grab the <code>two-column-landing-page</code> theme folder from the <a href=\"https://github.com/WordPress/theme-experiments/tree/try/two-col-landing-page\">try/two-col-landing-page</a> branch of the theme experiments repository. Enabling full-site editing within the Gutenberg plugin is also a requirement.</p>



<h2>Why This Theme Is the Future</h2>



<p class=\"has-drop-cap\">This Cardd-like theme is special not because it is anything extraordinary from a front-end design standpoint. It is special because it showcases how simple WordPress theming can be.</p>



<p>Theme authors will continue to build and experiment with old and new ideas. It will simply be much less hassle to do so. With traditional theming, developers who wanted to achieve this same Carrd-like layout for the front page of the site would have needed to build several customizer options and often provide extensive instructions on how to piece it together. When full-site editing finally lands in core, themers will be able to define a single template with predefined blocks.</p>



<p>No hooking into the customizer.</p>



<p>No need to register a database option.</p>



<p>No need to register a form field.</p>



<p>No need to sanitize user input for security.</p>



<p>No conditional checks before outputting front-end content.</p>



<p>WordPress will handle all these bits.  If theme authors are not excited about this, they have not been paying attention.  Now is the time to start.</p>



<p>This has been the problem with theme &ldquo;design&rdquo; over the years. More and more, it has become a business of learning relatively advanced PHP just to build out basic options. Because WordPress fell so far behind alternative solutions, far too much responsibility was placed onto the shoulders of theme developers. They were doing less and less design work and an increasing amount of programming. They were forced to build custom solutions to push past the shortcomings of WordPress.</p>



<p>Full-site editing is flipping the switch. It is transitioning toward a design framework that simplifies the process of building themes.</p>



<p>With block-based themes and the site editor, theme authors can simply define an HTML template with blocks. The user can then customize it how they like via the site editor.</p>



<p>To non-developers, it is hard to explain how revolutionary it is to take this step back from programming and a step toward designing. Themes are getting put into their proper place. This Carrd-like layout may be simple. However, with traditional theming, it would have been massively more complex.</p>



<p>The Two Column Landing Page theme supports other views, such as the posts page, single posts, and more. However, it should not have to. The future of theming should mean that the theme itself could be nothing more than a <code>front-page.html</code> file &mdash; the template that controls the front page output &mdash; and nothing more.</p>



<p>This means that the Themes Team, the gatekeepers to the official theme directory, may need to loosen the reins a bit. While the team currently allows experimental block-based themes, guidelines in the new era will need to be scaled back to the point that they are almost nonexistent if we want to see an explosion of artistry in the theme directory. Many of those rules were put into place because of the limitations of the system. When full-site editing lands in core and developers are building themes from blocks, many of the rules will become antiquated.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 27 Oct 2020 21:22:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: Dragging and Dropping Meta Boxes Might Not Be So Simple in WordPress 5.6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106675\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:209:\"https://wptavern.com/dragging-and-dropping-meta-boxes-might-not-be-so-simple-in-wordpress-5-6?utm_source=rss&utm_medium=rss&utm_campaign=dragging-and-dropping-meta-boxes-might-not-be-so-simple-in-wordpress-5-6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6444:\"<p class=\"has-drop-cap\">If you have been testing the latest development version of WordPress in the past week or so, you may have noticed that the ability to drag and drop meta boxes seemingly disappeared. This is not a bug. Nine days ago, lead developer Andrew Ozz <a href=\"https://core.trac.wordpress.org/changeset/49179\">committed a change</a> that requires end-users to click the &ldquo;screen options&rdquo; tab to expose the ability to rearrange meta boxes.</p>



<p>Ozz opened the <a href=\"https://core.trac.wordpress.org/ticket/50699\">original ticket</a> and has spearheaded the effort to change how users interact with meta boxes. The issue he would like to solve stems from a change in WordPress 5.5. WordPress&rsquo;s last major release <a href=\"https://core.trac.wordpress.org/ticket/49288\">introduced visible &ldquo;drop zones&rdquo;</a> in cases where a meta box container did not contain any meta boxes. These zones let users know that they can move meta boxes into those areas. This change was to fix a regression from a previous release. Needless to say, it was a rabbit hole of changes to chase down. Nevertheless, the problems with meta boxes were presumably fixed in WordPress 5.5.</p>



<img />Empty meta box holder on Dashboard screen.



<p>Ozz opened the ticket to remove the always-visible drop zones when no meta boxes were present. The argument is that the ability to move meta boxes around the screen is technically a &ldquo;screen option.&rdquo; Thus, it should only be triggered when the end-user has opened the screen options tab.</p>



<p>Another side issue is that he wanted to address accidental dragging, which he described as more common on laptops with trackpads than other devices.</p>



<p>Some readers may be thinking that meta boxes are going the way of the dinosaur. For those users who have migrated to 100% usage of the block editor, there is a good chance that their only interaction with meta boxes is on the Dashboard admin screen. For users on the classic editor, meta boxes are tightly interwoven into their day-to-day workflow. Many plugins also use the meta box system on custom admin screens.</p>



<p>The biggest counter-argument is that, because meta boxes look and feel like draggable elements, the ability to do so should be active at all times.</p>



<p>The point of contention is primarily about whether dragging and dropping meta boxes is technically a screen option. One side sees the WordPress 5.5 implementation as a broken user experience. The other side sees the new method as broken.</p>



<p>Without user data to back it up, no one can say which method is truly the best option. However, changes to a standard user experience that is more than a decade old are likely to be problematic for a large number of users.</p>



<p>This seems like one of those if-it-ain&rsquo;t-broke-don&rsquo;t-fix-it situations. With years of muscle memory for existing users and an expectation for how meta boxes should work, relegating the ability to drag them around the interface to the little-used screen options tab is a regression. At the very least, it is a major change that needs heavy discussion and testing before going forward.</p>



<p>&ldquo;Nothing breaks, per se,&rdquo; said John James Jacoby, the lead developer for BuddyPress and bbPress. &ldquo;Nothing fatal errors. Nothing visually looks different. Yet, a critical user interface function has now gone missing. In my WP User Profiles plugin, for example, there are 15 registered meta boxes. Previous to this change, users with the device and dexterity to use a mouse/pointer/cursor could rearrange those meta boxes with simple dragging and dropping. After this change, no user can rearrange them without first discovering how to unlock the interface to enable rearranging.&rdquo;</p>



<p>The problem is illustrated by the following screenshot from the <a href=\"https://wordpress.org/plugins/wp-user-profiles/\">WP User Profiles</a> plugin. Each of the highlighted boxes represents areas where end-users would typically be able to click to drag a meta box around the screen. If the current change is not reverted, many users may believe the plugin is broken when they upgrade to WordPress 5.6.</p>



<img />Meta boxes from the WP User Profiles plugin.



<p>&ldquo;Is there a plan for letting existing users know that moving metaboxes is now only when Screen Options is open?&rdquo; <a href=\"https://core.trac.wordpress.org/ticket/50699#comment:20\">asked Helen Hou-Sand&igrave;</a>, the core tech lead for 5.6, in the ticket. &ldquo;I&rsquo;m not sure I would ever discover that as an existing user and would be convinced everything was broken if I updated with no context.&rdquo;</p>



<p>The current solution is to drop a note in the &ldquo;What&rsquo;s New&rdquo; section of the WordPress 5.6 release notes to let users know of the change, which may not be visible enough for most users to see. If it does go through, ideally, users would be welcomed with an admin pointer that describe the change directly in their WordPress admin interface.</p>



<p>There are also <a href=\"https://core.trac.wordpress.org/ticket/50699#comment:37\">accessibility impacts to consider</a>. Joe Dolson, a core WordPress committer and member of the accessibility team, said the user experience for keyboard users would become difficult and that the feature would be harder to discover.</p>



<p>&ldquo;I can&rsquo;t see a way in which this change, as currently implemented, improves the experience for anybody,&rdquo; he said. &ldquo;The proposal from the accessibility team is how we could compromise to reduce the visual impact of the movers without compromising the usability of the system at this extreme level; but just <em>not</em> doing this would be something I&rsquo;d find entirely acceptable, as well.&rdquo;</p>



<p>So far, most people who have chimed in on the ticket have given numerous reasons for why this is not a good idea. There is almost no public support for it at this time. However, it currently remains in the latest development/trunk version of WordPress. If not reverted in the coming weeks, it will land in WordPress 5.6.</p>



<p class=\"is-style-default has-white-color has-blue-700-background-color has-text-color has-background text-white bg-blue-700\">Update: This <a href=\"https://core.trac.wordpress.org/ticket/50699#comment:48\">change was reverted</a> in WordPress core on October 27, 2020.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 26 Oct 2020 20:43:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"WPTavern: WordPress Contributors Explore Adding Dark Mode Support to Upcoming Twenty Twenty-One Theme via a Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106593\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:273:\"https://wptavern.com/wordpress-contributors-explore-adding-dark-mode-support-to-upcoming-twenty-twenty-one-theme-via-a-plugin?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-contributors-explore-adding-dark-mode-support-to-upcoming-twenty-twenty-one-theme-via-a-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5322:\"<p>WordPress 5.6 is set to include a new default theme, <a href=\"https://wptavern.com/first-look-at-twenty-twenty-one-wordpresss-upcoming-default-theme\">Twenty Twenty-One</a>, designed to give users a blank canvas for the block editor. The theme doesn&rsquo;t fall under any particular category and is meant to be suitable for use across different types of websites. One new feature that has very recently come under consideration is <a href=\"https://make.wordpress.org/core/2020/10/22/twenty-twenty-one-dark-mode-discussion/\">support for a dark mode that can be toggled on or off</a>.</p>



<p>Contributors have raised the possibility of including a dark mode in several <a href=\"https://github.com/WordPress/twentytwentyone/labels/%5BComponent%5D%20Dark%20Mode\">issues</a> while the theme has been in development. Mel Choyce, who is leading the design on the default theme, <a href=\"https://make.wordpress.org/core/2020/10/22/twenty-twenty-one-dark-mode-discussion/\">published a summary</a> of the team&rsquo;s recent discussions about which options the theme should make available for site owners and viewers in support of dark mode, or if the feature should simply be scrapped. </p>



<p>&ldquo;We&rsquo;ve built in a&nbsp;Customizer&nbsp;setting that lets site owners opt their sites out of supporting Dark Mode, for greater design control,&rdquo; Choyce said. &ldquo;Additionally, we&rsquo;re considering adding a front-end toggle so site viewers can turn Dark Mode on/off, regardless of their OS/Browser preference. This setting would only show if a site allows Dark Mode support.&rdquo;</p>



<div class=\"wp-block-image\"><img />Twenty Twenty-One Light and Dark Modes</div>



<p>Choyce outlined five different combinations of options for supporting it, including two options that allow site owners to disable it, regardless of the user&rsquo;s selection in their OS/browser. Two other options require the site to support dark mode but differ in whether or not the visitor is allowed to toggle it on or off. </p>



<h2>Does Twenty Twenty-One Need a Dark Mode?</h2>



<p>Dark mode was a late addition to the default theme&rsquo;s development. Choyce <a href=\"https://make.wordpress.org/core/2020/10/22/twenty-twenty-one-dark-mode-discussion/#comment-40111\">said</a> the idea seems like a good opportunity to explore but ideally the team would have intentionally designed the feature before development started. </p>



<p>In the comments of the post, contributors are discussing the many intricacies of adding this feature to a theme that will be on by default for new WordPress sites. A few commenters noted there might be issues and surprises with logos and transparent images. For this reason, several made the case for shipping it as an opt-in feature and not on by default.</p>



<p>Others did not see the need for users to be able to toggle dark mode on/off for individual websites when they already have controls available through their system or browser preferences.</p>



<p>Kjell Reigstad contends that users&rsquo; expectations have not yet translated into demand for this feature. </p>



<p>&ldquo;As much as I&rsquo;m a fan of dark mode in general (I use it on all my devices and it definitely helps to reduce eye strain), I think the general public views it as &lsquo;a thing that apps do&rsquo; &mdash; not something that websites do yet,&rdquo; Reigstad said. &ldquo;As mentioned above, this theme could be a step towards changing that perception, but the feature&rsquo;s novelty is something to keep in mind.&rdquo;</p>



<p>WordPress 5.6 core tech lead Helen Hou-Sand&iacute; suggested it might be better to develop the feature as a plugin, instead of pushing for it to be ready in a short time frame.</p>



<p>&ldquo;My instinct right now is that it would be best to split dark mode for Twenty Twenty-One out into a&nbsp;plugin&nbsp;as a form of opt-in, primarily because I think that will both ease the burden for meeting the bar for&nbsp;core&nbsp;ship and also gives space for the feature to be iterated on outside of the core development cycle,&rdquo; Hou-Sand&iacute; said. She also noted that users will be doing things with the theme that core contributors cannot anticipate and a plugin is an easier route for responding to those needs.</p>



<p>&ldquo;By separating it out, I think it has a better chance of reaching a point where it encompasses enough by default to be a theme setting without too much futzing on the user&rsquo;s part, or even enough of a thing to be a feature for all themes at large,&rdquo; Hou-Sand&iacute; said.</p>



<p>Choyce and Carolina Nymark agreed with this suggestion and <a href=\"https://wordpress.slack.com/archives/C02RP4VMP/p1603724762267800\">announced</a> a decision in the WordPress Slack #core-themes channel this morning, based on feedback on the post.</p>



<p>&ldquo;Carolina Nymark and I made the decision to move Dark Mode out into a plugin,&rdquo; Choyce said. &ldquo;This will allow us to better address all of the edge cases we&rsquo;ve been encountering without slowing down the progress of bug fixing within the core theme.&rdquo;</p>



<p>The plugin is being <a href=\"https://github.com/WordPress/twentytwentyone-dark-mode\">developed on GitHub</a> where contributors will explore how to support the feature moving forward.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 26 Oct 2020 18:47:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WordCamp Central: Get your free ticket to WordCamp Finland Online!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"https://central.wordcamp.org/?p=3130035\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"https://central.wordcamp.org/news/2020/10/26/get-your-free-ticket-to-wordcamp-finland-online/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1395:\"<p>WordCamp Finland 2020 is just right around the corner and speaker announcements have started to roll out! The online event with two session tracks takes place <strong>November 12 at 12-17 <a href=\"https://time.is/compare/12_12_Nov_2020_in_Helsinki/UTC\">UTC+2</a></strong>. Our organizing team is super excited about the event and upcoming content!</p>
<p>Tickets for WordCamp Finland Online 2020 are absolutely free! We strongly recommend registering for a ticket, as this will give you the full WordCamp experience. This will give you access to Q&amp;A sessions, networking opportunities with speakers, sponsors and other attendees. If you would rather not register, you will still be able to watch the talks.</p>
<p><a href=\"https://finland.wordcamp.org/2020/tickets/\">Register free for the WordCamp Finland Online</a>.</p>
<p>First speakers have been announced and more speakers as well as the full schedule will be announced shortly! Make sure to <a href=\"https://twitter.com/wordcampfinland\">follow us on Twitter</a> to get the news about new announcements.</p>
<p>There&#8217;s also still open <a href=\"https://finland.wordcamp.org/2020/call-for-volunteers/\">call for volunteers</a> to help us during the event day. Being a volunteer is more than lending a hand, it is the secret sauce that makes a wordcamp a WordCamp! Make sure to apply if you&#8217;d like to help make the event.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 26 Oct 2020 15:00:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Timi Wahalahti\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Akismet: Happy Birthday Akismet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://blog.akismet.com/?p=2093\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://blog.akismet.com/2020/10/25/happy-birthday-akismet/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1848:\"<p></p>


</p>
<img />
<p>


<p> </p>
<p>Akismet was launched 15 years ago today, when Automattic founder <a href=\"https://ma.tt/2005/10/akismet-stops-spam/\">Matt Mullenweg announced it on his blog</a> in a post describing what Akismet was and what it could become. Given how much the world has changed in the last decade and a half (back then spammers were pushing cheap flip phones and counterfeit Livestrong bracelets), we thought it would be fun to see whether Akismet succeeded in meeting the hopes and dreams that Matt laid out back in October 2005.</p>
<blockquote>
<p>&#8220;Akismet is a new web service that stops comment and trackback spam. (Or at least tries really hard to.)&#8221;</p>
</blockquote>
<p>Fact check: true! Akismet has stopped 500,000,000,000 pieces of comment and trackback spam since October 2005. That&#8217;s an average of a thousand spam per second, every second, since before Twitter existed. Plus another thousand in the time it took you to read that sentence. And this one. (And this one.)</p>
<blockquote>
<p>&#8220;The service is usable immediately as a WordPress plugin and the API could also be adapted for other systems.&#8221;</p>
</blockquote>
<p>Akismet is still usable as a WordPress plugin, and there are now dozens of Akismet clients for non-WordPress systems, plus countless other implementations for custom platforms. Some people say that Akismet is the most open anti-spam API on the Web. Some people are right.</p>
<blockquote>
<p>&#8220;If nothing else, I hope this makes blogging more joyful for at least one person.&#8221;</p>
</blockquote>
<p>According to an informal survey we just performed, Akismet has made blogging more joyful for multiple people. If you&#8217;re one of those people, put on a party hat, grab a piece of cake, and join us in wishing Akismet a very happy 15th birthday.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 25 Oct 2020 07:00:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Christopher Finke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: Yext Launches a WordPress Plugin To Connect To Its Answers Platform\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106325\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:199:\"https://wptavern.com/yext-launches-a-wordpress-plugin-to-connect-to-its-answers-platform?utm_source=rss&utm_medium=rss&utm_campaign=yext-launches-a-wordpress-plugin-to-connect-to-its-answers-platform\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6220:\"<p class=\"has-drop-cap\">Last week, Yext launched its <a href=\"https://wordpress.org/plugins/yext-answers/\">Yext Answers plugin</a> to the WordPress community. The goal was to bring a platform that won the Best Software Innovation category of the <a href=\"https://globalsearchawards.net/2020-winners/\">2020 Global Search Awards</a> to WordPress. However, my experience was far from satisfactory.</p>



<p>&ldquo;For people searching on a WordPress website, the Answers Connector provides a seamless search experience,&rdquo; said Alexandra Allegra, the Senior Product Marketing Manager at Yext. &ldquo;For businesses and organizations that integrate it, it drives higher rates of conversion, which generates more revenue. It helps lower support costs because when businesses can deliver detailed, official answers, customers don&rsquo;t have to call customer service. And finally, it unveils valuable customer insights, because businesses can see new questions coming in &mdash; in real-time.&rdquo;</p>



<p>Yext Answers is essentially trialware. Technically, the plugin itself is free. However, Yext is currently running a 90-day free trial for access to its <a href=\"https://www.yext.com/products/answers/\">Answers platform</a>. The website does not seem to provide an easy way to find what the true cost will be after that initial 90 days. To upgrade, users must contact the Yext team via email or phone.</p>



<p>The website does provide an estimated cost calculator. The lowest tier available via this calculator is for 20,000 searches per month at $5,000. It is unclear if there are lower pricing options. The Yext team provided no further details when asked about billing.</p>



<p>The plugin is marketing itself primarily toward business users. It can replace a WordPress site&rsquo;s traditional search, which is customizable to suit various site owner&rsquo;s needs, according to the Yext team.</p>



<p>Over the past week, I have discussed this plugin with a representative from the company, watched demo videos, and attempted to test the plugin. Thus far, it has been a subpar experience. I typically forgo writing about plugins that do not pan out. However, after the initial investment into what looked to be an interesting project, I wanted to share my experience, and my hope is that it helps the team build a better product in the long term.</p>



<p>I have yet to get the Yext Answers plugin to work. It requires an account with the Yext website. It also requires that end-users enter multiple fields on the plugin settings screen in WordPress. Unfortunately, after a frustrating amount of searching, I was never able to successfully find all of the correct information or get the information I did have to work. I gave up on the endeavor.</p>



<p>The demo video does show the promise of a somewhat interesting plugin:</p>



<div class=\"wp-block-embed__wrapper\">
<div class=\"embed-vimeo\"></div>
</div>



<p>Perhaps people who are already familiar with the Yext platform may have better luck. However, I would not recommend it to anyone new, at least in its current state.</p>



<p>There are far better options for connecting via third-party APIs that would be simpler for the average end-user (or even a developer of 15+ years such as myself). The one-click login process provided via the MakeStories plugin, <a href=\"https://wptavern.com/makestories-2-0-launches-editor-for-wordpress-rivaling-googles-official-web-stories-plugin\">which I covered recently</a>, is a prime example of how to do things right.</p>



<p>We are at a point in the internet era in which end-users should have simple, no-fuss connections between sites. Entering IDs, keys, and other complex fields should be tucked under an &ldquo;advanced&rdquo; section of the options screen, not as part of the default experience.  Or, they should be so easily available that no one should have trouble finding them.</p>



<h2>Launching with Shortcodes Instead of Blocks</h2>



<p class=\"has-drop-cap\">Two years after the integration of the block editor into WordPress, the Yext team is launching its Yext Answers plugin with shortcodes, which require manual entrance by end-users. Currently, the plugin does not have block equivalents for its shortcodes.</p>



<p>The team was either unwilling or unable to answer even the most fundamental questions about their decision to use shortcodes rather than launching their plugin &mdash; in the year 2020 &mdash; with at least block alternatives. At points, they even seemed confused about the subject altogether.</p>



<p>The closest the team came to providing feedback after a lengthy discussion was the following, attributed to Rose Grant, the Associate Product Manager:</p>



<blockquote class=\"wp-block-quote\"><p>We&rsquo;re looking forward to feedback on the initial release of our plugin before iterating further on it, including introducing custom blocks. For this version of the plugin, we wanted to prioritize supporting clients who are using older versions of WordPress.</p></blockquote>



<p>Packaging a set of shortcodes within a plugin is still a good practice, even for plugin developers who have transitioned fully to supporting the block editor. It allows them to support users who are still working with the classic editor. However, at this point, developers should be building from a block-first mindset. Blocks do not require that users remember specific shortcode names. They provide instant, visual feedback to users in the editor. And, block options (as opposed to shortcode arguments) do not rely on the oftentimes faulty input of user typing.</p>



<p>At this point, all plugin developers should consider shortcodes a legacy feature and useful only as a backward-compatible option for users on the classic editor.</p>



<p>The Communications Strategist for the company pointed out that this is Yext&rsquo;s first venture into WordPress plugins and that the team may not be able to provide perspective or commentary on such questions related to blocks and shortcodes. However, this is the <a href=\"https://profiles.wordpress.org/thundersnow/#content-plugins\">third Yext-related plugin</a> associated with the plugin author account on WordPress.org.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 23 Oct 2020 20:17:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: Gutenberg 9.2 Adds Video Tracks, Improvements to Columns and Cover Blocks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106638\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:209:\"https://wptavern.com/gutenberg-9-2-adds-video-tracks-improvements-to-columns-and-cover-blocks?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-9-2-adds-video-tracks-improvements-to-columns-and-cover-blocks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4029:\"<p><a href=\"https://make.wordpress.org/core/2020/10/21/whats-new-in-gutenberg-21-october/\">Gutenberg 9.2</a> was released this week and is the last release of the plugin to be rolled into WordPress 5.6. It features the long-awaited video tracks functionality, closing a <a href=\"https://github.com/WordPress/gutenberg/issues/7673\">ticket</a> that has been open for more than two years under development. </p>



<p>Video tracks includes things like subtitles, captions, descriptions, chapters, and metadata. This update introduces a UI for adding video tags, which can contain multiple track elements using the following four attributes: </p>



<ul><li><code>srclang</code>&nbsp;(Valid BCP 47 language tag)</li><li><code>label</code>&nbsp;(Title for player UI)</li><li><code>kind</code>&nbsp;(Captions, Chapters, Descriptions, Metadata or Subtitles)</li><li><code>src</code>&nbsp;(URL of the text file)</li></ul>



<p>The ability to edit tracks is exposed in the video block&rsquo;s toolbar:</p>



<div class=\"wp-block-image\"><img /></div>



<p>This update closes a major gap in video accessibility and greatly improves the user experience of videos.</p>



<p>Gutenberg 9.2 also introduces the ability to transform multiple selected blocks into a Columns block. For example, users can select three image blocks and instantly change them into a three-column section. Columns can be created from any kind of block, including InnerBlocks. The transform option will appear if the number of selected blocks falls between 2-6. (The maximum number is derived from the maximum number of columns allowed by the Columns block.)</p>



<div class=\"wp-block-image\"><img />Transform multiple blocks into Columns block</div>



<p>Another notable feature in 9.2 is the expansion of Cover blocks to support repeated background patterns. This gives users more flexibility in their designs, opening up a new set of possibilities.</p>



<div class=\"wp-block-embed__wrapper\">
https://cloudup.com/cArDykzhpYZ
</div>



<p>This release brings in more than a dozen improvements to the new Widgets screen, as well as updates to the Query Block and Site Editor experiments. The most notable smaller enhancements to existing features include the following: </p>



<ul><li>Add dropdown button to view templates in&nbsp;sidebar. (<a href=\"https://github.com/WordPress/gutenberg/pull/26132\">26132</a>)</li><li>Gallery block: Use image caption as fallback for alt text. (<a href=\"https://github.com/WordPress/gutenberg/pull/26082\">26082</a>)</li><li>Table block: Use&nbsp;hooks&nbsp;+&nbsp;API&nbsp;v2. (<a href=\"https://github.com/WordPress/gutenberg/pull/26065\">26065</a>)</li><li>Refactor document actions to handle template part titles. (<a href=\"https://github.com/WordPress/gutenberg/pull/26043\">26043</a>)</li><li>Info panel layout improvement. (<a href=\"https://github.com/WordPress/gutenberg/pull/26017\">26017</a>)</li><li>Remove non-core&nbsp;blocks from default editor content. (<a href=\"https://github.com/WordPress/gutenberg/pull/25844\">25844</a>)</li><li>Add very basic template information dropdown. (<a href=\"https://github.com/WordPress/gutenberg/pull/25757\">25757</a>)</li><li>Rename &ldquo;Options&rdquo; modal to &ldquo;Preferences&rdquo;. (<a href=\"https://github.com/WordPress/gutenberg/pull/25683\">25683</a>)</li><li>Add single column functionality to the Columns block. (<a href=\"https://github.com/WordPress/gutenberg/pull/24065\">24065</a>)</li><li>Add more writing flow options: Reduced&nbsp;UI, theme styles, spotlight. (<a href=\"https://github.com/WordPress/gutenberg/pull/22494\">22494</a>)</li><li>Add option to make Post&nbsp;Featured Image&nbsp;a link. (<a href=\"https://github.com/WordPress/gutenberg/pull/25714\">25714</a>)</li></ul>



<p>Since the Gutenberg 9.2 release was delayed by a week, it includes many more bug fixes and code quality improvements than most releases. Check out the full <a href=\"https://make.wordpress.org/core/2020/10/21/whats-new-in-gutenberg-21-october/\">changelog</a> for more details.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 23 Oct 2020 15:59:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"WPTavern: ESLint Maintainers Share Challenges of Funding Open Source Utilities through Sponsorship\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106411\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:241:\"https://wptavern.com/eslint-maintainers-share-challenges-of-funding-open-source-utilities-through-sponsorship?utm_source=rss&utm_medium=rss&utm_campaign=eslint-maintainers-share-challenges-of-funding-open-source-utilities-through-sponsorship\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8517:\"<p><a href=\"https://eslint.org/\">ESLint</a>, one of the most popular JavaScript linting utilities, quickly eclipsed more established early competitors, <a href=\"https://wptavern.com/jshint-is-now-free-software-after-updating-license-to-mit-expat\">thanks to its open source license</a>. The clear licensing enabled the project to become widely used but did not immediately translate into funds for its ongoing development. Despite being &nbsp;downloaded more than 13 million times each week, its maintainers still struggle to support the utility.</p>



<p>A little over a year since launching&nbsp;<a href=\"https://eslint.org/blog/2019/02/funding-eslint-future\">ESLint Collective</a>&nbsp;to fund contributors&rsquo; efforts, the project&rsquo;s leadership <a href=\"https://eslint.org/blog/2020/10/year-paying-contributors-review\">shared</a> some of the successes and challenges of pursuing the sponsorship model. One effort that didn&rsquo;t pan out was hiring a dedicated maintainer:</p>



<blockquote class=\"wp-block-quote\"><p>This was a difficult thing for the team to work through, and we think there&rsquo;s an important lesson about open source sustainability: even though we receive donations, ESLint doesn&rsquo;t bring in enough to pay maintainers full-time. When that happens, maintainers face a difficult decision: we can try to make part-time development work, but it&rsquo;s hard to find other part-time work to make up the monthly income we need to make it worthwhile. In some cases, doing the part-time work makes it more difficult to find other work because you are time-constrained in a way that other freelancers are not.</p></blockquote>



<p>One somewhat successful experiment ESLint explored is paying its five-person Technical Steering Committee (TSC), the project leadership responsible for managing releases, issues, and pull requests. Members receive $50/hour for contributions and time spent on the project, capped at a maximum of $1,000/month. The cap prevents TSC members from spending too much time on the project in addition to their day job so they don&rsquo;t get burned out.</p>



<p>The team reports that this stipend arrangement has worked &ldquo;exceedingly well&rdquo; and contributions have slowly increased: &ldquo;There is something to be said for paying people for valuable work: when the work is explicitly valued, people are more willing to do it.&rdquo; </p>



<p>On larger projects like WordPress, corporate contributions are critical to its ongoing development. In recent years, the <a href=\"https://wordpress.org/five-for-the-future/\">Five for the Future</a> campaign has helped compensate many contributors as their employers pay them a salary while donating their time to work on WordPress. </p>



<p>Some of the major advancements in WordPress require an immense investment of time and expertise. It&rsquo;s problem solving that requires working across teams for months to build complex solutions that will work for millions of users. That&rsquo;s why you don&rsquo;t see armies of people building Gutenberg for free. Much of the development is driven by paid employees and might not otherwise have happened without corporate donations of employee time. Automattic, Google, Yoast SEO, 10up, GoDaddy, Human Made, WebDevStudios, WP Engine, and many other companies have collectively <a href=\"https://wordpress.org/five-for-the-future/pledges/\">pledged</a> thousands of hours worth of labor per month. The diversity of companies and individuals supporting WordPress helps the project maintain stability and weather the storms of life better. </p>



<p>Smaller open source projects like ESLint rarely have the same resources at their disposal and have to experiment. Summarizing the one-year review of paying contributors from sponsorships, the team states: <em>&ldquo;Maintaining a project like ESLint takes a lot of work and a lot of contributions from a lot of people. The only way for that to continue is to pay people for their time.&rdquo;</em></p>



<p>When even the most popular utilities struggle to gain enough sponsorships, what hope is there for smaller projects? Many utilities that have become indispensable in developers&rsquo; workflows are on a trajectory towards becoming unsustainable.  </p>



<p>&ldquo;Unfortunately, utilities like these rarely bring in any meaningful amount of money from donations, no matter how widely used or beloved they are,&rdquo; OSS engineer Colin McDonnell said in his proposal for a new funding model. &ldquo;Consider&nbsp;<a href=\"https://github.com/ReactTraining/react-router\">react-router</a>. Even with 41.3k stars on GitHub, 3M weekly downloads from NPM, and nearly universal adoption in React-based single-page applications, it only brings in&nbsp;<a href=\"https://opencollective.com/react-router\">~$17k</a>&nbsp;of donations annually.&rdquo;</p>



<p>McDonnell proposed the concept of &ldquo;<a href=\"https://vriad.com/essays/a-new-funding-model-for-open-source-software\">sponsor pools</a>,&rdquo; to fund smaller projects that are unable to benefit from existing open-source funding models.&nbsp;Instead of making donations on a per-project basis, open source supporters could donate a set amount into a &ldquo;wallet&rdquo; every month and then distribute those funds to projects they select for their sponsor pools. The key part of the implementation is that adding new projects to the pool should only take one click, reducing the psychological friction associated with supporting additional projects.</p>



<p>McDonnell suggested that GitHub is the only organization with the infrastructure to implement this model as an extension of GitHub Sponsors. One commenter on <a href=\"https://news.ycombinator.com/item?id=23981563\">Hacker News</a> proposes that Sponsors and the idea of &ldquo;sponsors pool&rdquo; could exist in parallel.</p>



<p>&ldquo;I believe that there&rsquo;s a meaningful difference between being the patron of a developer and feeling like you&rsquo;re backing a creator with feelings and a story and a family&hellip; and wanting to be a good citizen that has an approved list of projects that I benefit from and want to support,&rdquo; Pete Forde said.</p>



<p>&ldquo;I can sponsor Matz, get his updates and feel good about knowing I am counted as a supporter AND set aside $$$ per month to contribute to all of the tools I use in my projects simply because it&rsquo;s the right thing to do and I want those projects to exist for the long term. They are completely different initiatives. Patreon vs Humble Bundle, if you will.&rdquo;</p>



<p><a href=\"https://www.tidelift.com/\">Tidelift</a> is another concept that was highlighted in the HN discussion. It has a different, unique approach to funding open source work. Tidelift pools funds from the organizations using the software to support the maintainers. </p>



<p>&ldquo;I maintain <a href=\"https://github.com/ruby-grape/grape\">ruby grape</a>, a mid-sized project,&rdquo; Daniel Doubrovkine said. &ldquo;We get $144/month from Tidelift. As more companies signup for corporate sponsorship the dollar amount increases. It&rsquo;s a pool.&rdquo;</p>



<p><a href=\"https://snowdrift.coop/\">Snowdrift</a> takes a more unusual approach to pooling sponsorships where patrons &ldquo;crowdmatch&rdquo; each others donations to fund public goods. It runs as a non-profit co-op to fund free and open projects that serve the public interest.  </p>



<p><a href=\"https://flossbank.com/\">Flossbank</a> is more specifically targeted at funding open source projects and takes technical approach to ensuring equitable contributions to the the&nbsp;entire dependency tree&nbsp;of your installed open source packages. The organization claims to provide &ldquo;a free and frictionless&rdquo; way to give back to maintainers. Developers can opt into curated, tech-focused ads in the terminal when installing open source packages. As an alternative, they can set a monthly donation amount to be spread across the packages they install.</p>



<p>No single funding model is suitable for all projects but the experiments that pool sponsorships in various ways seem to be trending, especially for supporting maintainers who may not be as skilled in marketing their efforts. The conversation around supporting utilities <a href=\"https://news.ycombinator.com/item?id=23981563\">continues on Hacker News</a>. WordPress developers who depend on some of these utilities may want to join in and share their experiences in funding small projects.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Oct 2020 20:26:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Akismet: Version 4.1.7 of the Akismet WordPress Plugin is Now Available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://blog.akismet.com/?p=2104\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://blog.akismet.com/2020/10/22/version-4-1-7-of-the-akismet-wordpress-plugin-is-now-available/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:882:\"Version 4.1.7 of <a href=\"http://wordpress.org/plugins/akismet/\">the Akismet plugin for WordPress</a> is now available. It contains the following changes:

<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
 	<li>Stops using the deprecated <code>wp_blacklist_check</code> function in favor of the new <code>wp_check_comment_disallowed_list</code> function.</li>
 	<li>Shows the &#8220;Set Up Akismet&#8221; banner on the comments dashboard page, where it&#8217;s appropriate to mention if Akismet has not yet been configured.</li>
 	<li>Miscellaneous text changes.</li>
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->

To upgrade, visit the Updates page of your WordPress dashboard and follow the instructions. If you need to download the plugin zip file directly, links to all versions are available in <a href=\"http://wordpress.org/plugins/akismet/\">the WordPress plugins directory</a>.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Oct 2020 19:23:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Christopher Finke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WPTavern: Q: First FSE WordPress Theme Now Live\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106388\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:137:\"https://wptavern.com/q-first-fse-wordpress-theme-now-live?utm_source=rss&utm_medium=rss&utm_campaign=q-first-fse-wordpress-theme-now-live\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7929:\"<img />Q WordPress theme screenshot.



<p class=\"has-drop-cap\">Themes Team representative Ari Stathopoulos is now officially the first theme author to have a theme in the directory that supports full-site editing (FSE). With a slimmed-down beta release of FSE shipping in WordPress 5.6 this December, someone had to be the first to take the plunge. It made sense for someone intimately familiar with theme development and the directory guidelines to step up.</p>



<p>In many ways, it is a huge responsibility that Stathopoulos has taken on. Until one of the default Twenty* themes handles FSE, the <a href=\"https://wordpress.org/themes/q/\">Q theme</a> will likely be one of the primary examples that other theme authors will follow as they begin learning how to build block-based themes.</p>



<p>Earlier this month, I used <a href=\"https://wptavern.com/exploring-full-site-editing-with-the-q-wordpress-theme\">Q to test FSE</a> and determine how much it had advanced. It is at least months away from being ready for use in production. The beta release in 5.6 is more or less just to get more people testing.</p>



<p>Stathopoulos has no plans to make Q much more than a bare-bones starter or experimental theme. It is almost a playground to see what is possible.</p>



<p>&ldquo;Q was born out of necessity,&rdquo; he said. &ldquo;I couldn&rsquo;t work on full-site editing or global styles without having a base theme for them, so for a while, I had it in a GitHub repository. I decided to release it to the WordPress.org repository because I think I might not be the only one with those issues. Downloading a theme in the dashboard is easier than cloning a repository for most people.&rdquo;</p>



<p>Existing block-based themes are few and far between. Automattic and some of its employees have some experimental projects, but none of those are in the official directory for anyone to test. Stathopoulos wanted a base theme that was unopinionated in terms of design that would allow him to work on FSE, test pull requests, and experiment with various ideas.</p>



<p>&ldquo;It has some ideas for things that ultimately I&rsquo;d like to see implemented in FSE, and it&rsquo;s a playground,&rdquo; he said. &ldquo;For example, the addition of a skip-link for accessibility in the theme, an implementation for responsive/adaptive typography, and conditional loading of block styles only when they are used/needed. These are things that I hope will be part of WordPress Core at some point, and the Q theme explores ideas on how to implement them.&rdquo;</p>



<p>He began work on the theme over a year ago and continues working on it as a side project. He said Yoast, his employer, fully supports the idea of creating things that are beneficial for other theme designers and WordPress core.</p>



<h2>Developing an FSE-Capable Theme</h2>



<img />Editing the Q theme single post template in the site editor.



<p class=\"has-drop-cap\">End-users must install the Gutenberg plugin and activate the experimental FSE feature to use the theme or any similar theme. Currently, FSE is missing many key features that make it viable for most real-world projects. However, theme developers who plan to work with WordPress over the next several years will need to begin testing and experimenting. Q makes for a good starting point to simply get a feel for what themes will look like.</p>



<p>&ldquo;The biggest issue was &mdash; and still is &mdash; keeping up with Gutenberg development,&rdquo; said Stathopoulos. &ldquo;Many things are currently fluid, and they happen at a very high pace. The reason I created the theme was because other themes I was testing, as part of my contribution to the Themes Team, were not properly maintained or updated. I wanted to create a starter theme that can be used as a starting point for others as well.&rdquo;</p>



<p>One of the biggest questions still hanging in the air is what the timeline will look like for publicly-available, block-based themes. <em>Will 2021 be the year they take over?</em> That is unlikely given the feature&rsquo;s current state. However, there will be a point where developers are no longer building classic or traditional themes.</p>



<p>&ldquo;I think we&rsquo;re going to see a lot more FSE themes in 2021,&rdquo; said Stathopoulos. &ldquo;It might take a couple of years before they become the standard, but after the release of WordPress 5.6, I hope there will be a lot more development and focus on FSE and global styles. Whether we see more FSE themes or not depends on when some things get merged in WordPress core.&rdquo;</p>



<p>He pointed out some critical missing features from Gutenberg at the moment. The big one is that the Query block, which is the block that displays posts on the front end, does not inherit its options from the global query. Essentially, this means that, regardless of what URL a visitor is on, it displays the latest posts.</p>



<p>&ldquo;Once these things are addressed, and blockers for theme builders get resolved, I expect we&rsquo;ll see an explosion of good FSE themes being built,&rdquo; he said.</p>



<p>Stathopoulos is most excited about the prospect of seeing more design standards come to core. Currently, there is no consistency between themes. Theme authors can use any markup they want. Switching themes affects a site&rsquo;s structure, SEO, accessibility, speed, and many other things.</p>



<p>&ldquo;My advice to theme developers who want to start tinkering would be to start with something simple,&rdquo; he said. &ldquo;It&rsquo;s tempting to add extremely opinionated styles, for buttons for example, but more and more things get added every day to the editor like a border-radius setting for buttons. Theme authors should avoid the trap of designing an FSE theme having in mind what the editor currently does. Instead, theme authors should strive to build something having in mind a vision of what the editor will eventually become.&rdquo;</p>



<h2>The Future of Theme Reviews</h2>



<p class=\"has-drop-cap\">Because Stathopoulos is a representative of the Themes Team, he also has some insight into the shift in the coming years for guidelines and what steps authors might need to take. While it is too early for the team to begin making decisions, its members are already thinking about forthcoming changes.</p>



<p>&ldquo;Change is always difficult, especially when it&rsquo;s for something this big,&rdquo; said Stathopoulos. &ldquo;It will be a bumpy ride, and it will take time. WordPress theming is a huge industry. For a while, &lsquo;classic&rsquo; (for lack of a better word) themes will continue to be a viable solution for theme developers who didn&rsquo;t have time to catch up. But not forever.&rdquo;</p>



<p>Some may look back at previous major shifts and worry about what the future theme directory guidelines may ask. In 2015, the team <a href=\"https://wptavern.com/wordpress-org-now-requires-theme-authors-to-use-the-customizer-to-build-theme-options\">required all theme options to use the customizer</a>. This was after a three-year wait for theme authors to organically make the switch. Given that FSE will be a much larger departure from norms and dislike of the Gutenberg  project from segments of the development community, it could be a rough transition.</p>



<p>&ldquo;At some point, FSE themes will become the industry standard and what the users want,&rdquo; said Stathopoulos. &ldquo;Personally, I hope no one will want to upload a classic theme in the w.org repository in 2025 when the industry has moved on. It would be like uploading today a theme that is using tables and iframes for layouts.&rdquo;</p>



<p>He said that sufficient time would be given for the eventual transition.  However, the team will likely prioritize FSE-based themes. They are cognizant of how much of a shift this will be and will plan accordingly when the time comes.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Oct 2020 18:48:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"WPTavern: Loginizer Plugin Gets Forced Security Update for Vulnerabilities Affecting 1 Million Users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106557\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:245:\"https://wptavern.com/loginizer-plugin-gets-forced-security-update-for-vulnerabilities-affecting-1-million-users?utm_source=rss&utm_medium=rss&utm_campaign=loginizer-plugin-gets-forced-security-update-for-vulnerabilities-affecting-1-million-users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5484:\"<p>WordPress.org has pushed out a forced security update for the <a href=\"https://wordpress.org/plugins/loginizer/\">Loginizer</a> plugin, which is active on more than 1 million websites. The plugin offers brute force protection in its free version, along with other security features like two-factor auth, reCAPTCHA, and PasswordLess login in its commercial upgrade. </p>



<p>Last week security researcher Slavco Mihajloski <a href=\"https://wpdeeply.com/loginizer-before-1-6-4-sqli-injection/\">discovered</a> an unauthenticated SQL injection vulnerability, and an XSS vulnerability, that he disclosed to the plugin&rsquo;s authors. Loginizer version 1.6.4 was released on October 16, 2020, with patches for the two issues, summarized on the plugin&rsquo;s blog: </p>



<blockquote class=\"wp-block-quote\"><p>1) [Security Fix] : A properly crafted username used to login could lead to SQL injection. This has been fixed by using the prepare function in PHP which prepares the SQL query for safe execution.</p><p>2) [Security Fix] : If the IP HTTP header was modified to have a null byte it could lead to stored XSS. This has been fixed by properly sanitizing the IP HTTP header before using the same.</p></blockquote>



<p>Loginizer did not disclose the vulnerability until today in order to give users the time to upgrade. Given the severity of the vulnerability, the plugins team at WordPress.org pushed out the security update to all sites running Loginizer on WordPress 3.7+. </p>



<p>In July, 2020, Loginizer was <a href=\"https://loginizer.com/blog/loginizer-has-been-acquired-by-softaculous/\">acquired by Softaculous</a>, so the company was also able to automatically upgrade any WordPress installations with Loginizer that had been created using Softaculous. This effort, combined with the updates from WordPress.org, covered a large portion of Loginizer&rsquo;s user base.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Any <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> install with <a href=\"https://twitter.com/loginizer?ref_src=twsrc%5Etfw\">@loginizer</a> probably isn\'t using another WAF solution. As you can notice from the graph 600k+500k active installs were updated upside down, so &hellip; Preauth SQLi in it, reported by me. Update! Crunching write up :) <a href=\"https://t.co/gkEVWun9wt\">https://t.co/gkEVWun9wt</a> <a href=\"https://t.co/XWXVMYO1ED\">pic.twitter.com/XWXVMYO1ED</a></p>&mdash; mslavco (@mslavco) <a href=\"https://twitter.com/mslavco/status/1318059239332601856?ref_src=twsrc%5Etfw\">October 19, 2020</a></blockquote>
</div>



<p>The automatic update took some of the plugin&rsquo;s users by surprise, since they had not initiated it themselves and had not activated automatic updates for plugins. After several users <a href=\"https://wordpress.org/support/topic/automatic-update-33/\">posted</a> on the plugin&rsquo;s support forum, plugin team member Samuel Wood said that &ldquo;WordPress.org has the ability to turn on auto-updates for security issues in plugins&rdquo; and has used this capability many times.</p>



<p>Mihajloski <a href=\"https://wpdeeply.com/loginizer-before-1-6-4-sqli-injection/\">published</a> a more detailed proof-of-concept on his blog earlier today. He also highlighted some concerns regarding the systems WordPress has in place that allowed this kind of of severe vulnerability to slip through the cracks. He claims the issue could have easily been prevented by the plugin review team since the plugin wasn&rsquo;t using the prepare function for safe execution of SQL queries. Mihajloski also recommended recurring code audits for plugins in the official directory.</p>



<p>&ldquo;When a plugin gets into the repository, it must be reviewed, but when is it reviewed again?&rdquo; Mihajloski said. &ldquo;Everyone starts with 0 active installs, but what happens on 1k, 10k, 50k, 100k, 500k, 1mil+ active installs?&rdquo;</p>



<p>Mihajloski was at puzzled how such a glaring security issue could remain in the plugin&rsquo;s code so long, given that it is a security plugin with an active install count that is more than many well known CMS&rsquo;s. The plugin also recently changed hands when it was acquired by Softaculus and had been audited by multiple security organizations, including <a href=\"https://blog.wpsec.com/sql-injection-and-csrf-security-vulnerability-in-loginizer/\">WPSec</a> and <a href=\"https://blog.dewhurstsecurity.com/2018/05/22/loginizer-wordpress-plugin-xss-vulnerability.html\">Dewhurst Security</a>.</p>



<p>Mihajloski also recommends that WordPress improve the transparency around <a href=\"https://wordpress.org/about/security/\">security</a>, as some site owners and closed communities may not be comfortable with having their assets administered by unknown people at WordPress.org.</p>



<p>&ldquo;WordPress.org in general is transparent, but there isn&rsquo;t any statement or document about who, how and when decides about and performs automatic updates,&rdquo; Mihajloski said. &ldquo;It is kind of [like] holding all your eggs in one basket.</p>



<p>&ldquo;I think those are the crucial points that WP.org should focus on and everything will came into place in a short time: complete WordPress tech documentation for security warnings, a guide for disclosure of the bugs (from researchers, but also from a vendor aspect), and recurring code audits for popular plugins.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Oct 2020 03:47:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"Post Status: Joe Casabona on creating quality content and courses\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=80099\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://poststatus.com/joe-casabona-on-creating-quality-content-and-courses/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1407:\"<p>David Bisset interviews Joe Casabona, an independent creator and teacher, and discusses what it\'s like to be a creator as his job, plus some news topics.</p>







<h3 id=\"h-links\">Links</h3>



<ul><li>W3C <a href=\"https://wptavern.com/w3c-drops-wordpress-from-consideration-for-redesign-narrows-cms-shortlist-to-statamic-and-craft\">drops WordPress</a> from consideration for its redesign</li><li>W3c <a href=\"https://wptavern.com/w3c-selects-craft-cms-for-redesign-project\">selects Craft</a> and <a href=\"https://w3c.studio24.net/docs/cms-selection-report/\">selection report</a></li><li><a href=\"https://www.youtube.com/watch?v=14RcHPfStA0\">Disabling full screen mode</a></li><li><a href=\"https://creatorcourses.com/shop/\">Creator Courses</a></li><li>How I Built It <a href=\"https://howibuilt.it/recording-notes/\">recording notes</a></li><li><a href=\"https://reincubate.com/camo/\">Camo</a></li></ul>



<h3>Partner: <a href=\"https://poststatus.com/sandhills\">Sandhills Development</a></h3>



<p><a href=\"https://poststatus.com/sandhills\">Sandhills Development</a> crafts ingenuity, developed with care:</p>



<ul><li>Easy Digital Downloads – Sell digital products with WordPress</li><li>AffiliateWP – A full-featured affiliate marketing solution</li><li>Sugar Calendar – WordPress event management made simple</li><li>WP Simple Pay – A lightweight Stripe payments plugin</li></ul>



<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Oct 2020 21:17:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"WPTavern: MakeStories 2.0 Launches Editor for WordPress, Rivaling Google’s Official Web Stories Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106327\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:245:\"https://wptavern.com/makestories-2-0-launches-editor-for-wordpress-rivaling-googles-official-web-stories-plugin?utm_source=rss&utm_medium=rss&utm_campaign=makestories-2-0-launches-editor-for-wordpress-rivaling-googles-official-web-stories-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8860:\"<img />Recipe slide from the MakeStories WordPress plugin.



<p class=\"has-drop-cap\">Earlier today, <a href=\"https://wordpress.org/plugins/makestories-helper/\">MakeStories launched version 2.0</a> of its plugin for creating Web Stories with WordPress. In many ways, this is a new plugin launch. The previous version simply allowed users to connect their WordPress installs to the <a href=\"https://makestories.io/\">MakeStories site</a>. With the new version, users can build and edit their stories directly from the WordPress admin.</p>



<p>Version 2.0 of the plugin still requires an account and a connection with the MakeStories.io website. However, it is simple to set up. Users can log in without leaving their WordPress admin interface. This API connection means that user-created Stories are stored on the MakeStories servers. If an end-user wanted to jump platforms from WordPress to something else, this would allow them to take their Stories with them.</p>



<p>&ldquo;One of the things we would like to assure is your content is still yours, and none of the user data is being consumed or analyzed by us,&rdquo; said Pratik Ghela, the founder and product manager at MakeStories. &ldquo;We only take enough data to help serve you better.&rdquo;</p>



<p>The plugin is a competing solution to the official <a href=\"https://wptavern.com/google-officially-releases-its-web-stories-for-wordpress-plugin\">Web Stories plugin by Google</a>. While the two share similarities in the final output (they are built to utilize the same front-end format for creating Stories on the web), they take different paths to get there.</p>



<p>The two share similarities on the backend too. However, MakeStories may be more polished in some areas. For example, it allows users to zoom in on the small canvas area. Having the ability to reorder slides from the grid view also feels more intuitive.</p>



<p>&ldquo;The main unique selling proposition of our plugin is that it comes with a guarantee of the MakeStories team,&rdquo; said Ghela. &ldquo;We as a team have been building this for over two years, and we are proud to be one of the tools that has stood the test of time, and competition and is still growing at a very fast pace.&rdquo;</p>



<p>The team also wants to make the Story-creating process faster, safer, and rewarding. The goal is to cater to designers, developers, and content creators. Ghela also feels like his team&rsquo;s support turnaround time of a few hours will be the key to success and is a good reason for users to give this plugin a try before settling on something else.</p>



<p>&ldquo;We feel that our goal is to see Web Stories flourish,&rdquo; he said. &ldquo;And we may have different types of users looking out for various options. So, the official plugin from Google and the one from MakeStories at least opens up the options for users to choose from. And we feel that the folks at Google are also building a great editor, and, at the end of the day, it&rsquo;s up to the user to select what they feel is the best.</p>



<p>Technically, MakeStories is a SaaS (software as a service) product. Even though it is a free plugin, there will eventually be a commercial component to it. Currently, it is free at least until the first quarter of 2021, which may be extended based on various factors. There is no word on what pricing tiers may be available after that.</p>



<p>&ldquo;There will always be a free tier, and we have always stood for it that your data belongs to you,&rdquo; said Ghela. &ldquo;In case you do not like the pricing, we will personally assist you to port out from using our editor and still keep the data and everything totally intact.&rdquo;</p>



<h2>Diving Into the Plugin</h2>



<img />Story management screen.



<p class=\"has-drop-cap\">MakeStories is a drag-and-drop editor for building Web Stories. It works and feels much like typical design editors like Gimp or Photoshop. It shares similarities with QuarkXPress or InDesign, for those familiar with page layout programs. In some ways, it feels a lot like a light-colored version of Google&rsquo;s Web Stories plugin with more features and a slightly more intuitive interface.</p>



<p>The end goal is simple: create a Story through designing slides/pages that site visitors will click through as the narrative unfolds.</p>



<p>The plugin provides a plethora of shapes, textures, and animations. These features are easy to find and implement. It also includes free access to images, GIFs, and videos. These are made possible via API integrations with Unsplash, Tenor, and Pexels.</p>



<p>MakeStories includes access to 10 templates at the moment. However, what makes this feature stand out is that end-users can create and save custom templates for reuse down the road.</p>



<img />Editing a Story from a predesigned template.



<p>One of the more interesting, almost hidden, features is the available text patterns. The plugin allows users to insert these patterns from a couple of dozen choices. This makes it easier to visualize a design without having to build everything from scratch.</p>



<img />Inserting a text pattern and adjusting its size.



<p>While the editing process is a carefully-crafted experience that makes the plugin worth a look, it is the actual publishing aspect of the workflow that is a bit painful. Traditional publishing in WordPress means hitting the &ldquo;publish&rdquo; button to make content live. This is not the case with the MakeStories plugin. It takes you through a four-step process of entering various publisher details, setting up metadata and SEO, validating the Story content, and analytics. It is not that these steps are necessarily bad. For example, MakeStories lets you know when images are missing alt text, which is needed information screen readers. The problem is that it feels out of place to go through all of these details when I, as a user, simply want my content published. And, many of these details, such as the publisher (author), should be automatically filled in.</p>



<p>Updating a Story is not as simple as hitting an &ldquo;update&rdquo; button either. The system needs to run through some of the same steps too.</p>



<p>Ghela said the publishing process might be a bit tough but will prove fruitful in the end. The plugin takes care of the technical aspects of adding title tags, meta, and other data on the front end after the user fills in the form fields.</p>



<p>&ldquo;We will definitely work on improving the flow as the community evolves and improve it a lot to be easier, faster, and, most importantly, still very customizable,&rdquo; he said.</p>



<p>The MakeStories team has no plans of stopping at its current point on the roadmap. Ghela sounded excited about some of the upcoming additions they are planning, including features like teams, branding, easy template customization, polls, and quizzes.</p>



<h2>On the Web Stories Format</h2>



<img /><a href=\"https://feature.undp.org/covid-and-poverty/\">UN report on COVID-19 and poverty</a> published with MakeStories.



<p class=\"has-drop-cap\">Many will ultimately hesitate to use any plugin that implements Web Stories given Google&rsquo;s history of dropping projects. There is also a feeling that the format is a bit of a fad and will not stand the test of time.</p>



<p>&ldquo;We greatly believe in AMP and Web Stories as a content format,&rdquo; said Ghela. &ldquo;We, as an agency, have been involved a lot in AMP and have done a lot of experiments with it, including a totally custom WooCommerce site in fully-native, valid AMP with support for variable products, subscriptions, and other functionalities.&rdquo;</p>



<p>The company is all-in on the format and feels like it will be around for the long term, particularly if there is a good ecosystem around monetization.</p>



<p>&ldquo;We think that the initial reactions are because there are not enough proven results and because we never imagined the story format to come to the web,&rdquo; said Ghela. &ldquo;There were definitely plugins that did this. Few folks tried to build stories using good ol&rsquo; HTML, CSS, and JavaScript. But, the performance and UX were not that great. On the other hand, the engineers at the AMP Team are making sure that everything is just perfect. The UX, load time, WCV Score, just everything.&rdquo;</p>



<p>He feels that some of the early criticisms are unwarranted and that the web development community should give the format a try and provide feedback.</p>



<p>&ldquo;The more data we all get, actually gives the AMP team a clear idea of what&rsquo;s needed, and they can design the roadmap accordingly,&rdquo; he said. &ldquo;So, just giving out early reactions won&rsquo;t help, but constructive criticism and getting back to the AMP team with what you are doing will.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Oct 2020 21:12:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.6 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9085\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/10/wordpress-5-6-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7956:\"<p>WordPress 5.6 Beta 1 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so we recommend that you run this version on a test site.</p>



<p>You can test the WordPress 5.6 beta in two ways:</p>



<ul><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option).</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.6-beta1.zip\">download the beta here&nbsp;(zip)</a>.</li></ul>



<p>The current target for final release is December 8, 2020. This is just&nbsp;<strong>seven weeks away</strong>, so your help is needed to ensure this release is tested properly.</p>



<h2><strong>Improvements in the Editor</strong></h2>



<p>WordPress 5.6 includes seven Gutenberg plugin releases. Here are a few highlighted enhancements:</p>



<ul><li>Improved support for video positioning in cover blocks.</li><li>Enhancements to Block Patterns including translatable strings.</li><li>Character counts in the information panel, improved keyboard navigation, and other adjustments to help users find their way better. </li><li>Improved UI for drag and drop functionality, as well as block movers.</li></ul>



<p>To see all of the features for each release in detail check out the release posts: <a href=\"https://make.wordpress.org/core/2020/07/22/whats-new-in-gutenberg-july-22/\">8.6</a>, <a href=\"https://make.wordpress.org/core/2020/08/05/whats-new-in-gutenberg-august-5/\">8.7</a>, <a href=\"https://make.wordpress.org/core/2020/08/19/whats-new-in-gutenberg-august-19/\">8.8</a>, <a href=\"https://make.wordpress.org/core/2020/09/03/whats-new-in-gutenberg-2-september/\">8.9</a>, <a href=\"https://make.wordpress.org/core/2020/09/16/whats-new-in-gutenberg-16-september/\">9.0</a>, <a href=\"https://make.wordpress.org/core/2020/10/01/whats-new-in-gutenberg-30-september/\">9.1</a>, and 9.2 <em>(link forthcoming)</em>.</p>



<h2><strong>Improvements in Core</strong></h2>



<h3><strong>A new default theme</strong></h3>



<p>The default theme is making its annual return with<a href=\"https://make.wordpress.org/core/2020/09/23/introducing-twenty-twenty-one/\"> Twenty Twenty-One</a>. This theme features a streamlined and elegant design, which aims to be <a href=\"https://www.w3.org/TR/UNDERSTANDING-WCAG20/conformance.html#uc-levels-head\">AAA ready</a>. </p>



<h3><strong>Auto-update option for major releases</strong></h3>



<p>The much anticipated opt-in for major releases of WordPress Core will ship in this release. With this functionality, you can elect to have major releases of the WordPress software update in the background with no additional fuss for your users. </p>



<h3><strong>Increased support for PHP 8</strong></h3>



<p>The next major version release of PHP, 8.0.0, is scheduled for release just a few days prior to WordPress 5.6. The WordPress project has a long history of being compatible with new versions of PHP as soon as possible, and this release is no different.</p>



<p>Because PHP 8 is a major version release, changes that break backward compatibility or compatibility for various APIs are allowed. Contributors have been hard at work <a href=\"https://make.wordpress.org/core/2020/10/06/call-for-testing-php-8-0/\">fixing the known incompatibilities with PHP 8</a> in WordPress during the 5.6 release cycle.</p>



<p>While all of the detectable issues in WordPress can be fixed, you will need to verify that all of your plugins and themes are also compatible with PHP 8 prior to upgrading. Keep an eye on the <a href=\"https://make.wordpress.org/core/\">Making WordPress Core blog</a> in the coming weeks for more detailed information about what to look for.</p>



<h3>Application Passwords for REST API Authentication</h3>



<p>Since the REST API was merged into Core, only cookie &amp; nonce based authentication has been available (without the use of a plugin). This authentication method can be a frustrating experience for developers, often limiting how applications can interact with protected endpoints.</p>



<p>With the introduction of <a href=\"https://make.wordpress.org/core/2020/09/23/proposal-rest-api-authentication-application-passwords/\">Application Password</a> in WordPress 5.6, gone is this frustration and the need to jump through hoops to re-authenticate when cookies expire. But don&#8217;t worry, cookie and nonce authentication will remain in WordPress as-is if you&#8217;re not ready to change.</p>



<p>Application Passwords are user specific, making it easy to grant or revoke access to specific users or applications (individually or wholesale). Because information like &#8220;Last Used&#8221; is logged, it&#8217;s also easy to track down inactive credentials or bad actors from unexpected locations.</p>



<h3><strong>Better accessibility</strong></h3>



<p>With every release, WordPress works hard to improve accessibility. Version 5.6 is no exception and will ship with a number of accessibility fixes and enhancements. Take a look:</p>



<ul><li>Announce block selection changes manually on windows.</li><li>Avoid focusing the block selection button on each render.</li><li>Avoid rendering the clipboard textarea inside the button</li><li>Fix dropdown menu focus loss when using arrow keys with Safari and Voiceover</li><li>Fix dragging multiple blocks downwards, which resulted in blocks inserted in wrong position.</li><li>Fix incorrect aria description in the Block List View.</li><li>Add arrow navigation in Preview menu.</li><li>Prevent links from being focusable inside the Disabled component.</li></ul>



<h2><strong>How You Can Help</strong></h2>



<p>Keep your eyes on the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;for&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-6+dev-notes/\">5.6-related developer notes</a>&nbsp;in the coming weeks, breaking down these and other changes in greater detail.</p>



<p>So far, contributors have fixed&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&milestone=5.6&group=component&max=500&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">188 tickets in WordPress 5.6</a>, including&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&status=reopened&type=enhancement&milestone=5.6&or&status=closed&status=reopened&type=feature+request&milestone=5.6&col=id&col=summary&col=type&col=status&col=milestone&col=owner&col=priority&col=changetime&col=keywords&order=changetime\">82 new features and enhancements</a>, and more bug fixes are on the way.</p>



<h3>Do some testing!</h3>



<p>Testing for bugs is an important part of polishing the release during the beta stage and a great way to contribute.</p>



<p>If you think you’ve found a bug, please post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a>&nbsp;in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>. That’s also where you can find a list of&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p><span><i>Props to&nbsp;</i><a href=\"https://profiles.wordpress.org/webcommsat/\">@webcommsat</a><i>,&nbsp;</i><a href=\"https://profiles.wordpress.org/yvettesonneveld/\">@yvettesonneveld</a><i>,&nbsp;</i><a href=\"https://profiles.wordpress.org/estelaris/\">@estelaris</a><i>, </i><a href=\"https://profiles.wordpress.org/cguntur/\">@cguntur</a><i>, <em><a href=\"https://profiles.wordpress.org/desrosj/\">@desrosj</a></em>, and&nbsp;</i><a href=\"https://profiles.wordpress.org/marybaum/\">@marybaum</a><i>&nbsp;for </i><em>editing/proof reading</em></span><em> this post, and&nbsp;<a href=\"https://profiles.wordpress.org/davidbaumwald/\">@davidbaumwald</a>&nbsp;for final review.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 20 Oct 2020 22:14:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: WordPress 5.6 Release Team Pulls the Plug on Block-Based Widgets\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106466\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:193:\"https://wptavern.com/wordpress-5-6-release-team-pulls-the-plug-on-block-based-widgets?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-5-6-release-team-pulls-the-plug-on-block-based-widgets\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8762:\"<img />Current block-based widgets admin screen design.



<p class=\"has-drop-cap\">I was wrong. I assured our readers that &ldquo;the block-based widget system will be ready for prime time when WordPress 5.6 lands&rdquo; in my previous <a href=\"https://wptavern.com/are-block-based-widgets-ready-to-land-in-wordpress-5-6\">post on the new feature&rsquo;s readiness</a>. I also said that was on the condition of not trying to make it work with the customizer &mdash; that experience was still broken. However, the 5.6 team pulled the plug on block-based widgets for the second time this year.</p>



<p>One week ago, WordPress 5.6 release lead Josepha Haden <a href=\"https://twitter.com/JosephaHaden/status/1316131424466952192\">seemed to agree</a> that it would be ready. However, things can change quickly in a development cycle, and tough decisions have to be made with beta release deadlines.</p>



<p>This is not the first feature the team has punted to a future release. Two weeks ago, they dropped <a href=\"https://wptavern.com/navigation-screen-sidelined-for-wordpress-5-6-full-site-editing-edges-closer-to-public-beta\">block-based nav menus </a>from the 5.6 feature list. Both features were <a href=\"https://wptavern.com/new-block-based-navigation-and-widgets-screens-sidelined-for-wordpress-5-5\">originally planned for WordPress 5.5</a>.</p>



<p>A new Widgets admin screen has been under development <a href=\"https://github.com/WordPress/gutenberg/issues/13204\">since January 2019</a>, which was not long after the initial launch of the block editor in WordPress 5.0. For now, the block-based widgets feature has been <a href=\"https://core.trac.wordpress.org/ticket/51506\">punted to WordPress 5.7</a>. It has also been given the &ldquo;early&rdquo; tag, which means it should go into core WordPress soon after the 5.7 release cycle begins. This will give it more time to mature and more people an opportunity to test it.</p>



<p>Helen Hou-Sand&igrave;, the core tech lead for 5.6, <a href=\"https://core.trac.wordpress.org/ticket/51506#comment:15\">provided a historical account</a> of the decision and why it was not ready for inclusion in the new ticket:</p>



<blockquote class=\"wp-block-quote\"><p>My question for features that affect the front-end is &ldquo;can I try out this new thing without the penalty of messing up my site?&rdquo; &mdash; that is, user trust. At this current moment, given that widget areas are not displayed anything like what you see on your site without themes really putting effort into it and that you have to save your changes live without revisions to get an actual contextual view, widget area blocks do not allow you to try this new feature without penalizing you for experimenting.</p></blockquote>



<p>She went on to say that the current experience is subpar at the moment. Problems related to the customizer experience, which I <a href=\"https://wptavern.com/gutenberg-8-9-brings-block-based-widgets-out-of-the-experimental-stage\">covered in detail</a> over a month ago, were also mentioned.</p>



<p>&ldquo;So, when we come back to this again, let&rsquo;s keep sight of what it means to keep users feeling secure that they can get their site looking the way they want with WordPress, and not like they are having to work around what we&rsquo;ve given them,&rdquo; said Hou-Sand&igrave;.</p>



<p>This is a hopeful outlook despite the tough decision. Sometimes, these types of calls need to be made for the good of the project in the long term. Pushing back a feature to a future version for a better user experience can be better than launching early with a subpar experience.</p>



<p>&ldquo;The good part of this is that now widgets can continue to be &lsquo;re-imagined&rsquo; for 5.7, and get even more enhancements,&rdquo; <a href=\"https://core.trac.wordpress.org/ticket/51506#comment:17\">said lead WordPress developer Andrew Ozz</a> in the ticket. &ldquo;Not sure how many people have tested this for a bit longer but having blocks in the widgets areas (a.k.a. sidebars) opens up many new possibilities and makes a lot of the old, limited widgets obsolete. The &lsquo;widget areas&rsquo; become something like &lsquo;specialized posts with more dynamic content,&rsquo; letting users (and designers) do a lot of stuff that was either hard or impossible with the old widgets.&rdquo;</p>



<p>After the letdown of seeing one of my most anticipated features of 5.6 being dropped, it is encouraging to see the positive outlook from community leaders on the project.</p>



<p>&ldquo;You know, I was really hopeful for it too, and that last-minute call was one I labored over,&rdquo; said Haden. &ldquo;When I last looked, it did seem close to ready, but then more focused testing was done and there were some interactions that are a little rough for users. I&rsquo;m grateful for that because the time to discover painful user experiences is before launch rather than after!&rdquo;</p>



<p>Despite dropping its second major feature, WordPress 5.6 still has some big highlights that will be shipping in less than two months. The new <a href=\"https://wptavern.com/first-look-at-twenty-twenty-one-wordpresss-upcoming-default-theme\">Twenty Twenty-One theme</a> looks to be a breath of fresh air and will explore block-related features not seen in previous default themes. Haden also pointed out auto-updates for major releases, <a href=\"https://wptavern.com/wordpress-5-6-to-introduce-application-passwords-for-rest-api-authentication\">application passwords support</a> for the REST API, and accessibility improvements as features to look forward to.</p>



<p>WordPress 5.6 Beta 1 is expected to ship today.</p>



<h2>Adding New Features To an Old Project</h2>



<p class=\"has-drop-cap\">At times, it feels like the Gutenberg project has bitten off more than it can chew. Many of the big feature plans continually miss projections. Between full-site editing, global styles, widgets, nav menus, and much more, it is tough to get hyper-focused on one feature and have it ready to ship. On the other hand, too much focus one way can be to the detriment to other features in the long run. All of these pieces must eventually come together to create a more cohesive whole.</p>



<p>WordPress is also <a href=\"https://wptavern.com/happy-17th-wordpress\">17 years old</a>. Any new feature could affect legacy features or code. The goal for block-based widgets is to transition an existing feature to work within a new system without breaking millions of websites in the process. Twenty-one months of work on a single feature shows that it is not an easy problem to solve.</p>



<p>&ldquo;You are so right about complex engineering problems!&rdquo; said Haden. &ldquo;We are now at a point in the history of the project where connecting all of the pieces can have us facing unforeseen complications.&rdquo;</p>



<p>The project also needs to think about how it can address some of the issues it has faced with not quite getting major features to completion. Is the team stretched too thin to focus on all the parts? Are there areas we can improve to push features forward?</p>



<p>&ldquo;There will be a retrospective where we can identify what parts of our process can be improved in the future, but I also feel like setting stretch goals is good for any software project,&rdquo; said Haden. &ldquo;Many contributors have a sense of urgency around bringing the power of blocks to more spaces in WordPress, which I share, but when it&rsquo;s time to ship, we have to balance that with our deep commitment to usability.&rdquo;</p>



<p>One problem that has become increasingly obvious is that front-end editing has become tougher over the years. Currently, widgets and nav menus can be edited in two places in WordPress with wildly different interfaces. Full-site editing stands to add an entirely new interface to the mix.</p>



<p>&ldquo;I think one of the problems that we&rsquo;re trying to solve with Gutenberg has always been a more consistent experience for editing elements across the WordPress interface,&rdquo; said Haden. &ldquo;No user should have to learn five different workflows to make sure their page looks the way they imagined it when it&rsquo;s published.&rdquo;</p>



<p>In the meantime, which may be numbered in years, end-users will likely have these multiple interfaces to deal with &mdash; overlap while new features are being developed. This may simply be a necessary growing pain of an aging project, one that is trying to lead the pack of hungry competitors in the CMS space.</p>



<p>&ldquo;There&rsquo;s a lot of interest in reducing the number of workflows, and I&rsquo;m hopeful that we can consolidate down to just one beautiful, intuitive interface,&rdquo; said Haden.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 20 Oct 2020 21:16:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: WooCommerce Tests New Instagram Shopping Checkout Feature, Now in Closed Beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106398\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/woocommerce-tests-new-instagram-shopping-checkout-feature-now-in-closed-beta?utm_source=rss&utm_medium=rss&utm_campaign=woocommerce-tests-new-instagram-shopping-checkout-feature-now-in-closed-beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2878:\"<p>Instagram&rsquo;s checkout feature, which allows users to purchase products without leaving the app, has become an even more important part of Facebook&rsquo;s long-term investment in e-commerce now that the pandemic has so heavily skewed consumer behavior towards online shopping. When Instagram <a href=\"https://business.instagram.com/blog/new-to-instagram-shopping-checkout\">introduced</a> checkout in 2019, it reported that 130 million users were tapping to reveal product tags in shopping posts every month.</p>



<img />image credit: Instagram



<p>Business owners who operate an existing store can extend their audience to Instagram by funneling orders from the social network into their own stores, without shoppers having to leave Instagram. Checkout supports integration with several e-commerce platform partners, including Shopify and BigCommerce, and will soon be available for WooCommerce merchants.</p>



<p>WooCommerce is testing a new Instagram Shopping Checkout feature for its <a href=\"https://woocommerce.com/products/facebook/\">Facebook for WooCommerce</a> plugin. The free extension is used on more than 900,000 websites and will provide the bridge for store owners who want to tap into Instagram&rsquo;s market. The checkout capabilities are currently in closed beta. Anyone interested to test the feature can <a href=\"https://docs.google.com/forms/d/e/1FAIpQLSfHwcCJf1UYi_7PGmFSXJXPfhdM8rkVlXAKub1qD5EBT9dFWw/viewform\">sign up</a> for consideration. Businesses registered in the USA that meet certain other requirements may be selected to participate, and the beta is also expanding to other regions soon.</p>



<p>WooCommerce currently supports <a href=\"https://woocommerce.com/posts/instagram-shopping/\">shoppable posts</a>, which are essentially products sourced from a product catalog created on Facebook that are then linked to the live store through an Instagram business account. Instagram&rsquo;s checkout takes it one step further to provide a native checkout experience inside the app. Merchants pay no selling fees&nbsp;until December 31, 2020. After that time, the fee is <a href=\"https://www.facebook.com/business/help/223030991929920?id=533228987210412\">5% per shipment</a> or a flat fee of $0.40 for shipments of $8.00 or less.&nbsp;</p>



<p>On the customer side, shoppers only have to enter their information once and thereafter it is stored for future Instagram purchases. Instagram also pushes shipment and delivery notifications inside the app. Store owners will need to weigh whether the convenience of the in-app checkout experience is worth forking over 5% to Facebook, or if they prefer funneling users over to the live store instead.</p>



<p>Instagram Shopping Checkout is coming to WooCommerce in the near future but the company has not yet announced a launch date, as the feature is just now entering closed beta. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 20 Oct 2020 04:13:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Past Twenty* WordPress Themes To Get New Block Patterns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106396\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:173:\"https://wptavern.com/past-twenty-wordpress-themes-to-get-new-block-patterns?utm_source=rss&utm_medium=rss&utm_campaign=past-twenty-wordpress-themes-to-get-new-block-patterns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6608:\"<p class=\"has-drop-cap\">Mel Choyce-Dwan, the Default Theme Design Lead for WordPress 5.6, kick-started 10 tickets around two months ago that would bring new features to the old default WordPress themes. The proposal is to add unique block patterns, a feature added to WordPress 5.5, to all of the previous 10 Twenty* themes. It is a lofty goal that could breathe some new life into old work from the previous decade.</p>



<p>Currently, only the last four themes are marked for an update by the time WordPress 5.6 lands. Previous themes are on the list to receive their block patterns in a future release. For developers and designers interested in getting involved, the following is a list of the Trac tickets for each theme:</p>



<ul><li><a href=\"https://core.trac.wordpress.org/ticket/51098\">Twenty Twenty</a> &ndash; 5.6</li><li><a href=\"https://core.trac.wordpress.org/ticket/51099\">Twenty Nineteen</a> &ndash; 5.6</li><li><a href=\"https://core.trac.wordpress.org/ticket/51100\">Twenty Seventeen</a> &ndash; 5.6</li><li><a href=\"https://core.trac.wordpress.org/ticket/51101\">Twenty Sixteen</a> &ndash; 5.6</li><li><a href=\"https://core.trac.wordpress.org/ticket/51102\">Twenty Fifteen</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51103\">Twenty Fourteen</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51104\">Twenty Thirteen</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51105\">Twenty Twelve</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51106\">Twenty Eleven</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51107\">Twenty Ten</a> &ndash; Future release</li></ul>



<p>If you are wondering where Twenty Eighteen is in that list, that theme does not actually exist. It is the one missing year the WordPress community has had since the one-default-theme-per-year era began with Twenty Ten. It is easy to forget that we did not get a new theme for the 2017-2018 season. With all that has happened in the world this year, we should count ourselves fortunate to see a <a href=\"https://wptavern.com/first-look-at-twenty-twenty-one-wordpresss-upcoming-default-theme\">new default theme land for WordPress</a> this December. WordPress updates and its upcoming default theme are at least one consistency that we have had in an otherwise chaotic time.</p>



<p>More than anything, it is nice to see some work going toward older themes &mdash; not just in terms of bug fixes but feature updates. The older defaults are still a part of the face of WordPress. Twenty Twenty and Twenty Seventeen each have over one million active installs. Twenty Nineteen has over half a million. The other default themes also have significant user bases in the hundreds of thousands &mdash; still some of the most-used themes in the directory. We owe it to those themes&rsquo; users to keep them fresh, at least as long as they maintain such levels of popularity.</p>



<p>This is where the massive theme development community could pitch in. Do some testing of the existing patches. Write some code for missing patterns or introduce new ideas. This is the sort of low-hanging fruit that almost anyone could take some time to help with.</p>



<h2>First Look at the New Patterns</h2>



<p class=\"has-drop-cap\">None of the proposed patterns have landed in trunk, the development version of WordPress, yet. However, several people have created mockups or added patches that could be committed soon.</p>



<p>One of my favorite patterns to emerge thus far is from Beatriz Fialho for the Twenty Nineteen theme. Fialho has created many of the pattern designs proposed thus far, but this one, in particular, stands out the most. It is a simple two-column, two-row pattern with a circular image, heading, and paragraph for each section. Its simplicity fits in well with the more elegant, business-friendly look of the Twenty Nineteen theme.</p>



<img />Services pattern for Twenty Nineteen.



<p>It is also fitting that Twenty Nineteen get a nice refresh with new patterns because it was the default theme to launch with the block editor. Ideally, it would continually be updated to showcase block-related features.</p>



<p>While many people will focus on some of the more recent default themes, perhaps the most interesting one is a bit more dated. Twenty Thirteen was meant to showcase the new post formats feature in WordPress 3.6. According to Joen Asmussen, the theme&rsquo;s primary designer, the original idea was for users to compose a ribbon of alternating colors as each post varied its colors.</p>



<p>&ldquo;The alternating ribbon of colors did not really come to pass because post formats were simply not used enough to create an interesting ribbon,&rdquo; he wrote in the Twenty Thirteen ticket. &ldquo;However, perhaps for block patterns, we have an opportunity to revisit those alternating ribbons of colors. In other words, I&rsquo;d love to see those warm bold colors used in big swathes that take up the whole pattern background.&rdquo;</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>Patterns designed to match post formats.



<p>This could be a fun update for end-users who are still using <s>that feature that shall not be named</s> post formats.</p>



<p>There is a lot to like about many of the pattern mockups so far. I look forward to seeing what lands along with WordPress 5.6 and in future updates.</p>



<h2>Establishing Pattern Category Standard</h2>



<p class=\"has-drop-cap\">With the more recent Twenty Twenty-One theme&rsquo;s block patterns and the new patterns being added to some of the older default themes, it looks like a specific pattern category naming scheme is starting to become a standard. Of the patches thus far, each is creating a new pattern category named after the theme itself.</p>



<p>This makes sense. Allowing users to find all of their theme&rsquo;s patterns in one location means that they can differentiate between them and those from core or other plugins. Third-party theme authors should follow suit and stick with this convention for the same reason.</p>



<p>Developers can also define multiple categories for a single pattern. This allows theme authors to create a category that houses all of their patterns in one location. However, they can also split them into more appropriate context-specific categories for discoverability.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 19 Oct 2020 21:13:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"BuddyPress: BuddyPress 7.0.0-beta1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=315150\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://buddypress.org/2020/10/buddypress-7-0-0-beta1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4332:\"<p><a href=\"https://downloads.wordpress.org/plugin/buddypress.7.0.0-beta1.zip\">BuddyPress 7.0.0-beta1</a> is now available for testing!</p>



<p>Please note the plugin is&nbsp;<strong>still in development</strong>, so we recommend running this beta release on a&nbsp;<strong>testing site</strong>.</p>



<p>You can test BuddyPress 7.0.0-beta1 in 4 ways :</p>



<ul><li>Try the <a href=\"https://wordpress.org/plugins/bp-beta-tester/\">BP Beta Tester</a> plugin.</li><li><a href=\"https://downloads.wordpress.org/plugin/buddypress.7.0.0-beta1.zip\">Download the beta here (zip file)</a>.</li><li>Check out our SVN repository: <code>svn co https://buddypress.svn.wordpress.org/trunk/</code></li><li>Clone our read-only Git repository: <code>git clone git://buddypress.git.wordpress.org/</code></li></ul>



<p><strong>The 7.0.0 stable release is slated to the beginning of December, and we’d love you to give us a hand to get there!</strong></p>



<p>Please note BuddyPress 7.0.0 <a href=\"https://bpdevel.wordpress.com/2020/07/05/wordpress-required-version-update-2/\"><strong>will require at least WordPress 4.9</strong>.</a></p>



<p>Testing for bugs is an important part of polishing the release during the beta stage and a great way to contribute. Here are some of the big changes and features to pay close attention to while testing (Check out&nbsp;<a href=\"https://buddypress.trac.wordpress.org/query?status=closed&group=resolution&milestone=7.0.0\">this report</a>&nbsp;on Trac for the full list).</p>



<div class=\"wp-block-spacer\"></div>



<h2><span class=\"dashicons dashicons-dashboard\"></span> New Administration screens to manage BuddyPress types</h2>



<p>In BuddyPress 7.0.0 site administrators will be able to add, edit or delete <strong>Member &amp; Group types</strong> using their WordPress Administration Screens just like they would do for Post tags.</p>



<p><a href=\"https://bpdevel.wordpress.com/2020/09/21/bp-types-admin-ui/\">Read this development note</a>&nbsp;to learn&nbsp;more about it.</p>



<div class=\"wp-block-spacer\"></div>



<h2><span class=\"dashicons dashicons-block-default\"></span> Let&#8217;s welcome 3 new BP Blocks into our Block Editor</h2>



<ul><li>The <strong>Activity Embed block</strong> let authors embed an activity into their post or page.</li><li>Use the <strong>BP Member<span class=\"has-inline-color\">s</span> block</strong> to select community users you want to feature into a post or a page.</li><li>Enjoy the <strong>BP Group<span class=\"has-inline-color\">s</span> block</strong> to pick the groups you want to highlight into a post or a page.</li></ul>



<p>Get to know these new blocks <a href=\"https://bpdevel.wordpress.com/2020/10/14/three-new-blocks-to-expect-in-buddypress-7-0-0/\">reading this development note</a>.</p>



<div class=\"wp-block-spacer\"></div>



<h2><span class=\"dashicons dashicons-admin-generic\"></span> Improved support for WP CLI</h2>



<p><a href=\"https://wp-cli.org/\">WP-CLI</a>&nbsp;is the command-line interface for WordPress. You can update plugins, configure multisite installs, and much more, without using a web browser. In 7.0.0, you will be able to Enjoy new BuddyPress CLI commands to manage BuddyPress Group Meta, BuddyPress Activity Meta, activate or deactivate the BuddyPress signup feature and create BuddyPress specific testing code for plugins.</p>



<p>Discover more about it from this <a href=\"https://bpdevel.wordpress.com/2020/10/09/wp-cli-buddypress-2-0/\">development note</a>.</p>



<div class=\"wp-block-spacer\"></div>



<p><em>And so much more such as improvements to the BP REST API, our Template pack, images and iframes lazy loading support&#8230;</em></p>



<div class=\"wp-block-spacer\"></div>



<h2><span class=\"dashicons dashicons-buddicons-buddypress-logo\"></span> How You Can Help</h2>



<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp-plugins/buddypress/dev/\">Help us translate BuddyPress into more than 100 languages</a>!</p>



<p>If you think you’ve found a bug, you can post in&nbsp;<a href=\"https://buddypress.org/support\">the support forums</a>. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://buddypress.trac.wordpress.org/newticket\">file one on BuddyPress Trac</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Oct 2020 22:30:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mathieu Viet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: Using the Web Stories for WordPress Plugin? You Better Play By Google’s Rules\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105848\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:215:\"https://wptavern.com/using-the-web-stories-for-wordpress-plugin-you-better-play-by-googles-rules?utm_source=rss&utm_medium=rss&utm_campaign=using-the-web-stories-for-wordpress-plugin-you-better-play-by-googles-rules\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4080:\"<img />Web Stories dashboard screen in WordPress.



<p class=\"has-drop-cap\">What comes as a surprise to few, Google has updated its <a href=\"https://developers.google.com/search/docs/guides/web-stories-content-policy\">content guidelines</a> for its Web Stories format. For users of its recently-released <a href=\"https://wordpress.org/plugins/web-stories/\">Web Stories for WordPress</a> plugin, they will want to follow the extended rules for their Stories to appear in the &ldquo;richer experiences&rdquo; across Google&rsquo;s services. This includes the grid view on Search, Google Images, and Google Discover&rsquo;s carousel.</p>



<p>Google <a href=\"https://wptavern.com/google-officially-releases-its-web-stories-for-wordpress-plugin\">released its Web Stories plugin</a> in late September to the WordPress community. It is a drag-and-drop editor that allows end-users to create custom Stories from a custom screen in their WordPress admin.</p>



<div class=\"wp-block-image\"><img />Visual Stories on Search.</div>



<p>The plugin does not directly link to Google&rsquo;s content guidelines anywhere. For users who do not do a little digging, they may be caught unaware if their stories are not surfaced in various Google services.</p>



<p>On top of the Discover and Webmaster guidelines, Web Stories have six additional restrictions related to the following:</p>



<ul><li>Copyrighted content</li><li>Text-heavy Web Stories</li><li>Low-quality assets</li><li>Lack of narrative</li><li>Incomplete stories</li><li>Overly commercial</li></ul>



<p>While not using copyrighted content is one of those reasonably-obvious guidelines, the others could trip up some users. Because Stories are meant to represent bite-sized bits of information on each page, they may become ineligible if most pages have more than 180 words of text. Videos should also be limited to fewer than 60 seconds on each page.</p>



<p>Low-quality media could be a flag for Stories too. Google&rsquo;s guidelines point toward &ldquo;stretched out or pixelated&rdquo; media that negatively impacts the reader&rsquo;s experience. They do not offer any specific resolution guidelines, but this should mostly be a non-issue today. The opposite issue is far more likely &mdash; users uploading media that is too large and not optimized for viewing on the web.</p>



<p>The &ldquo;lack of narrative&rdquo; guideline is perhaps the vaguest, and it is unclear how Google will monitor or police <em>narrative</em>. However, the Stories format is about storytelling.</p>



<p>&ldquo;Stories are the key here imo,&rdquo; wrote Jamie Marsland, founder of Pootlepress, in a <a href=\"https://twitter.com/pootlepress/status/1309020235102597122\">Twitter thread</a>. &ldquo;Now we have an open format to tell Stories, and we have an open platform (WordPress) where those Stories can be told easily.&rdquo;</p>



<p>Google specifically states that Stories need a &ldquo;binding theme or narrative structure&rdquo; from one page to the next. Essentially, the company is telling users to use the format for the purpose it was created for. They also do not want users to create incomplete stories where readers must click a link to finish the Story or get information.</p>



<img /><a href=\"https://www.cnn.com/ampstories/entertainment/john-lennon-remembering-the-great-musician\">CNN&rsquo;s Web Story on Remembering John Lennon.</a>



<p>Overly commercial Stories are frowned upon too. While Google will allow affiliate marketing links, they should be restricted to a minor part of the experience.</p>



<p>Closing his Twitter thread, Marsland seemed to hit the point. &ldquo;I&rsquo;ve seen some initial Google Web Stories where the platform is being used as a replacement for a brochure or website,&rdquo; he wrote. &ldquo;In my view that&rsquo;s a huge missed opportunity. If I was advising brands I would say &lsquo;Tell Stories&rsquo; this is a platform for Story Telling.&rdquo;</p>



<p>If users of the plugin follow this advice, their Stories should surface on Google&rsquo;s rich search experiences.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Oct 2020 20:51:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"WPTavern: Stripe Acquires Paystack for $200M+\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106269\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"https://wptavern.com/stripe-acquires-paystack-for-200m?utm_source=rss&utm_medium=rss&utm_campaign=stripe-acquires-paystack-for-200m\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3196:\"<p>The big news in the world of e-commerce today is Stripe&rsquo;s acquisition of <a href=\"https://paystack.com/\">Paystack</a>, a Nigeria-based payments system that is widely used throughout African markets. The company, which became informally known as &ldquo;<a href=\"https://techcrunch.com/2018/08/28/paystack-with-ambitions-to-become-the-stripe-of-africa-raises-8m-from-visa-tencent-and-stripe-itself/\">the Stripe of Africa</a>&rdquo; picked up $8 million in Series A funding in 2018, led by Stripe, Y Combinator, and Tencent. Paystack has grown to power more than 60,000 businesses, including FedEx, UPS, MTN, the Lagos Internal Revenue Service, and AXA Mansar.</p>



<p>Stripe&rsquo;s acquisition of the company is rumored to be more than $200M, a small price to pay for a foothold in emerging African markets. In the company&rsquo;s <a href=\"https://stripe.com/newsroom/news/paystack-joining-stripe\">announcement</a>, Stripe noted that African online commerce is growing 21% year-over-year, 75% faster than the global average. Paystack dominates among payment systems, accounting for more than half of all online transactions in Nigeria.  </p>



<p>&ldquo;In just five years, Paystack has done what many companies could not achieve in decades,&rdquo; Stripe EMEA business lead Matt Henderson said. &ldquo;Their tech-first approach, values, and ambition greatly align with our own. This acquisition will give Paystack resources to develop new products, support more businesses and consolidate the hyper-fragmented African payments market.&rdquo;</p>



<p>Long term, Stripe plans to embed Paystack&rsquo;s capabilities in its Global Payments and Treasury Network (GPTN), the company&rsquo;s programmable infrastructure for global money movement.</p>



<p>&ldquo;Paystack merchants and partners can look forward to more payment channels, more tools, accelerated geographic expansion, and deeper integrations with global platforms,&rdquo; Paystack CEO and co-founder Shola Akinlade said. He also assured customers that there&rsquo;s no need to make any changes to their technical integrations, as Paystack will continue expanding and operating independently in Africa.</p>



<p>Paystack is used as a payment gateway for thousands of WordPress-powered stores through plugins for WooCommerce, Easy Digital Downloads, Paid Membership Pro, Give, Contact Form 7, and an assortment of booking plugins. The company has an official WordPress plugin, <a href=\"https://wordpress.org/plugins/payment-forms-for-paystack/\">Payment Forms for Paystack</a>, which is active on more than 6,000 sites, but most users come through the <a href=\"https://wordpress.org/plugins/woo-paystack/\">Paystack WooCommerce Payment Gateway</a> (20,000+ active installations). </p>



<p>Stripe&rsquo;s acquisition was a bit of positive news during what is currently a turbulent time in Nigeria, as citizens are actively engaged in peaceful protests to end police brutality. Paystack&rsquo;s journey is an encouraging example of the flourishing Nigerian tech ecosystem and the possibilities available for smaller e-commerce companies that are solving problems and removing barriers for businesses in emerging markets. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Oct 2020 22:26:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"WPTavern: Diving Into the Book Review Block Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106273\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:145:\"https://wptavern.com/diving-into-the-book-review-block-plugin?utm_source=rss&utm_medium=rss&utm_campaign=diving-into-the-book-review-block-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6791:\"<p class=\"has-drop-cap\">Created by Donna Peplinskie, a Product Wrangler at Automattic, the <a href=\"https://wordpress.org/plugins/book-review-block\">Book Review Block</a> plugin is nearly three years old. However, it only came to my attention during a recent excursion to find interesting block plugins.</p>



<p>The plugin does pretty much what it says on the cover. It is designed to review books. It generally has all the fields users might need to add to their reviews, such as a title, author, image, rating, and more. The interesting thing is that it can automatically fill in those details with a simple ISBN value. Plus, it supports Schema markup, which may help with SEO.</p>



<p>Rain or shine, sick or well, I read every day. I am currently a month and a half shy of a two-year reading streak. When the mood strikes, I even venture to write a book review. As much as I want to share interesting WordPress projects with the community, I sometimes have personal motives for testing and writing about plugins like Book Review Block. Anything that might help me or other avid readers share our thoughts on the world of literature with others is of interest.</p>



<p>Admittedly, I was excited as I plugged in the ISBN for <em>Rhthym of War</em>, the upcoming fourth book of my favorite fantasy series of all time, <em>The Stormlight Archive</em>. I merely needed to click the &ldquo;Get Book Details&rdquo; button.</p>



<p>Success! The plugin worked its magic and pulled in the necessary information. It had my favorite author&rsquo;s name, the publisher, the upcoming release date, and the page count. It even had a long description, which I could trim down in the editor.</p>



<img />Default output of the Book Review block.



<p>There was a little work to make this happen before the success. To automatically pull in the book details, end-users must have an <a href=\"https://console.developers.google.com/flows/enableapi?apiid=books.googleapis.com&keyType=CLIENT_SIDE&reusekey=true\">API Key</a> from Google. It took me around a minute to set that up and enter it into the field available in the block options sidebar. The great thing about the plugin is that it saves this key so that users do not have to enter each time they want to review a book.</p>



<p>Book Review Block a good starting point. It is straightforward and simple to use. It is not yet at a point where I would call it a <em>great</em> plugin. However, it could be.</p>



<h2>Falling Short</h2>



<p class=\"has-drop-cap\">The plugin&rsquo;s Book Review block should be taking its cues from the core Media &amp; Text block. When you get right down to it, the two are essentially doing the same thing visually. Both are blocks with an image and some content sitting next to each other.</p>



<p>The following is a list of items where it should be following core&rsquo;s lead:</p>



<ul><li>No way to edit alt text (book title is automatically used).</li><li>The image is always aligned left and the content to the right with no way to flip them.</li><li>The media and content are not stackable on mobile views.</li><li>Cannot adjust the size of the image or content columns.</li><li>While inline rich-text controls are supported, users cannot add Heading, List, or Paragraph blocks to the content area and use their associated block options.</li></ul>



<p>That is the shortlist that could offer some quick improvements to the user experience. Ultimately, the problems with the plugin essentially come down to not offering a way to customize the output.</p>



<p>One of the other consistent problems is that the book image the plugin loads is always a bit small. This seems to be more of an issue from the Google Books API than the plugin. Each time I tested a book, I opted to add a larger image &mdash; the plugin does allow you to replace the default.</p>



<p>The color settings are limited. The block only offers a background color option with no way to adjust the text color. A better option for plugin users is to wrap it in a Group block and adjust the background and text colors there.</p>



<img />Book Review block wrapped inside a Group block.



<p>It would also be nice to have wide and full-alignment options, which is an often-overlooked featured from many block plugin authors.</p>



<h2>Using the Media &amp; Text Block to Recreate the Book Review Block</h2>



<p class=\"has-drop-cap\">The Book Review Block plugin has a lot of potential, and I want to see it evolve by providing more flexibility to end-users. Because the Media &amp; Text block is the closest core block to what the plugin offers, I decided to recreate a more visually-appealing design with it.</p>



<img />Book review section created with the Media &amp; Text block.



<p>I made some adjustments on the content side of things. I used the Heading block for the book title, a List block for the book metadata, and a Paragraph block for the description.</p>



<p>The Media &amp; Text block also provided me the freedom to adjust the alignment, stack the image and content on mobile views, and tinker with the size of the image. Plus, it has that all-important field for customizing the image alt attribute.</p>



<p>The Media &amp; Text block gave me much more design mileage.</p>



<p>However, there are limitations to the core block. It does not fully capture some of the features available via the Book Review block. The most obvious are the automatic book details via an ISBN and the Schema markup. Less obvious, there is no easy way to recreate the star rating &mdash; I used emoji stars &mdash; and long description text does not wrap under the image. To recreate that, you would have to opt to use a left-aligned image followed by content.</p>



<p>Overall, the Media &amp; Text block gives me the ability to better style the output, which is what I am more interested in as a user. I want to put my unique spin on things. That is where the Book Review Plugin misfires. It is also the sort of thing that the plugin author can iterate on, offering more flexibility in the future.</p>



<p>This is where many block plugins go wrong, particularly when there is more than one or two bits of data users should enter. Blocks represent freedom in many ways. However, when plugin developers stick to a rigid structure, users can sometimes lose that sense of freedom that they would otherwise have with building their pages.</p>



<p>One of the best blocks, hands down, that preserves that freedom is from the <a href=\"https://wptavern.com/start-a-recipe-blog-with-the-recipe-block-wordpress-plugin\">Recipe Block plugin</a>. It has structured inputs and fields. However, it allows freeform content for end-users to make it their own.</p>



<p>When block authors push beyond this rigidness, users win.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Oct 2020 20:44:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: WooCommerce 4.6 Makes New Home Screen the Default for New and Existing Stores\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106242\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:219:\"https://wptavern.com/woocommerce-4-6-makes-new-home-screen-the-default-for-new-and-existing-stores?utm_source=rss&utm_medium=rss&utm_campaign=woocommerce-4-6-makes-new-home-screen-the-default-for-new-and-existing-stores\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3018:\"<p><a href=\"https://developer.woocommerce.com/2020/10/14/woocommerce-4-6-is-now-available/\">WooCommerce 4.6</a> was released today. The minor release dropped during <a href=\"https://woosesh.com/\">WooSesh</a>, a global, virtual conference dedicated to WooCommerce and e-commerce topics. It features the new home screen as the default for all stores. Previously, the screen was only the default on new stores. Existing store owners had to turn the feature on in the settings.</p>



<div class=\"wp-block-image\"><img /></div>



<p>The updated home screen, originally introduced in version 4.3, helps store admins see activity across the site at a glance and includes an inbox, quick access to store management links, and an overview of stats on sales, orders, and visitors. This redesigned virtual command center arrives not a moment too soon, as anything that makes order management more efficient is a welcome improvement, due to the sheer volume of sales increases that store owners have seen over the past eight months.</p>



<p>In stark contrast to industries like hospitality and entertainment that have proven to be more vulnerable during the pandemic, e-commerce has seen explosive growth. During the State of the Woo address at WooSesh 2020, the WooCommerce team shared that e-commerce is currently estimated to be a $4 trillion market that will grow to $4.5 trillion by 2021. WooCommerce accounts for a sizable chunk of that market with an estimated total payment volume for 2020 projected to reach $20.6 billion, a 74% increase compared to 2019.</p>



<p>The WooCommerce community is on the forefront of that growth and is deeply invested in the products that are driving stores&rsquo; success. The WooCommerce team shared that 75% of people who build extensions also build and maintain stores for merchants, and 70% of those who build stores for merchants also build and maintain extensions or plugins. In 2021, they plan to invest heavily in unlocking more features in more countries and will make WooCommerce Payments the native payment method for the global platform.</p>



<p>A new report from eMarketer shows that <a href=\"https://www.emarketer.com/content/us-ecommerce-growth-jumps-more-than-30-accelerating-online-shopping-shift-by-nearly-2-years\">US e-commerce growth has jumped 32.4%</a>, accelerating the online shopping shift by nearly two years. Experts also predict the top 10 e-commerce players will swallow up more of US retail spending to account for 63.2% of all online sales this year, up from 57.9% in 2019. </p>



<p>The increase in e-commerce spending may not be entirely tied to the pandemic, as some experts believe this historic time will mark permanent changes in consumer spending habits. This is where independent stores, powered by WooCommerce and other technologies, have the opportunity to establish a strong reputation for themselves by providing quality products and reliable service, as well as by being more nimble in the face of pandemic-driven increases in volume.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Oct 2020 03:48:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"WPTavern: The Future of Starter Content: WordPress Themes Need a Modern Onboarding and Importing Tool\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106177\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:245:\"https://wptavern.com/the-future-of-starter-content-wordpress-themes-need-a-modern-onboarding-and-importing-tool?utm_source=rss&utm_medium=rss&utm_campaign=the-future-of-starter-content-wordpress-themes-need-a-modern-onboarding-and-importing-tool\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7385:\"<img />Image credit: <a href=\"https://www.pexels.com/photo/notebook-beside-the-iphone-on-table-196644/\">picjumbo.com on Pexels</a>.



<p class=\"has-drop-cap\">Starter content. It was a grand idea, one of those big dreams of WordPress. It was the <a href=\"https://make.wordpress.org/core/2016/11/30/starter-content-for-themes-in-4-7/\">new kid on the block in late 2016</a>. Like the introduction of post formats in 2011, the developer community was <em>all in</em> for at least that particular release version. Then, it was on to the next new thing, with the feature dropping off the radar for all but the most ardent evangelists. </p>



<p>Some of us were burned over the years, living and dying by the progress of features that we wanted most.</p>



<p>Released in WordPress 4.7, starter content has since seemed to be going the way of post formats. After four years, only <a href=\"https://wpdirectory.net/search/01EMM14PBRE6K8P1Z08KXQQ76D\">141 themes</a> in the WordPress theme directory support the feature. There has been no movement to push it beyond its initial implementation. And, it never <em>really</em> covered the things that theme authors wanted in the first place. It was a start. But, themers were ultimately left to their own devices, rolling custom solutions for something that never panned out &mdash; fully-featured demo and imported content. Four years is an eternity in the web development world, and there is no sense in waiting around to see if WordPress would push forward.</p>



<p>Until Helen Hou-Sand&iacute; published <a href=\"https://make.wordpress.org/core/2020/10/06/revisiting-starter-content-on-org-and-beyond/\">Revisiting Starter Content</a> last week, most would have likely assumed the feature would be relegated to legacy code used by old-school fans of the feature and those theme authors who consider themselves completionists.</p>



<p>&ldquo;Starter content in 4.7 was always meant to be a step one, not the end goal or even the resting point it&rsquo;s become,&rdquo; wrote Hou-Sand&iacute;. &ldquo;There are still two major things that need to be done: themes should have a unified way of showing users how best to put that theme to use in both the individual site and broader preview contexts, and sites with existing content should also be able to take advantage of these sort of &lsquo;ideal content&rsquo; definitions.&rdquo;</p>



<p>Step two should have been this <a href=\"https://core.trac.wordpress.org/ticket/38624\">four-year-old accompanying ticket</a> to allow users to import starter content into existing, non-<em>fresh</em> sites.</p>



<p>Since the initial feature dropped, the theme landscape has changed. Let&rsquo;s face it. WordPress might simply not be able to compete with theme companies that are pushing the limits, creating experiences that users want at much swifter speeds.</p>



<p>Look at where the Brainstorm Force&rsquo;s <a href=\"https://wordpress.org/plugins/astra-sites/\">Starter Templates</a> plugin for its <a href=\"https://wordpress.org/themes/astra/\">Astra</a> theme is now. Users can click a button and import a full suite of content-filled pages or even individual templates. And, the Astra theme is not alone in this. It has become an increasingly-common standard to offer some sort of onboarding to users. GoDaddy&rsquo;s managed WordPress service <a href=\"https://wptavern.com/inside-look-at-godaddys-onboarding-process-for-managed-wordpress-hosting\">fills a similar need</a> on the hosting end.</p>



<img />Astra&rsquo;s starter templates and content.



<p>As WordPress use becomes more widespread, the more it needs a way to onboard users.</p>



<p>This essentially boils down to the question: <em>how can I make it look like the demo?</em></p>



<p>Ah, the age-old question that theme authors have been trying to solve. Whether it has been limitations in the software or, perhaps, antiquated theme review guidelines related to demo and imported content, this has been a hurdle that has been tough to jump. But, some have sailed over it and moved on. While WordPress has seemingly been twiddling its thumbs for years, Brainstorm Force and other theme companies have solved this and continued to innovate.</p>



<p>This is not necessarily a bad thing. There are plenty of ideas to <s>steal</s> copy and pull into the core platform.</p>



<p>One of the other problems facing the WordPress starter content feature is that it is tied to the customizer. With the direction of the block system, it is easy to ask what the future holds. The customizer &mdash; originally named the <em><strong>theme</strong></em> customizer &mdash; was essentially a project to allow users to make front-end adjustments and watch those customizations happen in real time. However, new features like global styles and full-site editing are happening on their own admin screens. Most theme options will ultimately be relegated to global styles, custom templates, block styles, and block patterns. There may not be much left for the customizer to do.</p>



<p>Right now, there are too many places in WordPress to edit the front-end bits of a WordPress site. My hope is that all of these things are ultimately merged into one less-confusing interface. But, I digress&hellip;</p>



<p>Starter content should be rethought. Whoever takes the reins on this needs a fresh take that adopts modern methods from leading theme companies.</p>



<p>The ultimate goal should be to allow theme authors to create multiple sets of templates/content that end-users can preview and import. It should not be tied to whether it is a new site. Any site owner should be able to import content and have it <em>automagically</em> go live. It should also be extendable to allow themes to support page builders like Elementor, Beaver Builder, and many others.</p>



<p>This seems to be in line with Hou-Sand&iacute;&rsquo;s thoughts. &ldquo;For a future release, we should start exploring what it might look like to opt into importing starter content into existing sites, whether wholesale or piecewise,&rdquo; she wrote. &ldquo;Many of us who work in the WordPress development/consulting space tend not to ever deal in switching between public themes on our sites, but let&rsquo;s not forget that&rsquo;s a significant portion of our user audience and we want to continue to enable them to not just publish but also publish in a way that matches their vision.&rdquo;</p>



<p>Let&rsquo;s do it right this go-round, keep a broad vision, and provide an avenue for theme authors to adopt a standardized core WordPress method instead of having everyone build in-house solutions.</p>



<p>I haven&rsquo;t even touched on the <a href=\"https://meta.trac.wordpress.org/ticket/30#comment:66\">recent call to use starter content</a> for WordPress.org theme previews. It will take more than ideas to excite many theme authors about the possibility. That ticket has sat for seven years with no progress, and most have had it on their wish list for much longer. It is an interesting proposal, one that has been tossed around in various team meetings for years.</p>



<p>Like so many other things, theme authors have either given up hope or moved onto doing their own thing. They need to be brought into the fold, not only as third parties who are building with core WordPress tools but as developers who are contributing to those features.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 14 Oct 2020 20:07:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:116:\"WPTavern: Google Podcasts Manager Adds More Data from Search: Impressions, Top-Discovered Episodes, and Search Terms\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106191\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:271:\"https://wptavern.com/google-podcasts-manager-adds-more-data-from-search-impressions-top-discovered-episodes-and-search-terms?utm_source=rss&utm_medium=rss&utm_campaign=google-podcasts-manager-adds-more-data-from-search-impressions-top-discovered-episodes-and-search-terms\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2568:\"<p>Google <a href=\"https://twitter.com/googlewmc/status/1316030688508825600\">announced</a> an expansion of listener engagement metrics today for those using its Podcast Manager. Previously, audience insights included data about the types of devices listeners are using, where listeners tune in and drop off during a given episode, total number of listens, and listening duration, but the service lacked analytics regarding how visitors were discovering the podcast.</p>



<p>Google is remedying that today by expanding the dashboard to show impressions, clicks, top-discovered episodes, and search terms that brought listeners to the podcast. This information can help podcasters understand how their content is getting discovered so they can better tailor their episodes to attract more new listeners. </p>



<p>The podcasting industry has seen remarkable growth over the past five years, which previously led experts to project that marketers will spend&nbsp;<a href=\"https://www.searchenginejournal.com/marketers-will-spend-1-billion-on-podcast-advertising-by-2021-report/316499/#close\">over $1 billion in advertising by 2021</a>. After the pandemic hit, podcast listening took a downturn in the U.S. but at the same time, podcast creators have found more time to <a href=\"https://wptavern.com/podcasting-during-the-pandemic-castos-sees-300-growth-in-new-podcasters\">create new shows and episodes</a>. Businesses are turning to the medium to supplement traditional marketing methods that no longer have the same impact now that consumer spending habits heavily favor online products.</p>



<p>Along with the new metrics available inside Google Podcasts Manager, the company also published a <a href=\"https://support.google.com/podcast-publishers/thread/76595315\">guide to optimizing podcasts</a> for Google Search. It highlights four important items for making sure a podcast can be found:</p>



<ul><li>Detailed show and episode metadata</li><li>Ensure the podcast&rsquo;s webpage and RSS data match</li><li>Include cover art</li><li>Ensure Googlebot can access your audio files </li></ul>



<p>A detailed breakdown of your audience&rsquo;s listening habits isn&rsquo;t worth much if you&rsquo;re having trouble getting your podcast discovered. Any podcasting plugin for WordPress should handle these basic optimization recommendations, but if you are still having trouble being found via Google, you can dig deeper into the <a href=\"https://support.google.com/podcast-publishers/answer/9889864\">podcast setup guide</a> for more detailed recommendations. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 13 Oct 2020 22:57:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Are Block-Based Widgets Ready To Land in WordPress 5.6?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106175\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:173:\"https://wptavern.com/are-block-based-widgets-ready-to-land-in-wordpress-5-6?utm_source=rss&utm_medium=rss&utm_campaign=are-block-based-widgets-ready-to-land-in-wordpress-5-6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8214:\"<p class=\"has-drop-cap\">Two weeks ago, the Gutenberg team put out an <a href=\"https://make.wordpress.org/core/2020/09/30/call-for-testing-the-widgets-screen-in-gutenberg-9-1/\">open call for block-based widgets feedback</a>. I had already written a <a href=\"https://wptavern.com/gutenberg-8-9-brings-block-based-widgets-out-of-the-experimental-stage\">lengthy review</a> of the new system earlier in September but was asked by a member of the team to share my thoughts on the most recent iteration. With the upcoming freeze for WordPress 5.6 Beta 1 just a week away, I figured it would not hurt to do another deep dive.</p>



<p>For reference, my latest testing is against version 9.2.0-alpha-172f589 of the Gutenberg plugin, which was a build from earlier today. Gutenberg development moves fast, but everything should be accurate to that point.</p>



<p>Ultimately, many of the problems I pointed out over a month ago still exist. However, the team has cleaned most of the minor issues, such as pointing the open/close arrows for sidebars (block areas) in the correct direction and making it more consistent with the post-editing screen. The UI is much more polished.</p>



<p>Before I dive into all the problems, I want to answer the question I am proposing. Yes, the block-based widget system <em>will be</em> ready for prime time when WordPress 5.6 lands. It is not there yet, but it is at a point where there is a clear finish line that is reachable in the next two months.</p>



<p>I will ignore the failure of block-based widgets in the customizer, which landed in Gutenberg 8.9 and was <a href=\"https://wptavern.com/gutenberg-9-1-adds-patterns-category-dropdown-and-reverts-block-based-widgets-in-the-customizer\">removed in 9.1</a>. I will also look past the recent proposal to <a href=\"https://github.com/WordPress/gutenberg/issues/26012\">reconstruct the widgets screen</a> to use the Customize API, at least for now. There is a boatload of problems that block-based widgets present for the customizer, and those problems are insurmountable for WordPress 5.6. Long term, WordPress needs to have a single place for editing widget/block areas. Users will likely have to live with some inconsistencies for a while.</p>



<p>Assuming the team does not try to throw a last-minute Hail Mary and implement full editing of blocks in the customizer this round, it is safe to say that block-based widgets are well on their way toward a successful WordPress 5.6 debut.</p>



<h2>The User Experience</h2>



<img />Block-based widgets screen.



<p class=\"has-drop-cap\">As a user, I genuinely enjoy using the new Widgets admin screen. The open-ended, free-form block areas create untold possibilities for designing my WordPress sites. Traditional widgets were limited in scope. Users were buckled down to a handful of core widgets, possibly some plugin widgets, and whatever their theme author offered up. However, with blocks, the pool of choices expands to at least triple the out-of-the-box options (I am not counting embed-type blocks individually). Plus, blocks provide a far more extensive set of design options than a traditional widget.</p>



<p>In comparison, traditional widgets are outdated. Blocks are superior in almost every way. However, there are still problems with this new system.</p>



<p>The biggest issue right now is that end-users can exit the Widgets screen without saving their changes. There is no warning to let them know that all their work is about to be lost in the ether. This is one of those <em>OMGBBQ</em>-level items that need to happen before WordPress 5.6 drops.</p>



<p>One nice-to-have-but-not-necessary feature would be the ability to drag blocks from one block area to another. In the old widgets system, users could move widgets from sidebar to sidebar. The current alternative is to copy a widget, paste it in a new block area, and remove the original.</p>



<p>I am also not a fan of not having an option for the top toolbar, which is available on the post-editing screen. One of the reasons for using this toolbar is because I dislike the default popup toolbar on individual blocks. It is distracting and often gets in the way of my work.</p>



<p>Legacy widgets seem to still be a work in progress. The Legacy Widget block did not work at all for me at times. Then, it magically began to work. However, Gutenberg does now automatically add registered third-party widgets to the block inserter just as if they were blocks.</p>



<img />Getting a plugin&rsquo;s widget to work.



<p>This presented its own problems. The only way I managed to make third-party plugin widgets work was to insert the widget, save, and refresh the widgets screen. At that point, the widgets appeared and became editable.</p>



<h2>The Theme Author Experience</h2>



<p class=\"has-drop-cap\">One of my biggest concerns for theme authors right now is that there does not seem to be any documentation in the <a href=\"https://developer.wordpress.org/block-editor/developers/themes/\">block editor handbook</a>. There is plenty of time to make that happen, but there are things theme authors need to be aware of. Having a centralized location, even while the feature is under development, would help them gear up for the 5.6 release.</p>



<p>Some of these questions, which may be answered in various Make blog posts, should exist on a dedicated documentation page:</p>



<ul><li>How can a theme opt out of block-based widgets?</li><li>What are the hooks to add custom styles for the Widgets screen?</li><li>Can themes target specific sidebar styles on the Widgets screen?</li><li>Is it possible to consistently style sections like traditional widgets on the front end?</li><li>Can themes opt into wide and full-alignment within block areas, which could essentially be used similarly to the post content area?</li></ul>



<p>These are some of the questions I would want to be answered as a former theme author. I am no longer in the thick of the theme design game and presume that those who are would have a larger list of questions.</p>



<p>One less-obvious piece of documentation should center on how to handle fallbacks or default <em>widgets</em>. Traditionally, themes that needed to show a default set of widgets would check if the sidebar has widgets and fall back to using <code>the_widget()</code> to output one or more defaults. While theme authors can still do that, we should start to transition them across the board to the block system.</p>



<p>Should theme authors copy/paste block HTML as a fallback? Would the starter content system be better for this, and can starter widget content handle blocks? What is the recommended method for widget fallbacks in WordPress 5.6?</p>



<p>There is still the <a href=\"https://github.com/WordPress/gutenberg/issues/25174\">ongoing issue</a> of how theme authors should handle the traditional widget and widget title wrapper HTML in the new block paradigm. One patch added since the Gutenberg 9.1 release <a href=\"https://github.com/WordPress/gutenberg/pull/25693\">wraps every top-level block</a> with the widget wrapper. If this lands in the 9.2 release, it will likely make the issue worse.</p>



<p>In the traditional system, both the widget title and content are wrapped within a container together. However, if a user adds a Heading block (widget title) and another block (widget content), each block is wrapped separately with the theme&rsquo;s widget wrappers. The only way to rectify the situation as it stands is for end-users to add a Group block for each &ldquo;widget&rdquo; they want, which would require an extensive amount of re-education for WordPress users. It is not an ideal scenario.</p>



<img />Each block is wrapped as an individual section.



<p>Instead of attempting to directly &ldquo;fix&rdquo; this issue, WordPress should instead do nothing to the output. Blocks and traditional widgets are fundamentally different.</p>



<p>Let theme authors take the reins on this one and explore possibilities. However, give them the tools to do so, such as <a href=\"https://wptavern.com/addressing-the-theme-design-problem-with-gutenbergs-new-block-based-widgets-system\">supporting block patterns</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 13 Oct 2020 21:35:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"WPTavern: WordCamp Austin 2020 Finds Success with VR Experience for Sessions and Networking\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106119\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:227:\"https://wptavern.com/wordcamp-austin-2020-finds-success-with-vr-experience-for-sessions-and-networking?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-austin-2020-finds-success-with-vr-experience-for-sessions-and-networking\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7246:\"<p><a href=\"https://austin.wordcamp.org/2020/\">WordCamp Austin 2020</a> attendees are raving about their experiences attending the virtual event last Friday. It was no secret that the camp&rsquo;s organizers planned to use&nbsp;<a href=\"https://hubs.mozilla.com/\">Hubs Virtual Rooms</a>&nbsp;by Mozilla to create a unique environment, but few could imagine how much more interactive and personalized the experience would be than a purely Zoom-based WordCamp.</p>



<p>After selecting a custom avatar, attendees entered the venue using a VR headset or the browser to check out sessions or network in the hallway track.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Here&rsquo;s a small taste of the experience at <a href=\"https://twitter.com/WordCampATX?ref_src=twsrc%5Etfw\">@WordCampATX</a> today. <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> logos and no sponsor banners on any elevator doors. <a href=\"https://twitter.com/hashtag/WCATX?src=hash&ref_src=twsrc%5Etfw\">#WCATX</a> <a href=\"https://t.co/Nv2p2VchXf\">pic.twitter.com/Nv2p2VchXf</a></p>&mdash; David Bisset (@dimensionmedia) <a href=\"https://twitter.com/dimensionmedia/status/1314643915904086018?ref_src=twsrc%5Etfw\">October 9, 2020</a></blockquote>
</div>



<p>Speaker and Q&amp;A sessions were broadcast through Zoom but organizers can also embed YouTube videos and streams within the standalone VR environment.</p>



<p>&ldquo;The VR experience was the most life-like WordCamp experience I&rsquo;ve had since the start of global lockdowns,&rdquo; attendee and speaker David Vogelpohl said. &ldquo;You could attend sessions in one of two virtual presentation halls depending on what track you wanted to see at that time. The speaker presented on a virtual stage and you could see the other attendees watching the presentation.&rdquo;</p>



<p>Vogelpohl said he enjoyed his experience getting to know others in the Slack and VR venue. Organizers preserved the general vibe of the &ldquo;hallway track&rdquo; to recreate what is arguably one of the most valuable aspects of in-person WordCamps.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">So cool &ndash; checking out the Virtual Space of WordCamp Austin &ndash; love the background noise of people talking, ran into <a href=\"https://twitter.com/ChrisWiegman?ref_src=twsrc%5Etfw\">@ChrisWiegman</a> and <a href=\"https://twitter.com/Josh412?ref_src=twsrc%5Etfw\">@Josh412</a> <a href=\"https://twitter.com/hashtag/WCATX?src=hash&ref_src=twsrc%5Etfw\">#WCATX</a> <a href=\"https://t.co/68EdgDN2Om\">pic.twitter.com/68EdgDN2Om</a></p>&mdash; Birgit Pauli-Haack (@bph) <a href=\"https://twitter.com/bph/status/1314570573792632832?ref_src=twsrc%5Etfw\">October 9, 2020</a></blockquote>
</div>



<p>&ldquo;In the hallway track between the virtual presentation halls was a large foyer where you could meet new people, spot a friend speaking with someone else, and virtually step aside from a group conversation to have a private conversation,&rdquo; Vogelpohl said.</p>



<p>&ldquo;It was great to see folks like Josepha circling around speaking with attendees, Josh Pollock nerding out in a corner with a group of advanced WP developers, and having random friends drop into a conversation I was having with a group of others. While VR WordCamp doesn&rsquo;t wholly&nbsp;replace the value of attending a WordCamp live, a lot of the best parts of meeting and collaborating with others was captured in the VR context.&rdquo;</p>



<p>The live music interludes, which showcased talents from around the community, also provided a way for virtual attendees to stay connected while waiting for the next session. </p>



<h2>Behind the Scenes with Anthony Burchell: Creative Director for WordCamp Austin&rsquo;s Virtual World</h2>



<p>WordPress core contributor Anthony Burchell, who started a <a href=\"https://broken.place/\">company</a> dedicated to creating interactive XR sound and art experiences, was the creative director behind the WordCamp Austin&rsquo;s VR backdrop.</p>



<p>&ldquo;For WordCamp Austin we wanted to give folks something to be excited about outside of the typical webcam and chat networking,&rdquo; Burchell said. &ldquo;I feel that virtual events are not utilizing the networking layer nearly enough to make folks feel like they are really at an event. I&rsquo;ve seen many compelling formats for virtual events utilizing webcams and chat rooms, but in the end, it feels like there&rsquo;s been a missing element of presence; something video games and virtual reality excel at.&rdquo;</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Virtual mission control for <a href=\"https://twitter.com/hashtag/WCATX?src=hash&ref_src=twsrc%5Etfw\">#WCATX</a> <a href=\"https://t.co/WyrFkIsW2Q\">pic.twitter.com/WyrFkIsW2Q</a></p>&mdash; Anthony Burchell (@antpb) <a href=\"https://twitter.com/antpb/status/1314592863569707008?ref_src=twsrc%5Etfw\">October 9, 2020</a></blockquote>
</div>



<p>Setting up the virtual world involves spinning up a self-hosted instance of Hubs Cloud, which Burchell said is very similar to the complexity of making a WordPress site.</p>



<p>&ldquo;The most time consuming part of creating a 3D world for an event is making the 3D assets for the space,&rdquo; Burchell said. &ldquo;In total I streamed 11 hours of video leading up to the event to give a glimpse into the process.&rdquo;</p>



<p>Burchell&rsquo;s YouTube <a href=\"https://www.youtube.com/playlist?list=PLi1xKbv0cklpzJCgXyKi-pp3KANYJLqGk\">playlist</a> documents the incredible amount of work that went into creating the WordCamp&rsquo;s virtual venue for attendees to enjoy. </p>



<p>&ldquo;While it took quite a bit of time to prepare, the code and assets are completely reusable for another event,&rdquo; Burchell said. &ldquo;A lot of the time was spent trying to make the space purpose built for the goals of the camp. Much like a real WordCamp, I found the majority of folks packing into the theater rooms for presentations and dipping out a little early to network with friends in the hallway area. That was very much by design!&rdquo;</p>



<p>Burchell and the other organizers were careful to ensure that the Hubs space was not the primary viewing experience of the camp but rather an extension of the networking activities that attendees could drop in on. The event had nearly identical numbers of attendees joining the virtual space as it did for those joining the video channels. At the end of the afterparty, Burchell turned on flying for all attendees to conclude the successful event:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>&ldquo;With Hubs we were able to give attendees the ability to express themselves within a venue vs within a camera and chat box,&rdquo; Burchell said. &ldquo;It was incredible to see characteristics of folks in the community shine through a virtual avatar! Just the simple act of seeing your WordCamp friends in the hallway joking and chatting just as they would at a real life event was enough to make me feel like I was transported to a real WordCamp.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 12 Oct 2020 22:31:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: Privacy-Conscious WordPress Plugin Caches and Serves Gravatar Images Locally\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105825\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/privacy-conscious-wordpress-plugin-caches-and-serves-gravatar-images-locally?utm_source=rss&utm_medium=rss&utm_campaign=privacy-conscious-wordpress-plugin-caches-and-serves-gravatar-images-locally\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5285:\"<p class=\"has-drop-cap\">Ari Stathopoulos released his new <a href=\"https://wordpress.org/plugins/local-gravatars/\">Local Gravatars</a> plugin last week. The goal of the plugin is to allow site owners to take advantage of the benefits of a global avatar system while mitigating privacy concerns by hosting the images locally.</p>



<p>In essence, it is a caching system that stores the images on the site owner&rsquo;s server. It is an idea that Peter Shaw <a href=\"https://wptavern.com/local-avatars-in-wordpress-yes-please#comment-338262\">proposed in the comments</a> on an earlier Tavern article covering <a href=\"https://wptavern.com/local-avatars-in-wordpress-yes-please\">local avatar upload</a>. It is a middle ground that may satisfy some users&rsquo; issues with how avatars currently work in WordPress.</p>



<p>&ldquo;I am one of the people that blocks analytics, uses private sessions when visiting social sites, I use DuckDuckGo instead of Google, and I don&rsquo;t like the &lsquo;implied&rsquo; consents,&rdquo; said Stathopoulos. &ldquo;I built the plugin for my own use because I don&rsquo;t know what Gravatar does, I don&rsquo;t understand the privacy policies, and I am too lazy to spend two hours analyzing them. It&rsquo;s faster for me to build something that is safe and doesn&rsquo;t leave any room for misunderstandings.&rdquo;</p>



<p>He is referring to Automattic&rsquo;s extensive <a href=\"https://automattic.com/privacy/\">Privacy Policy</a>. He said it looks benign. However, he does not like the idea of any company being able to track what sites he visits without explicit consent.</p>



<p>&ldquo;And when I visit a site that uses Gravatar, some information is exposed to the site that serves them &mdash; including my IP,&rdquo; said Stathopoulos. &ldquo;Even if it&rsquo;s just for analytics purposes, I don&rsquo;t think the company should know that page A on site B got 1,000 visitors today with these IPs from these countries. There is absolutely no reason why any company not related to the page I&rsquo;m actually visiting should have any kind of information about my visit.&rdquo;</p>



<p>The Local Gravatars plugin must still connect to the Gravatar service. However, the connection is made on the server rather than the client. Stathopoulos explained that the only information exposed in this case is the server&rsquo;s IP and nothing from the client, which eliminates any potential privacy concerns.</p>



<h2>The Latest Plugin Update</h2>



<p class=\"has-drop-cap\">Stathopoulos updated the plugin earlier today to address some performance concerns for pages that have hundreds or more Gravatar images. In the version 1.0.1 update, he added a maximum processing time of five seconds and changed the cache cleanup process from daily to weekly. Both of these are filterable via code.</p>



<p>&ldquo;Now, if there are Gravatars missing in a page request, it will get as many as it can, and, after five seconds, it will stop,&rdquo; said Stathopoulos. &ldquo;So if there are 100 Gravatars missing and it gets the first 20, the rest will be blank (can be filtered to use a fallback URL, or even fall back to the remote URL, though that would defeat the privacy improvement). The next page request will get the next 20, and so on. At some point, all will be there, and there will be no more delays.&rdquo;</p>



<p>He did point out that performance could temporarily suffer when installing it on a site that has individual posts with 1,000s of comments and a lot of traffic. However, nothing would crash on the site, and the plugin should eventually lead to a performance boost in this scenario. For such large sites, owners could use the existing filter hooks to tweak the settings.</p>



<p>Right now, the plugin is primarily an itch he wanted to scratch for his own purposes. However, if given enough usage and feedback, he may include a settings screen to allow users to control some of the currently-filterable defaults, such as the cleanup timeframe and the maximum process time allowed.</p>



<h2>The Growing List of Alternatives</h2>



<p class=\"has-drop-cap\">With growing concerns around privacy in the modern world, Local Gravatars is another tool that end-users can employ if they have any concerns around the Gravatar service. For those who are OK with an auto-generated avatar, <a href=\"https://wptavern.com/privacy-first-gravatar-replacement-pixel-avatars-module-released-for-the-toolbelt-wordpress-plugin\">Pixel Avatars</a> may be a solution.</p>



<p>&ldquo;I&rsquo;ve seen some of them, and they are wonderful!&rdquo; Stathopoulos said of alternatives for serving avatars. &ldquo;However, this plugin is slightly different in that the avatars the user already has on Gravatar.com are actually used. They can see the image they have uploaded. The user doesn&rsquo;t need to upload a separate avatar, and an automatic one is not used by default.&rdquo;</p>



<p>He would not mind using an auto-generated avatar when commenting on blogs or news sites at times. However, Stathopoulos prefers Gravatar for community-oriented sites.</p>



<p>&ldquo;My Gravatar is part of my online identity, and when I see, for example, a comment from someone on WordPress.org, I know who they are by their Gravatar,&rdquo; he said.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 12 Oct 2020 21:06:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: WordPress 5.6 to Introduce Application Passwords for REST API Authentication\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105997\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/wordpress-5-6-to-introduce-application-passwords-for-rest-api-authentication?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-5-6-to-introduce-application-passwords-for-rest-api-authentication\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2604:\"<p>In 2015, WordPress 4.4 introduced a REST API, but one thing that has severely limited its broader use is the lack of  authentication capabilities for third-party applications. After considering the benefits and drawbacks of many different types of authentication systems, George Stephanis published a <a href=\"https://make.wordpress.org/core/2020/09/23/proposal-rest-api-authentication-application-passwords/\">proposal</a> for integrating <a href=\"https://github.com/WP-API/authentication/issues/13\">Application Passwords</a>, into core. </p>



<p>Stephanis highlighted a few of the major benefit that were important factors in the decision to use Application Passwords: the ease of making API requests, ease of revoking credentials, and the ease of requesting API credentials. The project is available as a standalone <a href=\"https://wordpress.org/plugins/application-passwords/\">feature plugin</a>, but Stephanis and his collaborators recommended WordPress merge a <a href=\"https://github.com/WordPress/wordpress-develop/pull/540\">pull request</a> that is based off the feature plugin&rsquo;s codebase.</p>



<p>After WordPress 5.6 core tech lead Helen Hou-Sandi gave the green light for Application Passwords to be merged into core, the developer community responded enthusiastically to the news.</p>



<p>&ldquo;I am/we are 100% in favor of this,&rdquo; Joost deValk commented on the proposal. &ldquo;Opening this up is like opening the dawn of a new era of WordPress based web applications. Suddenly authentication is not something you need to fix when working with the&nbsp;API&nbsp;and you can just build awesome stuff.&rdquo;</p>



<p>Stephanis&rsquo; proposal also mentioned how beneficial a REST API authentication system would be for the <a href=\"https://make.wordpress.org/mobile/\">Mobile teams</a>&lsquo; contributors who are relying on awkward workarounds while integrating Gutenberg support.</p>



<p>&ldquo;This would be a first step to replace the use of XMLRPC in the mobile apps and it would allow us to add more features for self hosted users,&rdquo; Automattic mobile engineer Maxime Biais said.</p>



<p>After the REST API was added to WordPress five years ago, many had the expectation that WordPress-based web applications would start popping up everywhere. Without a reliable authentication system, it wasn&rsquo;t easy for developers to just get inspired and build something quickly. Application Passwords in WordPress 5.6 will open up a lot of possibilities for those who were previously deterred by the lack of core methods for authenticating third-party access.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Oct 2020 23:01:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: WP Agency Summit Begins Its Second Annual Virtual Event October 12\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105160\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:197:\"https://wptavern.com/wp-agency-summit-begins-its-second-annual-virtual-event-october-12?utm_source=rss&utm_medium=rss&utm_campaign=wp-agency-summit-begins-its-second-annual-virtual-event-october-12\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6357:\"<p class=\"has-drop-cap\">Jan Koch, the founder and host of WP Agency Summit, is kicking off his <a href=\"https://wpagencysummit.com/\">second annual event on October 12</a>. The five-day event will feature 37 speakers from a wide range of backgrounds across the WordPress industry. It is a free virtual event that anyone can attend.</p>



<p>&ldquo;The focus for the 2020 WP Agency Summit is showing attendees how to bring back the fun into scaling their agencies,&rdquo; said Koch. &ldquo;It is all about reducing the daily hustle by teaching how to successfully build and manage teams, how to work with enterprises (allowing for fewer customers but bigger projects), how to build sustainable recurring revenue, and how to position your agency to dominate your niche.&rdquo;</p>



<p>This year&rsquo;s event includes three major changes to make the content more accessible to a larger group of people. Each session will be available between October 12 &ndash; 16 instead of the previous 48-hour window that attendees had to find time for in 2019.</p>



<p>After the event has concluded, access to the content will be behind a paywall. Koch reduced the price to $77 for lifetime access for those who purchase pre-launch, which will increase to $127 during the event. Last year&rsquo;s prices ballooned to $497, which meant that it was simply not affordable for many who found it too late.</p>



<p>Some of the proceeds this year are going toward transcribing all the videos so that hearing-impaired users can enjoy the content.</p>



<p>This year&rsquo;s event will also focus on a virtual networking lounge for attendees. &ldquo;I&rsquo;ve seen how well it worked at the WP FeedBack Summit &mdash; we even had BobWP record a podcast episode on the fly in that lounge!&rdquo; said Koch. &ldquo;I&rsquo;ve seen many new friendships develop, people connecting with new suppliers or getting themselves booked on podcasts, and sharing experiences about their businesses.&rdquo;</p>



<p>The lounge will be open during the entirety of the summit, which will allow attendees to jump into the conversation on their own time.</p>



<h2>A More Diverse Speaker Lineup</h2>



<p class=\"has-drop-cap\">Koch received some backlash for the lack of gender diversity last year. <a href=\"https://wptavern.com/wp-agency-summit-kicks-off-december-6\">The 2019 event</a> had over 20 speakers from a diverse male lineup. However, only four women from our industry led sessions.</p>



<p>When asked about this issue in 2019, Koch responded, &ldquo;I recognize this as a problem with my event. The reason I have so much more male than female speakers is quite simple, the current speaker line-up is purely based on connections I had when I started planning for the event. It was a relatively short amount of time for me, so I wasn&rsquo;t able to build relationships with more female WP experts beforehand.&rdquo;</p>



<p>The host said he paid attention to the feedback he received. While not hitting the 50/50 split goal he had for 2020&rsquo;s event, 16 of the 37 speakers are women.</p>



<p>Koch said he strived to get speakers from a wider range of backgrounds. He wanted to bring in both freelancers and multi-million dollar agency owners. He also focused on getting people from multiple countries to represent WordPress agencies.</p>



<p>&ldquo;I did reach out to around 130 people four months before the event to make new connections,&rdquo; he said. &ldquo;The community around the Big Orange Heart (a non-profit for mental well-being) also helped a lot with introducing me to new members of the WP community.&rdquo;</p>



<p>Koch said he learned two valuable lessons when branching out beyond his existing connections for this year&rsquo;s event:</p>



<blockquote class=\"wp-block-quote\"><p>Firstly, don&rsquo;t hesitate to reach out to people you think will never talk to you because they&rsquo;re running such big companies. For example, I immediately got confirmations from Mario Peshev from Devrix, Brad Touesnard from Delicious Brains, or Marieke van de Rakt from Yoast. When first messaging them, I had little hope they&rsquo;d set aside time to jump on an interview with me &ndash; but they were super supportive and accommodating! The WordPress community really is a welcoming environment if you approach people in a humble way.</p><p>Secondly, build connections with sincerity. Do not just focus on what you can get from that connection but how you can help the other person. I know this sounds cheesy and you&rsquo;ve heard this quite often &mdash; but it is true. Once I got the first response from new contacts and explained my goal of connecting fellow WordPress community members virtually, most immediately agreed because they also benefit from new connections and being positioned as a thought-leader in this event.</p></blockquote>



<h2>WP Agency Summit? WP FeedBack Summit?</h2>



<p class=\"has-drop-cap\">For readers who recall the Tavern&rsquo;s coverage of the <a href=\"https://wptavern.com/wp-feedback-kicks-off-free-virtual-summit-for-wordpress-professionals-on-april-27\">WP FeedBack Summit</a> earlier this year, the article specifically stated that the WP FeedBack Summit was a continuation of 2019&rsquo;s WP Agency Summit. The official word at the time from WP FeedBack&rsquo;s public relations team was the following:</p>



<blockquote class=\"wp-block-quote\"><p>Last year&rsquo;s event, the WP Agency Summit has been rebranded under the umbrella of WP FeedBack&rsquo;s brand when Jan Koch the host of last&rsquo;s year WP Agency Summit joined WP FeedBack as CTO.</p></blockquote>



<p>Koch said that it was a standalone event and not directly connected to WP Agency Summit but had the same target audience. However, the WP FeedBack Summit did use the previous WP Agency Summit&rsquo;s stats and data to promote the event.</p>



<p>&ldquo;The WP FeedBack Summit was hosted under the WP FeedBack brand because I joined their team as CTO in March this year,&rdquo; he said. &ldquo;Vito [Peleg] and I had the idea to host a virtual conference around WordPress because of WordCamp Asia being canceled &mdash; we wanted to help connect the community online through our summit.</p>



<p>Koch left WP FeedBack soon after the summit ended and is currently back on his own and has a goal of making WP Agency Summit a yearly event.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Oct 2020 17:01:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Navigation Screen Sidelined for WordPress 5.6, Full-Site Editing Edges Closer to Public Beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105839\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:247:\"https://wptavern.com/navigation-screen-sidelined-for-wordpress-5-6-full-site-editing-edges-closer-to-public-beta?utm_source=rss&utm_medium=rss&utm_campaign=navigation-screen-sidelined-for-wordpress-5-6-full-site-editing-edges-closer-to-public-beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4676:\"<p>The new block-based navigation screen is once again delayed after it was originally <a href=\"https://wptavern.com/new-block-based-navigation-and-widgets-screens-sidelined-for-wordpress-5-5\">slated for WordPress 5.5</a> and then put <a href=\"https://wptavern.com/wordpress-5-6-development-kicks-off-with-all-women-release-squad\">on deck for 5.6</a>. Contributors have confirmed that it will not be landing in WordPress core until 2021 at the earliest.</p>



<p>&ldquo;The Navigation screen is still in experimental state in the&nbsp;Gutenberg&nbsp;plugin, so it hasn&rsquo;t had any significant real-world use and testing yet,&rdquo; Editor Tech Lead&nbsp;Isabel Brison said. She made the call to remove it from the 5.6 lineup after the feature missed the deadline for&nbsp;<a href=\"https://github.com/WordPress/gutenberg/issues/24683\">bringing it out of the experimental state</a>. It still requires a substantial amount of development work and accessibility feedback before moving forward.  </p>



<p>Contributors will focus instead on making sure the Widgets screen gets out the door for 5.6 and plan to pick up again on Navigation towards the end of November. </p>



<p>WordPress 5.6 lead Josepha Haden gave an <a href=\"https://make.wordpress.org/core/2020/10/06/update-wordpress-5-6-release-progress/\">update</a> this week on the progress of all the anticipated features, including the planned public beta for full-site editing (FSE).</p>



<p>&ldquo;I don&rsquo;t expect FSE to be feature complete by the time WP5.6 is released,&rdquo; Haden said. &ldquo;What I expect is that FSE will be functional for simple, routine user flows, which we can start testing and iterating on. That feedback will also help us more confidently design and build our complex user flows.&rdquo;</p>



<p>Frank Klein, an engineer at Human Made, asked in the <a href=\"https://make.wordpress.org/themes/2020/10/07/block-based-themes-and-wordpress-5-6/#comment-44126\">comments</a> of another update why full-site editing is being tied to 5.6 progress in the first place, since it will still only be available in the plugin at the time of release. </p>



<p>&ldquo;The main value is that it provides a good checkpoint along the path of&nbsp;FSE&rsquo;s development,&rdquo; <a href=\"https://profiles.wordpress.org/kjellr/\">Kjell Reigstad</a> said.&nbsp;&ldquo;Full-site editing is very much in progress. It is still experimental, but the general approach is coming into view, and becoming clearer with every plugin release.&rdquo;</p>



<p>Reigstad posted an update on what developers can expect regarding <a href=\"https://make.wordpress.org/themes/2020/10/07/block-based-themes-and-wordpress-5-6/\">block-based theming and the upcoming release,</a> since the topic is closely tied to full-site editing. He emphasized that the infrastructure is already in place and that, despite it still being experimental, future block-based themes should work in a similar way to how they are working now.</p>



<p>&ldquo;The focus is now shifting towards polishing the user experience: using the site editor to create templates, using the query block, iterating on the post and site blocks, and implementing the Global Styles&nbsp;UI,&rdquo; Reigstad said.</p>



<p>&ldquo;The main takeaway is that when 5.6 is released, the full-site editing feature set will look similar to where it is today, with added polish to the UI, and additional features in the Query block.&rdquo;</p>



<p>Theme authors are entering a new time of uncertainty and transition, but Reigstad reassured the community that themes as we know them today are not on track to be phased out in the immediate future.</p>



<p>&ldquo;There is currently no plan to deprecate the way themes are built today,&rdquo; Reigstad said. &ldquo;Your existing themes will continue to work as they always have for the foreseeable future.&rdquo; He also encouraged contributors to get involved in an initiative to&nbsp;<a href=\"https://github.com/WordPress/gutenberg/issues/24803\">help theme authors transition to block-based themes</a>. (This project is not targeted for the 5.6 release.)</p>



<p>Developers can follow important <a href=\"https://github.com/WordPress/gutenberg/issues/24551\">FSE project milestones</a> on GitHub, and subscribe to the weekly&nbsp;<a href=\"https://make.wordpress.org/themes/tags/gutenberg-themes-roundup/\">Gutenberg + Themes updates</a> to track progress on block-based theming. A block-based version of the&nbsp;<a href=\"https://make.wordpress.org/core/2020/09/23/introducing-twenty-twenty-one/\">Twenty Twenty-One theme</a> is in the works and should pick up steam after 5.6 beta 1, expected on October 20.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Oct 2020 22:57:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: EditorPlus 1.9 Adds Animation Builder for the Block Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105678\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:181:\"https://wptavern.com/editorplus-1-9-adds-animation-builder-for-the-block-editor?utm_source=rss&utm_medium=rss&utm_campaign=editorplus-1-9-adds-animation-builder-for-the-block-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4535:\"<p class=\"has-drop-cap\">Munir Kamal shows no signs of slowing down. He continues to push forward with new features for his <a href=\"https://wordpress.org/plugins/editorplus/\">EditorPlus plugin</a>, which allows end-users to customize the look of the blocks in their posts and pages. He calls it the &ldquo;no-code style editor for WordPress.&rdquo; </p>



<p><em>The latest addition to his plugin?</em> Animation styles for every core block.</p>



<p>My first thought was that this would bloat the plugin with large amounts of unnecessary CSS and JavaScript for what is essentially a few bells and whistles. However, Kamal pulled it off with minimal custom CSS.</p>



<p>Inspired by features from various website builders, he wanted to bring more and more of those things to the core block editor. The animations feature is just another ticked box on a seemingly never-ending checklist of features. And, so far, it&rsquo;s all still free.</p>



<p>Since we last <a href=\"https://wptavern.com/control-block-design-via-the-editorplus-wordpress-plugin\">covered EditorPlus in June</a>, Kamal has added the ability to insert icons via any rich-text area (e.g., paragraphs, lists, etc.). He has also added shape divider, typography, style copying, and responsive editing options for the core WordPress blocks.</p>



<h2>How Do Animations Work?</h2>



<p class=\"has-drop-cap\">In the version 1.9 release of EditorPlus, Kamal added &ldquo;entrance&rdquo; animations. These types of animations happen when a visitor sees the block for the first time on the screen. For example, users could set the Image block to fade into visibility as a reader views the block.</p>



<p>Currently, the plugin adds seven animations:</p>



<ul><li>Fade</li><li>Slide</li><li>Bounce</li><li>Zoom</li><li>Flip</li><li>Fold</li><li>Roll</li></ul>



<img />Adding a Slide animation for the Cover block text.



<p>Each animation has its own subset of options to control how it behaves on the page. The bounce animation, for example, allows users to select the bounce direction. Other options include duration, delay, speed curve, delay, and repeat. There are enough choices to spend an inordinate amount of time tinkering with the output.</p>



<p>One of the best features of this new feature is that Kamal has included an Animation Player under the block options. By clicking the play button, users can view the animation in action without previewing the post.</p>



<p>Watch a quick video of the Animations feature:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>After testing and using each animation, everything seemed to work well. The one downside &mdash; and this is not limited to animations &mdash; is that applying styles on the block level sometimes does not make sense. In many cases, it would help users to have options to style or animate the items within the block, such as the images in the Gallery block. When I broached the subject with Kamal, he was open to the idea of finding a solution to this in the future.</p>



<h2>What Is Next for EditorPlus?</h2>



<p class=\"has-drop-cap\">At a certain point, too many block options can almost feel like overkill and become unwieldy. EditorPlus does allow users to disable specific features from its settings screen, which can help get rid of some unwanted options. Kamal said he would like to continue making it more modular so that users can use only the features they need.</p>



<p>&ldquo;What I plan is to have micro-level feature control for this extension so that a user can switch off individual styling panels like, Typography, Background, etc.,&rdquo; he said. &ldquo;Even further, I plan to bring these controls based on the user role as well. So an admin can disable these features for the editor, author, etc.&rdquo;</p>



<p>That may be a bit down the road though. For now, he wants to focus on adding new features that he already has planned.</p>



<p>&ldquo;I do plan to add more animation features,&rdquo; said Kamal. &ldquo;I got too many ideas, such as scroll-controlled animation, hover animation, text animation, Lottie animation, background animation, animated shape dividers, and more. But, having said that, I will be careful adding only those features that don&rsquo;t affect page performance much.&rdquo;</p>



<p>Outside of extra styles and animations for existing blocks, he plans to jump on the block-building train in future releases. EditorPlus users could see accordion, toggle, slider, star rating, and other blocks in an upcoming release.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Oct 2020 20:53:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"Donncha: Hide featured image if it’s in the post\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"https://odd.blog/?p=89503242\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://odd.blog/2020/10/08/hide-featured-image-if-its-in-the-post/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3885:\"<p>I&#8217;ve been running a photoblog at <a href=\"https://inphotos.org/\">inphotos.org</a> since 2005 on WordPress. (And thanks to writing this I noticed it&#8217;s <a href=\"https://inphotos.org/2005/10/08/yellow-flower/\">15 years old today</a>!)</p>



<div class=\"wp-block-image\"><img /></div>



<p>In that time WordPress has changed dramatically. At first I used Flickr to host my images, but after a short time I hosted the images myself. (Good thing too since Flickr limited free user accounts to 1000 images, so I wrote <a href=\"https://github.com/donnchawp/bye-bye-flickr\">a script to download</a> the Flickr images I used in posts.)</p>



<div class=\"wp-block-image\"><img /></div>



<p>For quite a long time I used the featured image instead of inserting the image into the post content, but then about two years ago I went back to inserting the photo into the post. Unfortunately that meant the photo was shown twice, once as a featured image, and once in the post content.</p>



<p>The last theme I used supported custom post types, one of which was a photo type that displayed the featured image but hid the post content. It was an ok compromise, but not perfect.</p>



<div class=\"wp-block-image\"><img /></div>



<p>Recently I started using Twenty Twenty, but after 15 years I had a mixture of posts with:</p>



<ul><li>Featured image with no image in the post.</li><li>Featured image with the same image in the post.</li></ul>



<p>I knew I needed something more flexible. I wanted to hide the featured image if it also appeared in the post content. I procrastinated and never got around to it until this evening when I discovered it was actually quite easy. </p>



<img />



<p>Copy the following code into the function.php of your child theme and you&#8217;ll be all set! It relies on you having unique filenames for your images. If you don&#8217;t then remove the call to <code>basename()</code>, and that may help.</p>


<pre class=\"brush: php; auto-links: false; gutter: false; title: ; notranslate\">
function maybe_remove_featured_image( $html ) {
        if ( $html == \'\' ) {
                return \'\';
        }
        $post = get_post();
        $post_thumbnail_id = get_post_thumbnail_id( $post );
        if ( ! $post_thumbnail_id ) {
                return $html;
        }

        $image_url = wp_get_attachment_image_src( $post_thumbnail_id );
        if ( ! $image_url ) {
                return $html;
        }

        $image_filename = basename( parse_url( $image_url[0], PHP_URL_PATH ) );
        if ( strpos( $post-&gt;post_content, $image_filename ) ) {
                return \'\';
        } else {
                return $html;
        }
}
add_filter( \'post_thumbnail_html\', \'maybe_remove_featured_image\' );
</pre>


<p>The <code>post_thumbnail_html</code> filter acts on the html generated to display the featured image. My code above gets the filename of the featured image, checks if it&#8217;s in the current post and if it is returns a blank string. Feedback welcome if you have a better way of doing this!</p>



<div class=\"wp-block-image\"><img /></div>



<p></p>

<p><strong>Related Posts</strong><ul><li> <a href=\"https://odd.blog/2007/07/09/around-ireland-in-80-links-on-july-9th-2007/\" rel=\"bookmark\" title=\"Permanent Link: Around Ireland in 80 links on July 9th 2007\">Around Ireland in 80 links on July 9th 2007</a></li><li> <a href=\"https://odd.blog/2003/12/22/webalizer-hide-the-groups/\" rel=\"bookmark\" title=\"Permanent Link: Webalizer &#8211; hide the groups!\">Webalizer &#8211; hide the groups!</a></li><li> <a href=\"https://odd.blog/2002/11/16/dvdrip-a-full-fe/\" rel=\"bookmark\" title=\"Permanent Link: dvd::rip &#8211; A full featured DVD &#8230;\">dvd::rip &#8211; A full featured DVD &#8230;</a></li></ul></p>
<p><a href=\"https://odd.blog/2020/10/08/hide-featured-image-if-its-in-the-post/\" rel=\"nofollow\">Source</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Oct 2020 20:43:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Donncha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: Cloudflare Launches Automatic Platform Optimization for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105641\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:195:\"https://wptavern.com/cloudflare-launches-automatic-platform-optimization-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=cloudflare-launches-automatic-platform-optimization-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6128:\"<p>Just a day after launching its new <a href=\"https://wptavern.com/cloudflare-launches-new-web-analytics-product-focusing-on-privacy\">privacy-first web analytics product</a> last week, Cloudflare announced Automatic Platform Optimization (APO) for WordPress. The new service boasts staggering performance improvements for sites that might otherwise be slowed down by shared hosting, slow database lookups, or sluggish plugins:</p>



<blockquote class=\"wp-block-quote\"><p>Our testing&hellip; showed a 72% reduction in Time to First Byte (TTFB), 23% reduction to&nbsp;<a rel=\"noreferrer noopener\" href=\"https://web.dev/fcp/\" target=\"_blank\">First Contentful Paint</a>, and 13% reduction in&nbsp;<a rel=\"noreferrer noopener\" href=\"https://web.dev/speed-index/\" target=\"_blank\">Speed Index</a>&nbsp;for desktop users at the 90th percentile, by serving nearly all of your website&rsquo;s content from Cloudflare&rsquo;s network.&nbsp;</p></blockquote>



<p>APO uses Cloudflare Workers to cache dynamic content and serve the website from its <a href=\"https://www.cloudflare.com/learning/cdn/glossary/edge-server/\">edge network</a>. In most cases this eliminates origin requests and origin processing time. That means visitors requesting your website will get near instant load times. Cloudflare reports that its testing shows APO delivers consistent load times of under 400ms for HTML Time to First Byte (TTFB).</p>



<p>The effects of using APO are similar to hosting static files on a CDN, but without the need to manage a complicated tech stack. Content creators retain their ability to create dynamic websites without any changes to their workflow for the sake of performance. </p>



<p>Version 3.8 of <a href=\"https://wordpress.org/plugins/cloudflare/\">Cloudflare&rsquo;s official WordPress plugin</a> was recently updated to include support for APO. It detects when users make changes to their content and purges the content stored on Cloudflare&rsquo;s edge.</p>



<p>The new service is available to Cloudflare users with a single click of a button. APO is included at no cost for existing Cloudflare customers on the Professional, Business, and Enterprise plans. Users on the Free plan can add it to their sites for $5/month. The service is a flat fee and is not metered. </p>



<p>Cloudflare&rsquo;s announcement has so far been well-received by WordPress professionals and hosting companies and many have already begun testing it. </p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">So the week after <a href=\"https://twitter.com/Cloudflare?ref_src=twsrc%5Etfw\">@Cloudflare</a> Birthday Week I try and play with as many of the new products as possible. Today was the WordPress APO on my simple demo site. You can see TTFB dropped from ~350ms to ~75ms!  <a href=\"https://t.co/zg976EjrZI\">https://t.co/zg976EjrZI</a> <a href=\"https://t.co/KuaHqtHLom\">pic.twitter.com/KuaHqtHLom</a></p>&mdash; Matt Bullock (@mibullock) <a href=\"https://twitter.com/mibullock/status/1313478984534052865?ref_src=twsrc%5Etfw\">October 6, 2020</a></blockquote>
</div>



<p>WordPress lead developer Mark Jaquith <a href=\"https://twitter.com/markjaquith/status/1312178973372157953\">called</a> APO &ldquo;incredible news for the WordPress world.&rdquo;</p>



<p>&ldquo;On sites I manage this is going to lower hosting complexity and easily save hundreds of dollars a month in hosting costs,&rdquo; Jaquith said.</p>



<p>After running several speed tests from six different locations around the world, early testers at Kinsta got remarkable results using APO:</p>



<blockquote class=\"wp-block-quote\"><p>&ldquo;By caching&nbsp;static HTML&nbsp;on Cloudflare&rsquo;s edge network, we saw a 70-300% performance increase. As expected, the testing locations furthest away from Tokyo saw the biggest reduction in&nbsp;load time.</p><p>&ldquo;If your WordPress site uses a traditional&nbsp;CDN&nbsp;that only caches CSS, JS, and images, upgrading to Cloudflare&rsquo;s WordPress APO is a no-brainer and will help you stay competitive with modern Jamstack and static sites that live on the edge by default.&rdquo;</p></blockquote>



<p>George Liu, a &ldquo;self-confessed page speed addict&rdquo; and Cloudflare Community MVP, performed a series of <a href=\"https://community.centminmod.com/threads/cloudflare-wordpress-plugin-automatic-platform-optimization.20486/\">detailed tests</a> on the new APO product with his blog. After many comparisons, he found that Cloudoflare&rsquo;s WordPress plugin with APO turned on delivers results similar to his heavily optimized WordPress blog that uses a custom Cloudflare Worker caching configuration.</p>



<p>&ldquo;You&rsquo;ll find that Cloudflare WordPress plugin&rsquo;s one click Automatic Platform Optimization button does wonders for page speed for the average WordPress user not well versed in page speed optimizations,&rdquo; Liu said.</p>



<p>&ldquo;Cloudflare&rsquo;s WordPress plugin Automatic Platform Optimization will in theory beat all other WordPress caching solutions other than you rolling out your own Cloudflare Worker based caching like I did. So you get a good bang for your buck at US$5/month for Cloudflare&rsquo;s WordPress plugin APO.&rdquo;</p>



<p>Liu also warned of some speed bumps with the initial rollout, as Cloudflare&rsquo;s APO supports a limited set of WordPress cookies for bypassing the Cloudflare CDN cache, leaving certain use cases unsupported. APO does not seem to work on subdomains and users are also reporting that it&rsquo;s not compatible with other caching plugins. It also disables real visitor IP address detection. </p>



<p>Cloudflare is aware of many of these issues, which have been raised in the comments of the <a href=\"https://blog.cloudflare.com/automatic-platform-optimizations-starting-with-wordpress/\">announcement</a>, and is in the process of adding more cookies to the list to bypass caching. Due to some plugin conflicts, APO may not be as plug-and-play as it sounds for some users right now, but the product is very promising and should improve over time with more feedback.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Oct 2020 04:18:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: Kick off Block-Based WordPress Theme Development With the Theme.json Creator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105832\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/kick-off-block-based-wordpress-theme-development-with-the-theme-json-creator?utm_source=rss&utm_medium=rss&utm_campaign=kick-off-block-based-wordpress-theme-development-with-the-theme-json-creator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4674:\"<p class=\"has-drop-cap\">Gutenberg 9.1 made a backward-incompatible change to its <code>theme.json</code> file (<code>experimental-theme.json</code> while full-site editing is under the experimental flag). This is the configuration file that theme developers will need to create as part of their block-based themes. Staying up to date with such changes can be a challenge for theme authors, but Ari Stathopoulos, a Themes Team representative, wrote a <a href=\"https://make.wordpress.org/themes/2020/10/01/gutenberg-9-1-new-json-structure-for-fse-theme-json-files/\">full guide for developers</a>.</p>



<p>Jon Quach, a Principal Designer at Automattic, has also been busy creating a tool to help theme authors transition to block-based themes. He recently built a UI-based project called <a href=\"https://gutenberg-theme.xyz/\">Theme.json Creator</a> that builds out the JSON code for theme authors. Plus, it is up to date with the most recent changes in the Gutenberg plugin.</p>



<p>Tools like these will be what the development community needs as it gets over the inevitable hump of moving away from the traditional theme development paradigm and into a new era where themes are made almost entirely of blocks and a config file.</p>



<p>While plugin development is becoming more complex with the addition of JavaScript, theme development is taking a sharp turn toward its roots of HTML and CSS. We are barreling toward a future in which far more people will be able to create WordPress themes. Even the possibility of sharing pieces of themes (e.g., template parts and patterns) is on the table. This could not only empower theme designers by lowering the barrier to entry, it could also empower some end-users to make the jump into theme building.</p>



<p>However, the <code>theme.json</code> file is one aspect of future theme authorship that is extremely developer-oriented. JSON is a universal format shared between various programming languages. It is meant to be read by machines and is not quite as human-friendly as other formats. As the <code>theme.json</code> file grows to accommodate more configuration options over time, the less friendly it will become to simply typing keys and values in.</p>



<p>It makes sense to build tools to simplify this part of the theme building process.</p>



<p>That is where the Theme.json Creator tool comes in. Theme authors pick and choose the options they want to support and input custom values. Then, the tool spits out everything in properly-formatted JSON.</p>



<img />Using the Theme.json Creator tool.



<p>One big thing the tool does not yet cover is custom CSS variables. This feature is a recent addition to the <code>theme.json</code> specification. It allows theme authors to create any custom property that WordPress will automatically output as CSS. In his announcement post, Stathopoulos covered how to create a typographic scale with custom properties and use those variables for editor features, such as line-height and font-size values.</p>



<p>Currently, Theme.json Creator&rsquo;s primary focus is on global styles. However, Gutenberg allows theme authors to configure default styles on the block level. For example, theme designers can set the color or typography options for the core Heading block to be different from the default global styles. This provides theme authors with fine-tuned control over every block.</p>



<p>Theme.json Creator does not yet support configuration at this level. However, it would be interesting to see if Quach adds it in the future.</p>



<p>The focus on setting up global styles is a good start for now. This is still an experimental feature. The great thing about it is that it can help theme authors begin to see how one piece of the block-based themes puzzle fits in. It is a starting point for an entirely new method of adding theme support for features when most are accustomed to adding multiple <code>add_theme_support()</code> PHP function calls.</p>



<p>With the direction that theme development seems to be heading, it is easy to imagine that it could evolve into a completely UI-based affair at some point down the line. If templates are made up of blocks and patterns, which anyone can already build with the block editor, and if styles will essentially boil down to a config file, there will be little-to-no programming required to build a basic WordPress theme.</p>



<p>If someone is not already at least jotting down notes for a plugin that allows users to create and package a block-based theme, I would be surprised. For now, Theme.json Creator is removing the need to write code for at least one part of the theme design process.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 07 Oct 2020 20:53:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Wed, 04 Nov 2020 19:09:44 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Wed, 04 Nov 2020 18:45:08 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20200501142607\";}","no");
INSERT INTO `wp_options` VALUES("141","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1604560185","no");
INSERT INTO `wp_options` VALUES("142","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1604516985","no");
INSERT INTO `wp_options` VALUES("143","_transient_timeout_dash_v2_f69de0bbfe7eaa113146875f40c02000","1604560185","no");
INSERT INTO `wp_options` VALUES("144","_transient_dash_v2_f69de0bbfe7eaa113146875f40c02000","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ru.wordpress.org/news/2020/10/2020-annual-survey/\'>Ежегодный опрос пользователей и разработчиков WordPress 2020</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/wordpress-5-6-to-add-ui-for-enabling-major-version-auto-updates-contributors-discuss-adding-a-filter-to-hide-it?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wordpress-5-6-to-add-ui-for-enabling-major-version-auto-updates-contributors-discuss-adding-a-filter-to-hide-it\'>WPTavern: WordPress 5.6 to Add UI for Enabling Major Version Auto-Updates, Contributors Discuss Adding a Filter to Hide It</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/automattic-releases-spearhead-a-seedlet-child-theme-aimed-at-podcasters-and-content-creators?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=automattic-releases-spearhead-a-seedlet-child-theme-aimed-at-podcasters-and-content-creators\'>WPTavern: Automattic Releases Spearhead, a Seedlet Child Theme Aimed at Podcasters and Content Creators</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/wordpress-2019-survey-results-show-professionals-slow-to-adopt-block-editor-2020-survey-now-open?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wordpress-2019-survey-results-show-professionals-slow-to-adopt-block-editor-2020-survey-now-open\'>WPTavern: WordPress 2019 Survey Results Show Professionals Slow to Adopt Block Editor, 2020 Survey Now Open</a></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("147","finished_updating_comment_type","1","yes");
INSERT INTO `wp_options` VALUES("148","recently_activated","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("149","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1604528426","no");
INSERT INTO `wp_options` VALUES("150","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4726;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:4463;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2690;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2565;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1979;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1832;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1812;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1493;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1491;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1491;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1462;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1459;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1448;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1306;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1226;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1209;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1170;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1136;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1109;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:1021;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:907;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:905;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:883;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:882;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:830;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:805;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:797;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:783;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:782;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:756;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:755;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:726;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:721;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:707;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:703;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:690;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:666;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:663;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:658;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:652;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:638;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:636;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:618;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:617;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:593;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:587;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:583;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:580;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:578;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:562;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:560;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:557;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:554;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:552;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:542;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:542;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:534;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:533;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:524;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:522;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:522;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:507;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:496;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:495;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:486;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:483;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:479;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:465;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:459;}s:5:\"block\";a:3:{s:4:\"name\";s:5:\"block\";s:4:\"slug\";s:5:\"block\";s:5:\"count\";i:444;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:443;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:441;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:440;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:439;}s:9:\"elementor\";a:3:{s:4:\"name\";s:9:\"elementor\";s:4:\"slug\";s:9:\"elementor\";s:5:\"count\";i:437;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:433;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:429;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:427;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:424;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:423;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:422;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:413;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:405;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:400;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:397;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:394;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:389;}s:8:\"shipping\";a:3:{s:4:\"name\";s:8:\"shipping\";s:4:\"slug\";s:8:\"shipping\";s:5:\"count\";i:387;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:385;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:381;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:380;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:379;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:373;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:365;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:361;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:359;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:350;}s:6:\"import\";a:3:{s:4:\"name\";s:6:\"import\";s:4:\"slug\";s:6:\"import\";s:5:\"count\";i:346;}s:5:\"cache\";a:3:{s:4:\"name\";s:5:\"cache\";s:4:\"slug\";s:5:\"cache\";s:5:\"count\";i:346;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:343;}}","no");
INSERT INTO `wp_options` VALUES("155","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("156","aio_wp_security_configs","a:95:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"9boae3otjbi5x7b7q6kf\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_custom_login_captcha\";s:1:\"1\";s:25:\"aiowps_captcha_secret_key\";s:20:\"aew2zhy60o1lbci0frvd\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:1:\"1\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:1;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:1:\"1\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:1:\"1\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:1:\"1\";s:28:\"aiowps_enable_404_IP_lockout\";s:1:\"1\";s:30:\"aiowps_404_lockout_time_length\";i:60;s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:61:\"This site is currently not available. Please try again later.\";s:30:\"aiowps_enable_spambot_blocking\";s:1:\"1\";s:29:\"aiowps_enable_comment_captcha\";s:1:\"1\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:1:\"1\";s:33:\"aiowps_spam_ip_min_comments_block\";i:3;s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2019-08-29 22:38:57\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_woo_register_captcha\";s:1:\"1\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:35:\"aiowps_enable_lost_password_captcha\";s:1:\"1\";s:28:\"aiowps_block_fake_googlebots\";s:1:\"1\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";s:27:\"aiowps_max_file_upload_size\";s:2:\"10\";}","yes");
INSERT INTO `wp_options` VALUES("157","_transient_timeout_users_online","1604523790","no");
INSERT INTO `wp_options` VALUES("158","_transient_users_online","a:1:{i:0;a:4:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1604532790;s:10:\"ip_address\";s:9:\"127.0.0.1\";s:7:\"blog_id\";b:0;}}","no");
INSERT INTO `wp_options` VALUES("163","_site_transient_timeout_theme_roots","1604521700","no");
INSERT INTO `wp_options` VALUES("164","_site_transient_theme_roots","a:4:{s:5:\"mozar\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("170","imsanity_max_width","1920","no");
INSERT INTO `wp_options` VALUES("171","imsanity_max_height","1920","no");
INSERT INTO `wp_options` VALUES("172","imsanity_max_width_library","1920","no");
INSERT INTO `wp_options` VALUES("173","imsanity_max_height_library","1920","no");
INSERT INTO `wp_options` VALUES("174","imsanity_max_width_other","1920","no");
INSERT INTO `wp_options` VALUES("175","imsanity_max_height_other","1920","no");
INSERT INTO `wp_options` VALUES("176","imsanity_png_to_jpg","0","no");
INSERT INTO `wp_options` VALUES("177","imsanity_bmp_to_jpg","1","no");
INSERT INTO `wp_options` VALUES("178","imsanity_quality","82","no");
INSERT INTO `wp_options` VALUES("179","imsanity_deep_scan","","no");
INSERT INTO `wp_options` VALUES("180","imsanity_version","2.6.0","yes");
INSERT INTO `wp_options` VALUES("186","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.5.3.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.5.3.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.5.3\";s:7:\"version\";s:5:\"5.5.3\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1604518982;s:15:\"version_checked\";s:5:\"5.5.3\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("187","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1604518983;s:7:\"checked\";a:8:{s:19:\"akismet/akismet.php\";s:5:\"4.1.7\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.4.4\";s:22:\"cyr3lat/cyr-to-lat.php\";s:3:\"3.5\";s:9:\"hello.php\";s:5:\"1.7.2\";s:21:\"imsanity/imsanity.php\";s:5:\"2.6.0\";s:31:\"query-monitor/query-monitor.php\";s:5:\"3.6.4\";s:27:\"woocommerce/woocommerce.php\";s:5:\"4.6.1\";s:24:\"wordpress-seo/wp-seo.php\";s:6:\"15.2.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:8:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.7\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.4\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:22:\"cyr3lat/cyr-to-lat.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/cyr3lat\";s:4:\"slug\";s:7:\"cyr3lat\";s:6:\"plugin\";s:22:\"cyr3lat/cyr-to-lat.php\";s:11:\"new_version\";s:3:\"3.5\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/cyr3lat/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/cyr3lat.3.5.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:51:\"https://s.w.org/plugins/geopattern-icon/cyr3lat.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:21:\"imsanity/imsanity.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/imsanity\";s:4:\"slug\";s:8:\"imsanity\";s:6:\"plugin\";s:21:\"imsanity/imsanity.php\";s:11:\"new_version\";s:5:\"2.6.0\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/imsanity/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/imsanity.2.6.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/imsanity/assets/icon-256x256.png?rev=1094749\";s:2:\"1x\";s:61:\"https://ps.w.org/imsanity/assets/icon-128x128.png?rev=1170755\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/imsanity/assets/banner-772x250.png?rev=900541\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"query-monitor/query-monitor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/query-monitor\";s:4:\"slug\";s:13:\"query-monitor\";s:6:\"plugin\";s:31:\"query-monitor/query-monitor.php\";s:11:\"new_version\";s:5:\"3.6.4\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/query-monitor/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/query-monitor.3.6.4.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/query-monitor/assets/icon-256x256.png?rev=2301273\";s:2:\"1x\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";s:3:\"svg\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/query-monitor/assets/banner-1544x500.png?rev=1629576\";s:2:\"1x\";s:68:\"https://ps.w.org/query-monitor/assets/banner-772x250.png?rev=2301273\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"4.6.1\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.4.6.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2366418\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2366418\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2366418\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2366418\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:6:\"15.2.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wordpress-seo.15.2.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=2363699\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}","no");
INSERT INTO `wp_options` VALUES("188","_site_transient_update_themes","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1604519901;s:7:\"checked\";a:4:{s:5:\"mozar\";s:0:\"\";s:14:\"twentynineteen\";s:3:\"1.7\";s:15:\"twentyseventeen\";s:3:\"2.4\";s:12:\"twentytwenty\";s:3:\"1.5\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:3:{s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.1.7.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentyseventeen\";a:6:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"2.4\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.2.4.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.5\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.5.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("189","action_scheduler_hybrid_store_demarkation","5","yes");
INSERT INTO `wp_options` VALUES("190","schema-ActionScheduler_StoreSchema","3.0.1604518985","yes");
INSERT INTO `wp_options` VALUES("191","schema-ActionScheduler_LoggerSchema","2.0.1604518986","yes");
INSERT INTO `wp_options` VALUES("194","woocommerce_schema_version","430","yes");
INSERT INTO `wp_options` VALUES("195","woocommerce_store_address","","yes");
INSERT INTO `wp_options` VALUES("196","woocommerce_store_address_2","","yes");
INSERT INTO `wp_options` VALUES("197","woocommerce_store_city","","yes");
INSERT INTO `wp_options` VALUES("198","woocommerce_default_country","GB","yes");
INSERT INTO `wp_options` VALUES("199","woocommerce_store_postcode","","yes");
INSERT INTO `wp_options` VALUES("200","woocommerce_allowed_countries","all","yes");
INSERT INTO `wp_options` VALUES("201","woocommerce_all_except_countries","","yes");
INSERT INTO `wp_options` VALUES("202","woocommerce_specific_allowed_countries","","yes");
INSERT INTO `wp_options` VALUES("203","woocommerce_ship_to_countries","","yes");
INSERT INTO `wp_options` VALUES("204","woocommerce_specific_ship_to_countries","","yes");
INSERT INTO `wp_options` VALUES("205","woocommerce_default_customer_address","base","yes");
INSERT INTO `wp_options` VALUES("206","woocommerce_calc_taxes","no","yes");
INSERT INTO `wp_options` VALUES("207","woocommerce_enable_coupons","yes","yes");
INSERT INTO `wp_options` VALUES("208","woocommerce_calc_discounts_sequentially","no","no");
INSERT INTO `wp_options` VALUES("209","woocommerce_currency","GBP","yes");
INSERT INTO `wp_options` VALUES("210","woocommerce_currency_pos","left","yes");
INSERT INTO `wp_options` VALUES("211","woocommerce_price_thousand_sep",",","yes");
INSERT INTO `wp_options` VALUES("212","woocommerce_price_decimal_sep",".","yes");
INSERT INTO `wp_options` VALUES("213","woocommerce_price_num_decimals","2","yes");
INSERT INTO `wp_options` VALUES("214","woocommerce_shop_page_id","6","yes");
INSERT INTO `wp_options` VALUES("215","woocommerce_cart_redirect_after_add","no","yes");
INSERT INTO `wp_options` VALUES("216","woocommerce_enable_ajax_add_to_cart","yes","yes");
INSERT INTO `wp_options` VALUES("217","woocommerce_placeholder_image","5","yes");
INSERT INTO `wp_options` VALUES("218","woocommerce_weight_unit","kg","yes");
INSERT INTO `wp_options` VALUES("219","woocommerce_dimension_unit","cm","yes");
INSERT INTO `wp_options` VALUES("220","woocommerce_enable_reviews","yes","yes");
INSERT INTO `wp_options` VALUES("221","woocommerce_review_rating_verification_label","yes","no");
INSERT INTO `wp_options` VALUES("222","woocommerce_review_rating_verification_required","no","no");
INSERT INTO `wp_options` VALUES("223","woocommerce_enable_review_rating","yes","yes");
INSERT INTO `wp_options` VALUES("224","woocommerce_review_rating_required","yes","no");
INSERT INTO `wp_options` VALUES("225","woocommerce_manage_stock","yes","yes");
INSERT INTO `wp_options` VALUES("226","woocommerce_hold_stock_minutes","60","no");
INSERT INTO `wp_options` VALUES("227","woocommerce_notify_low_stock","yes","no");
INSERT INTO `wp_options` VALUES("228","woocommerce_notify_no_stock","yes","no");
INSERT INTO `wp_options` VALUES("229","woocommerce_stock_email_recipient","dimisiusis@gmail.com","no");
INSERT INTO `wp_options` VALUES("230","woocommerce_notify_low_stock_amount","2","no");
INSERT INTO `wp_options` VALUES("231","woocommerce_notify_no_stock_amount","0","yes");
INSERT INTO `wp_options` VALUES("232","woocommerce_hide_out_of_stock_items","no","yes");
INSERT INTO `wp_options` VALUES("233","woocommerce_stock_format","","yes");
INSERT INTO `wp_options` VALUES("234","woocommerce_file_download_method","force","no");
INSERT INTO `wp_options` VALUES("235","woocommerce_downloads_require_login","no","no");
INSERT INTO `wp_options` VALUES("236","woocommerce_downloads_grant_access_after_payment","yes","no");
INSERT INTO `wp_options` VALUES("237","woocommerce_downloads_add_hash_to_filename","yes","yes");
INSERT INTO `wp_options` VALUES("238","woocommerce_prices_include_tax","no","yes");
INSERT INTO `wp_options` VALUES("239","woocommerce_tax_based_on","shipping","yes");
INSERT INTO `wp_options` VALUES("240","woocommerce_shipping_tax_class","inherit","yes");
INSERT INTO `wp_options` VALUES("241","woocommerce_tax_round_at_subtotal","no","yes");
INSERT INTO `wp_options` VALUES("242","woocommerce_tax_classes","","yes");
INSERT INTO `wp_options` VALUES("243","woocommerce_tax_display_shop","excl","yes");
INSERT INTO `wp_options` VALUES("244","woocommerce_tax_display_cart","excl","yes");
INSERT INTO `wp_options` VALUES("245","woocommerce_price_display_suffix","","yes");
INSERT INTO `wp_options` VALUES("246","woocommerce_tax_total_display","itemized","no");
INSERT INTO `wp_options` VALUES("247","woocommerce_enable_shipping_calc","yes","no");
INSERT INTO `wp_options` VALUES("248","woocommerce_shipping_cost_requires_address","no","yes");
INSERT INTO `wp_options` VALUES("249","woocommerce_ship_to_destination","billing","no");
INSERT INTO `wp_options` VALUES("250","woocommerce_shipping_debug_mode","no","yes");
INSERT INTO `wp_options` VALUES("251","woocommerce_enable_guest_checkout","yes","no");
INSERT INTO `wp_options` VALUES("252","woocommerce_enable_checkout_login_reminder","no","no");
INSERT INTO `wp_options` VALUES("253","woocommerce_enable_signup_and_login_from_checkout","no","no");
INSERT INTO `wp_options` VALUES("254","woocommerce_enable_myaccount_registration","no","no");
INSERT INTO `wp_options` VALUES("255","woocommerce_registration_generate_username","yes","no");
INSERT INTO `wp_options` VALUES("256","woocommerce_registration_generate_password","yes","no");
INSERT INTO `wp_options` VALUES("257","woocommerce_erasure_request_removes_order_data","no","no");
INSERT INTO `wp_options` VALUES("258","woocommerce_erasure_request_removes_download_data","no","no");
INSERT INTO `wp_options` VALUES("259","woocommerce_allow_bulk_remove_personal_data","no","no");
INSERT INTO `wp_options` VALUES("260","woocommerce_registration_privacy_policy_text","Ваши личные данные будут использоваться для упрощения вашей работы с сайтом, управления доступом к вашей учётной записи и для других целей, описанных в нашей [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("261","woocommerce_checkout_privacy_policy_text","Ваши личные данные будут использоваться для обработки ваших заказов, упрощения вашей работы с сайтом и для других целей, описанных в нашей [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("262","woocommerce_delete_inactive_accounts","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("263","woocommerce_trash_pending_orders","","no");
INSERT INTO `wp_options` VALUES("264","woocommerce_trash_failed_orders","","no");
INSERT INTO `wp_options` VALUES("265","woocommerce_trash_cancelled_orders","","no");
INSERT INTO `wp_options` VALUES("266","woocommerce_anonymize_completed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("267","woocommerce_email_from_name","mozar","no");
INSERT INTO `wp_options` VALUES("268","woocommerce_email_from_address","dimisiusis@gmail.com","no");
INSERT INTO `wp_options` VALUES("269","woocommerce_email_header_image","","no");
INSERT INTO `wp_options` VALUES("270","woocommerce_email_footer_text","{site_title} &mdash; Built with {WooCommerce}","no");
INSERT INTO `wp_options` VALUES("271","woocommerce_email_base_color","#96588a","no");
INSERT INTO `wp_options` VALUES("272","woocommerce_email_background_color","#f7f7f7","no");
INSERT INTO `wp_options` VALUES("273","woocommerce_email_body_background_color","#ffffff","no");
INSERT INTO `wp_options` VALUES("274","woocommerce_email_text_color","#3c3c3c","no");
INSERT INTO `wp_options` VALUES("275","woocommerce_cart_page_id","7","no");
INSERT INTO `wp_options` VALUES("276","woocommerce_checkout_page_id","8","no");
INSERT INTO `wp_options` VALUES("277","woocommerce_myaccount_page_id","9","no");
INSERT INTO `wp_options` VALUES("278","woocommerce_terms_page_id","","no");
INSERT INTO `wp_options` VALUES("279","woocommerce_force_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("280","woocommerce_unforce_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("281","woocommerce_checkout_pay_endpoint","order-pay","yes");
INSERT INTO `wp_options` VALUES("282","woocommerce_checkout_order_received_endpoint","order-received","yes");
INSERT INTO `wp_options` VALUES("283","woocommerce_myaccount_add_payment_method_endpoint","add-payment-method","yes");
INSERT INTO `wp_options` VALUES("284","woocommerce_myaccount_delete_payment_method_endpoint","delete-payment-method","yes");
INSERT INTO `wp_options` VALUES("285","woocommerce_myaccount_set_default_payment_method_endpoint","set-default-payment-method","yes");
INSERT INTO `wp_options` VALUES("286","woocommerce_myaccount_orders_endpoint","orders","yes");
INSERT INTO `wp_options` VALUES("287","woocommerce_myaccount_view_order_endpoint","view-order","yes");
INSERT INTO `wp_options` VALUES("288","woocommerce_myaccount_downloads_endpoint","downloads","yes");
INSERT INTO `wp_options` VALUES("289","woocommerce_myaccount_edit_account_endpoint","edit-account","yes");
INSERT INTO `wp_options` VALUES("290","woocommerce_myaccount_edit_address_endpoint","edit-address","yes");
INSERT INTO `wp_options` VALUES("291","woocommerce_myaccount_payment_methods_endpoint","payment-methods","yes");
INSERT INTO `wp_options` VALUES("292","woocommerce_myaccount_lost_password_endpoint","lost-password","yes");
INSERT INTO `wp_options` VALUES("293","woocommerce_logout_endpoint","customer-logout","yes");
INSERT INTO `wp_options` VALUES("294","woocommerce_api_enabled","no","yes");
INSERT INTO `wp_options` VALUES("295","woocommerce_allow_tracking","no","no");
INSERT INTO `wp_options` VALUES("296","woocommerce_show_marketplace_suggestions","yes","no");
INSERT INTO `wp_options` VALUES("297","woocommerce_single_image_width","600","yes");
INSERT INTO `wp_options` VALUES("298","woocommerce_thumbnail_image_width","300","yes");
INSERT INTO `wp_options` VALUES("299","woocommerce_checkout_highlight_required_fields","yes","yes");
INSERT INTO `wp_options` VALUES("300","woocommerce_demo_store","no","no");
INSERT INTO `wp_options` VALUES("301","woocommerce_permalinks","a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("302","current_theme_supports_woocommerce","yes","yes");
INSERT INTO `wp_options` VALUES("303","woocommerce_queue_flush_rewrite_rules","no","yes");
INSERT INTO `wp_options` VALUES("304","_transient_wc_attribute_taxonomies","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("305","product_cat_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("306","default_product_cat","15","yes");
INSERT INTO `wp_options` VALUES("309","woocommerce_version","4.6.1","yes");
INSERT INTO `wp_options` VALUES("310","woocommerce_db_version","4.6.1","yes");
INSERT INTO `wp_options` VALUES("311","_transient_timeout__woocommerce_upload_directory_status","1604605418","no");
INSERT INTO `wp_options` VALUES("312","_transient__woocommerce_upload_directory_status","protected","no");
INSERT INTO `wp_options` VALUES("313","action_scheduler_lock_async-request-runner","1604521374","yes");
INSERT INTO `wp_options` VALUES("314","woocommerce_admin_notices","a:1:{i:0;s:20:\"no_secure_connection\";}","yes");
INSERT INTO `wp_options` VALUES("315","woocommerce_maxmind_geolocation_settings","a:1:{s:15:\"database_prefix\";s:32:\"nBQ9DtGyWFZlGV2fysjn7QgQ1XJDAq1B\";}","yes");
INSERT INTO `wp_options` VALUES("316","_transient_woocommerce_webhook_ids_status_active","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("317","widget_woocommerce_widget_cart","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("318","widget_woocommerce_layered_nav_filters","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("319","widget_woocommerce_layered_nav","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("320","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("321","widget_woocommerce_product_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("322","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("323","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("324","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("325","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("326","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("327","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("328","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("331","woocommerce_admin_version","1.6.2","yes");
INSERT INTO `wp_options` VALUES("332","woocommerce_admin_install_timestamp","1604519024","yes");
INSERT INTO `wp_options` VALUES("334","_transient_timeout_as-post-store-dependencies-met","1604605425","no");
INSERT INTO `wp_options` VALUES("335","_transient_as-post-store-dependencies-met","yes","no");
INSERT INTO `wp_options` VALUES("337","wc_admin_note_home_screen_feedback_homescreen_accessed","1604519025","yes");
INSERT INTO `wp_options` VALUES("339","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("340","wc_blocks_db_schema_version","260","yes");
INSERT INTO `wp_options` VALUES("342","wc_remote_inbox_notifications_stored_state","O:8:\"stdClass\":2:{s:22:\"there_were_no_products\";b:1;s:22:\"there_are_now_products\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("343","woocommerce_meta_box_errors","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("346","wc_remote_inbox_notifications_specs","a:3:{s:37:\"ecomm-need-help-setting-up-your-store\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"ecomm-need-help-setting-up-your-store\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:32:\"Need help setting up your Store?\";s:7:\"content\";s:350:\"Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:16:\"set-up-concierge\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:21:\"Schedule free session\";}}s:3:\"url\";s:34:\"https://wordpress.com/me/concierge\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}}}s:20:\"woocommerce-services\";O:8:\"stdClass\":8:{s:4:\"slug\";s:20:\"woocommerce-services\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"WooCommerce Shipping & Tax\";s:7:\"content\";s:255:\"WooCommerce Shipping & Tax helps get your store “ready to sell” as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:84:\"https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-services\";}}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}s:32:\"ecomm-unique-shopping-experience\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"ecomm-unique-shopping-experience\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:53:\"For a shopping experience as unique as your customers\";s:7:\"content\";s:274:\"Product Add-Ons allow your customers to personalize products while they’re shopping on your online store. No more follow-up email requests—customers get what they want, before they’re done checking out. Learn more about this extension that comes included in your plan.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:43:\"learn-more-ecomm-unique-shopping-experience\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:71:\"https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}}","yes");
INSERT INTO `wp_options` VALUES("347","_transient_timeout_wc_onboarding_product_data","1604605429","no");
INSERT INTO `wp_options` VALUES("348","_transient_wc_onboarding_product_data","a:6:{s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:17:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Wed, 04 Nov 2020 19:43:49 GMT\";s:12:\"content-type\";s:31:\"application/json; charset=UTF-8\";s:14:\"content-length\";s:5:\"11432\";s:12:\"x-robots-tag\";s:7:\"noindex\";s:4:\"link\";s:60:\"<https://woocommerce.com/wp-json/>; rel=\"https://api.w.org/\"\";s:22:\"x-content-type-options\";s:7:\"nosniff\";s:29:\"access-control-expose-headers\";s:33:\"X-WP-Total, X-WP-TotalPages, Link\";s:28:\"access-control-allow-headers\";s:73:\"Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type\";s:13:\"cache-control\";s:10:\"max-age=60\";s:5:\"allow\";s:3:\"GET\";s:16:\"content-encoding\";s:4:\"gzip\";s:4:\"x-rq\";s:16:\"arn1 87 207 3156\";s:3:\"age\";s:2:\"59\";s:7:\"x-cache\";s:3:\"hit\";s:4:\"vary\";s:23:\"Accept-Encoding, Origin\";s:13:\"accept-ranges\";s:5:\"bytes\";}}s:4:\"body\";s:48161:\"{\"products\":[{\"title\":\"WooCommerce Google Analytics\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/GA-Dark.png\",\"excerpt\":\"Understand your customers and increase revenue with world\\u2019s leading analytics platform - integrated with WooCommerce for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2d21f7de14dfb8e9885a4622be701ddf\",\"slug\":\"woocommerce-google-analytics-integration\",\"id\":1442927},{\"title\":\"WooCommerce Tax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Tax-Dark.png\",\"excerpt\":\"Get live rates, discounted labels, tracking numbers, and more \\u2013 without leaving your dashboard.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/tax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":3220291},{\"title\":\"Stripe\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Stripe-Dark-1.png\",\"excerpt\":\"Accept all major debit and credit cards as well as local payment methods with Stripe.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/stripe\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"50bb7a985c691bb943a9da4d2c8b5efd\",\"slug\":\"woocommerce-gateway-stripe\",\"id\":18627},{\"title\":\"Jetpack\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Jetpack-Dark.png\",\"excerpt\":\"Power up and protect your store with Jetpack\\r\\n\\r\\nFor free security, insights and monitoring, connect to Jetpack. It\'s everything you need for a strong, secure start.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jetpack\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"d5bfef9700b62b2b132c74c74c3193eb\",\"slug\":\"jetpack\",\"id\":2725249},{\"title\":\"Facebook for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Facebook-Dark.png\",\"excerpt\":\"Get the Official Facebook for WooCommerce plugin for three powerful ways to help grow your business.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/facebook\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"0ea4fe4c2d7ca6338f8a322fb3e4e187\",\"slug\":\"facebook-for-woocommerce\",\"id\":2127297},{\"title\":\"Amazon Pay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Amazon-Pay-Dark.png\",\"excerpt\":\"Amazon Pay is embedded in your WooCommerce store. Transactions take place via\\u00a0Amazon widgets, so the buyer never leaves your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/pay-with-amazon\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9865e043bbbe4f8c9735af31cb509b53\",\"slug\":\"woocommerce-gateway-amazon-payments-advanced\",\"id\":238816},{\"title\":\"Square for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Square-Dark.png\",\"excerpt\":\"Accepting payments is easy with Square. Clear rates, fast deposits (1-2 business days). Sell online and in person, and sync all payments, items and inventory.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/square\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e907be8b86d7df0c8f8e0d0020b52638\",\"slug\":\"woocommerce-square\",\"id\":1770503},{\"title\":\"WooCommerce Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Dark-1.png\",\"excerpt\":\"Save time and money with WooCommerce Shipping. Print labels right from your WooCommerce dashboard at the lowest USPS rates.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":2165910},{\"title\":\"WooCommerce Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Pay-Dark.png\",\"excerpt\":\"The only payment method designed exclusively for WooCommerce, by WooCommerce. Securely accept major credit and debit cards on your site. View and manage your transactions within your WordPress dashboard.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"8c6319ca-8f41-4e69-be63-6b15ee37773b\",\"slug\":\"woocommerce-payments\",\"id\":5278104},{\"title\":\"ShipStation Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Shipstation-Dark.png\",\"excerpt\":\"Fulfill all your Woo orders (and wherever else you sell) quickly and easily using ShipStation. Try it free for 30 days today!\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipstation-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9de8640767ba64237808ed7f245a49bb\",\"slug\":\"woocommerce-shipstation-integration\",\"id\":18734},{\"title\":\"WooCommerce Subscriptions\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Subscriptions-Dark.png\",\"excerpt\":\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscriptions\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"6115e6d7e297b623a169fdcf5728b224\",\"slug\":\"woocommerce-subscriptions\",\"id\":27147},{\"title\":\"Mailchimp for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/09\\/logo-mailchimp-dark-v2.png\",\"excerpt\":\"Increase traffic, drive repeat purchases, and personalize your marketing when you connect to Mailchimp.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/mailchimp-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b4481616ebece8b1ff68fc59b90c1a91\",\"slug\":\"mailchimp-for-woocommerce\",\"id\":2545166},{\"title\":\"PayPal Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Dark.png\",\"excerpt\":\"PayPal Checkout now with Smart Payment Buttons\\u2122, dynamically displays, PayPal, Venmo, PayPal Credit, or other local payment options in a single stack giving customers the choice to pay with their preferred option.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"69e6cba62ac4021df9e117cc3f716d07\",\"slug\":\"woocommerce-gateway-paypal-express-checkout\",\"id\":1597922},{\"title\":\"PayFast Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Payfast-Dark-1.png\",\"excerpt\":\"Take payments on your WooCommerce store via PayFast (redirect method).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/payfast-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"557bf07293ad916f20c207c6c9cd15ff\",\"slug\":\"woocommerce-payfast-gateway\",\"id\":18596},{\"title\":\"Product Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-Add-Ons-Dark.png\",\"excerpt\":\"Offer add-ons like gift wrapping, special messages or other special options for your products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"147d0077e591e16db9d0d67daeb8c484\",\"slug\":\"woocommerce-product-addons\",\"id\":18618},{\"title\":\"Google Ads &#038; Marketing by Kliken\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/02\\/GA-for-Woo-Logo-374x192px-qu3duk.png\",\"excerpt\":\"Get in front of shoppers and drive traffic to your store so you can grow your business with Smart Shopping Campaigns and free listings.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-ads-and-marketing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"bf66e173-a220-4da7-9512-b5728c20fc16\",\"slug\":\"kliken-marketing-for-google\",\"id\":3866145},{\"title\":\"Braintree for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/02\\/braintree-black-copy.png\",\"excerpt\":\"Accept PayPal, credit cards and debit cards with a single payment gateway solution \\u2014 PayPal Powered by Braintree.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-powered-by-braintree\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"27f010c8e34ca65b205ddec88ad14536\",\"slug\":\"woocommerce-gateway-paypal-powered-by-braintree\",\"id\":1489837},{\"title\":\"WooCommerce Memberships\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/06\\/Thumbnail-Memberships-2.png\",\"excerpt\":\"Give members access to restricted content or products, for a fee or for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-memberships\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"9288e7609ad0b487b81ef6232efa5cfc\",\"slug\":\"woocommerce-memberships\",\"id\":958589},{\"title\":\"USPS Shipping Method\",\"image\":\"\",\"excerpt\":\"Get shipping rates from the USPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/usps-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"83d1524e8f5f1913e58889f83d442c32\",\"slug\":\"woocommerce-shipping-usps\",\"id\":18657},{\"title\":\"Product Bundles\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-PB.png?v=1\",\"excerpt\":\"Offer personalized product bundles, bulk discount packages and assembled\\u00a0products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-bundles\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa2518b5-ab19-4b75-bde9-60ca51e20f28\",\"slug\":\"woocommerce-product-bundles\",\"id\":18716},{\"title\":\"UPS Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/UPS-Shipping-Method-Dark.png\",\"excerpt\":\"Get shipping rates from the UPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ups-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8dae58502913bac0fbcdcaba515ea998\",\"slug\":\"woocommerce-shipping-ups\",\"id\":18665},{\"title\":\"Table Rate Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Product-Table-Rate-Shipping-Dark.png\",\"excerpt\":\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/table-rate-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"3034ed8aff427b0f635fe4c86bbf008a\",\"slug\":\"woocommerce-table-rate-shipping\",\"id\":18718},{\"title\":\"Checkout Field Editor\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Checkout-Field-Editor-Dark.png\",\"excerpt\":\"Optimize your checkout process by adding, removing or editing fields to suit your needs.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-field-editor\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"2b8029f0d7cdd1118f4d843eb3ab43ff\",\"slug\":\"woocommerce-checkout-field-editor\",\"id\":184594},{\"title\":\"Shipment Tracking\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Tracking-Dark-1.png\",\"excerpt\":\"Add shipment tracking information to your orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipment-tracking\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"1968e199038a8a001c9f9966fd06bf88\",\"slug\":\"woocommerce-shipment-tracking\",\"id\":18693},{\"title\":\"Authorize.Net\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/Thumbnail-Authorize.Net-3-cdclct.png\",\"excerpt\":\"Authorize.Net gateway with support for pre-orders and subscriptions.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/authorize-net\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8b61524fe53add7fdd1a8d1b00b9327d\",\"slug\":\"woocommerce-gateway-authorize-net-cim\",\"id\":178481},{\"title\":\"WooCommerce Customer \\/ Order \\/ Coupon Export\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-Customer-Order-Coupon-Export-2.png\",\"excerpt\":\"Export customers, orders, and coupons from WooCommerce manually or on an automated schedule.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ordercustomer-csv-export\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"914de15813a903c767b55445608bf290\",\"slug\":\"woocommerce-customer-order-csv-export\",\"id\":18652},{\"title\":\"WooCommerce Bookings\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Dark.png\",\"excerpt\":\"Allow customers to book appointments, make reservations or rent equipment without leaving your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/hotel\\/\",\"price\":\"&#36;249.00\",\"hash\":\"911c438934af094c2b38d5560b9f50f3\",\"slug\":\"WooCommerce Bookings\",\"id\":390890},{\"title\":\"Amazon and eBay Integration for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/10\\/wooapplogoretina.png\",\"excerpt\":\"Sell on Amazon and eBay directly from your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-ebay-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e4000666-9275-4c71-8619-be61fb41c9f9\",\"slug\":\"woocommerce-amazon-ebay-integration\",\"id\":3545890},{\"title\":\"LiveChat for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2015\\/11\\/LC_woo_regular-zmiaym.png\",\"excerpt\":\"Live Chat and messaging platform for sales and support -- increase average order value and overall sales through live conversations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/livechat\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.livechat.com\\/livechat-for-ecommerce\\/?a=woocommerce&amp;utm_source=woocommerce.com&amp;utm_medium=integration&amp;utm_campaign=woocommerce.com\",\"price\":\"&#36;0.00\",\"hash\":\"5344cc1f-ed4a-4d00-beff-9d67f6d372f3\",\"slug\":\"livechat-woocommerce\",\"id\":1348888},{\"title\":\"Smart Coupons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/10\\/wc-product-smart-coupons.png\",\"excerpt\":\"Everything you need for discounts, coupons, credits, gift cards, product giveaways, offers, and promotions. Most popular and complete coupons plugin for WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/smart-coupons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demo.storeapps.org\\/?demo=sc\",\"price\":\"&#36;99.00\",\"hash\":\"05c45f2aa466106a466de4402fff9dde\",\"slug\":\"woocommerce-smart-coupons\",\"id\":18729},{\"title\":\"Dynamic Pricing\",\"image\":\"\",\"excerpt\":\"Bulk discounts, role-based pricing and much more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/dynamic-pricing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"9a41775bb33843f52c93c922b0053986\",\"slug\":\"woocommerce-dynamic-pricing\",\"id\":18643},{\"title\":\"Min\\/Max Quantities\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Min-Max-Qua-Dark.png\",\"excerpt\":\"Specify minimum and maximum allowed product quantities for orders to be completed.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/minmax-quantities\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"2b5188d90baecfb781a5aa2d6abb900a\",\"slug\":\"woocommerce-min-max-quantities\",\"id\":18616},{\"title\":\"WooCommerce Print Invoices &amp; Packing lists\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/03\\/Thumbnail-Print-Invoices-Packing-lists-2.png\",\"excerpt\":\"Generate invoices, packing slips, and pick lists for your WooCommerce orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/print-invoices-packing-lists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"465de1126817cdfb42d97ebca7eea717\",\"slug\":\"woocommerce-pip\",\"id\":18666},{\"title\":\"Name Your Price\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/09\\/nyp-icon-dark-v83owf.png\",\"excerpt\":\"Allow customers to define the product price. Also useful for accepting user-set donations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/name-your-price\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"31b4e11696cd99a3c0572975a84f1c08\",\"slug\":\"woocommerce-name-your-price\",\"id\":18738},{\"title\":\"FedEx Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/01\\/FedEx_Logo_Wallpaper.jpeg\",\"excerpt\":\"Get shipping rates from the FedEx API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/fedex-shipping-module\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1a48b598b47a81559baadef15e320f64\",\"slug\":\"woocommerce-shipping-fedex\",\"id\":18620},{\"title\":\"WooCommerce Zapier\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/woocommerce-zapier-logo.png\",\"excerpt\":\"Integrate with 2000+ cloud apps and services today.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-zapier\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;59.00\",\"hash\":\"0782bdbe932c00f4978850268c6cfe40\",\"slug\":\"woocommerce-zapier\",\"id\":243589},{\"title\":\"Product CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-CSV-Import-Dark.png\",\"excerpt\":\"Import, merge, and export products and variations to and from WooCommerce using a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"7ac9b00a1fe980fb61d28ab54d167d0d\",\"slug\":\"woocommerce-product-csv-import-suite\",\"id\":18680},{\"title\":\"Follow-Ups\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Follow-Ups-Dark.png\",\"excerpt\":\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/follow-up-emails\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"05ece68fe94558e65278fe54d9ec84d2\",\"slug\":\"woocommerce-follow-up-emails\",\"id\":18686},{\"title\":\"PayPal Payments Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Payments-Pro-Dark.png\",\"excerpt\":\"Take credit card payments directly on your checkout using PayPal Pro.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/paypal-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6d23ba7f0e0198937c0029f9e865b40e\",\"slug\":\"woocommerce-gateway-paypal-pro\",\"id\":18594},{\"title\":\"Google Product Feed\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2011\\/11\\/logo-regular-lscryp.png\",\"excerpt\":\"Allows you to create real-time product &amp; review feeds to supply product information to Google Merchant Center for setting up Google Product Ads. Also supports Bing Merchant Centre.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-product-feed\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d55b4f852872025741312839f142447e\",\"slug\":\"woocommerce-product-feeds\",\"id\":18619},{\"title\":\"Gravity Forms Product Add-ons\",\"image\":\"\",\"excerpt\":\"Powerful product add-ons, Gravity style\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/gravity-forms-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/gravity-forms\\/\",\"price\":\"&#36;99.00\",\"hash\":\"a6ac0ab1a1536e3a357ccf24c0650ed0\",\"slug\":\"woocommerce-gravityforms-product-addons\",\"id\":18633},{\"title\":\"Composite Products\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CP.png?v=1\",\"excerpt\":\"Create product kit builders and custom product configurators using existing products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/composite-products\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"0343e0115bbcb97ccd98442b8326a0af\",\"slug\":\"woocommerce-composite-products\",\"id\":216836},{\"title\":\"Product Vendors\",\"image\":\"\",\"excerpt\":\"Turn your store into a multi-vendor marketplace\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-vendors\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"a97d99fccd651bbdd728f4d67d492c31\",\"slug\":\"woocommerce-product-vendors\",\"id\":219982},{\"title\":\"WooCommerce Paid Courses\",\"image\":\"\",\"excerpt\":\"Sell your online courses using the most popular eCommerce platform on the web \\u2013 WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paid-courses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"bad2a02a063555b7e2bee59924690763\",\"slug\":\"woothemes-sensei\",\"id\":152116},{\"title\":\"WooCommerce AvaTax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2016\\/01\\/Thumbnail-Avalara-3-vfulwb.png\",\"excerpt\":\"Get 100% accurate sales tax calculations and on time tax return filing. No more tracking sales tax rates, rules, or jurisdictional boundaries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-avatax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"57077a4b28ba71cacf692bcf4a1a7f60\",\"slug\":\"woocommerce-avatax\",\"id\":1389326},{\"title\":\"WooCommerce Accommodation Bookings\",\"image\":\"\",\"excerpt\":\"Book accommodation using WooCommerce and the WooCommerce Bookings extension.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-accommodation-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"99b2a7a4af90b6cefd2a733b3b1f78e7\",\"slug\":\"woocommerce-accommodation-bookings\",\"id\":1412069},{\"title\":\"WooCommerce Brands\",\"image\":\"\",\"excerpt\":\"Create, assign and list brands for products, and allow customers to view by brand.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/brands\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"8a88c7cbd2f1e73636c331c7a86f818c\",\"slug\":\"woocommerce-brands\",\"id\":18737},{\"title\":\"Xero\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/08\\/xero2.png\",\"excerpt\":\"Save time with automated sync between WooCommerce and your Xero account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/xero\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"f0dd29d338d3c67cf6cee88eddf6869b\",\"slug\":\"woocommerce-xero\",\"id\":18733},{\"title\":\"Catalog Visibility Options\",\"image\":\"\",\"excerpt\":\"Transform WooCommerce into an online catalog by removing eCommerce functionality\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/catalog-visibility-options\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"12e791110365fdbb5865c8658907967e\",\"slug\":\"woocommerce-catalog-visibility-options\",\"id\":18648},{\"title\":\"Klarna Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/01\\/Partner_marketing_Klarna_Checkout_Black-1.png\",\"excerpt\":\"Klarna Checkout is a full checkout experience embedded on your site with Pay Now, Pay Later and Slice It. No credit card numbers, no passwords, no worries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/klarna-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.krokedil.se\\/klarnacheckout\\/\",\"price\":\"&#36;0.00\",\"hash\":\"90f8ce584e785fcd8c2d739fd4f40d78\",\"slug\":\"klarna-checkout-for-woocommerce\",\"id\":2754152},{\"title\":\"Advanced Notifications\",\"image\":\"\",\"excerpt\":\"Easily setup \\\"new order\\\" and stock email notifications for multiple recipients of your choosing.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/advanced-notifications\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"112372c44b002fea2640bd6bfafbca27\",\"slug\":\"woocommerce-advanced-notifications\",\"id\":18740},{\"title\":\"eWAY\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/eway-logo-3000-2000.jpg\",\"excerpt\":\"Take credit card payments securely via eWay (SG, MY, HK, AU, and NZ) keeping customers on your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2c497769d98d025e0d340cd0b5ea5da1\",\"slug\":\"woocommerce-gateway-eway\",\"id\":18604},{\"title\":\"WooCommerce Points and Rewards\",\"image\":\"\",\"excerpt\":\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-points-and-rewards\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"1649b6cca5da8b923b01ca56b5cdd246\",\"slug\":\"woocommerce-points-and-rewards\",\"id\":210259},{\"title\":\"Sequential Order Numbers Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Sequential-Order-Numbers-Pro-2.png\",\"excerpt\":\"Tame your order numbers! Advanced &amp; sequential order numbers with optional prefixes \\/ suffixes\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sequential-order-numbers-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"0b18a2816e016ba9988b93b1cd8fe766\",\"slug\":\"woocommerce-sequential-order-numbers-pro\",\"id\":18688},{\"title\":\"WooCommerce Checkout Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/07\\/Thumbnail-Checkout-Add-Ons-2.png\",\"excerpt\":\"Highlight relevant products, offers like free shipping and other up-sells during checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8fdca00b4000b7a8cc26371d0e470a8f\",\"slug\":\"woocommerce-checkout-add-ons\",\"id\":466854},{\"title\":\"WooCommerce Subscription Downloads\",\"image\":\"\",\"excerpt\":\"Offer additional downloads to your subscribers, via downloadable products listed in your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscription-downloads\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5be9e21c13953253e4406d2a700382ec\",\"slug\":\"woocommerce-subscription-downloads\",\"id\":420458},{\"title\":\"AutomateWoo\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-AutomateWoo-Dark-1.png\",\"excerpt\":\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/automatewoo\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"ba9299b8-1dba-4aa0-a313-28bc1755cb88\",\"slug\":\"automatewoo\",\"id\":4652610},{\"title\":\"Australia Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/australia-post.gif\",\"excerpt\":\"Get shipping rates for your WooCommerce store from the Australia Post API, which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/australia-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1dbd4dc6bd91a9cda1bd6b9e7a5e4f43\",\"slug\":\"woocommerce-shipping-australia-post\",\"id\":18622},{\"title\":\"WooCommerce Pre-Orders\",\"image\":\"\",\"excerpt\":\"Allow customers to order products before they are available.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-pre-orders\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"b2dc75e7d55e6f5bbfaccb59830f66b7\",\"slug\":\"woocommerce-pre-orders\",\"id\":178477},{\"title\":\"WooCommerce Google Analytics Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2016\\/01\\/Thumbnail-GAPro-3-b3imif.png\",\"excerpt\":\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d8aed8b7306b509eec1589e59abe319f\",\"slug\":\"woocommerce-google-analytics-pro\",\"id\":1312497},{\"title\":\"First Data\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/02\\/Thumbnail-FirstData-3-c5ssqi.png\",\"excerpt\":\"FirstData gateway for WooCommerce\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/firstdata\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb3e32663ec0810592eaf0d097796230\",\"slug\":\"woocommerce-gateway-firstdata\",\"id\":18645},{\"title\":\"Conditional Shipping and Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CSP.png?v=1\",\"excerpt\":\"Use conditional logic to restrict the shipping and payment options available on your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/conditional-shipping-and-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1f56ff002fa830b77017b0107505211a\",\"slug\":\"woocommerce-conditional-shipping-and-payments\",\"id\":680253},{\"title\":\"Canada Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/canada-post.png\",\"excerpt\":\"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/canada-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ac029cdf3daba20b20c7b9be7dc00e0e\",\"slug\":\"woocommerce-shipping-canada-post\",\"id\":18623},{\"title\":\"WooSlider\",\"image\":\"\",\"excerpt\":\"WooSlider is the ultimate responsive slideshow WordPress slider plugin\\r\\n\\r\\n\\u00a0\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/wooslider\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/www.wooslider.com\\/\",\"price\":\"&#36;49.00\",\"hash\":\"209d98f3ccde6cc3de7e8732a2b20b6a\",\"slug\":\"wooslider\",\"id\":46506},{\"title\":\"WooCommerce Order Status Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/02\\/Thumbnail-Order-Status-Manager-2.png\",\"excerpt\":\"Create, edit, and delete completely custom order statuses and integrate them seamlessly into your order management flow.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"51fd9ab45394b4cad5a0ebf58d012342\",\"slug\":\"woocommerce-order-status-manager\",\"id\":588398},{\"title\":\"WooCommerce One Page Checkout\",\"image\":\"\",\"excerpt\":\"Create special pages where customers can choose products, checkout &amp; pay all on the one page.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-one-page-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"c9ba8f8352cd71b5508af5161268619a\",\"slug\":\"woocommerce-one-page-checkout\",\"id\":527886},{\"title\":\"WooCommerce Social Login\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/08\\/Thumbnail-Social-Login-2.png\",\"excerpt\":\"Enable Social Login for seamless checkout and account creation.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-social-login\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demos.skyverge.com\\/woocommerce-social-login\\/\",\"price\":\"&#36;79.00\",\"hash\":\"b231cd6367a79cc8a53b7d992d77525d\",\"slug\":\"woocommerce-social-login\",\"id\":473617},{\"title\":\"WooCommerce Product Search\",\"image\":\"\",\"excerpt\":\"The perfect search engine helps customers to find and buy products quickly \\u2013 essential for every WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-product-search\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.itthinx.com\\/wps\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c84cc8ca16ddac3408e6b6c5871133a8\",\"slug\":\"woocommerce-product-search\",\"id\":512174},{\"title\":\"Variation Swatches and Photos\",\"image\":\"\",\"excerpt\":\"Show color and image swatches instead of dropdowns for variable products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/variation-swatches-and-photos\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/swatches-and-photos\\/\",\"price\":\"&#36;99.00\",\"hash\":\"37bea8d549df279c8278878d081b062f\",\"slug\":\"woocommerce-variation-swatches-and-photos\",\"id\":18697},{\"title\":\"WooCommerce Additional Variation Images\",\"image\":\"\",\"excerpt\":\"Add gallery images per variation on variable products within WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-additional-variation-images\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/storefront\\/product\\/woo-single-1\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c61dd6de57dcecb32bd7358866de4539\",\"slug\":\"woocommerce-additional-variation-images\",\"id\":477384},{\"title\":\"WooCommerce Order Status Control\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/06\\/Thumbnail-Order-Status-Control-2.png\",\"excerpt\":\"Use this extension to automatically change the order status to \\\"completed\\\" after successful payment.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-control\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"32400e509c7c36dcc1cd368e8267d981\",\"slug\":\"woocommerce-order-status-control\",\"id\":439037},{\"title\":\"WooCommerce Deposits\",\"image\":\"\",\"excerpt\":\"Enable customers to pay for products using a deposit or a payment plan.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-deposits\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;179.00\",\"hash\":\"de192a6cf12c4fd803248da5db700762\",\"slug\":\"woocommerce-deposits\",\"id\":977087},{\"title\":\"WooCommerce Blocks\",\"image\":\"\",\"excerpt\":\"WooCommerce Blocks offers a range of Gutenberg blocks you can use to build and customise your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gutenberg-products-block\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c2e9f13a-f90c-4ffe-a8a5-b432399ec263\",\"slug\":\"woo-gutenberg-products-block\",\"id\":3076677},{\"title\":\"Opayo (Formerly SagePay)\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/Opayo_logo_RGB.png\",\"excerpt\":\"Take payments on your WooCommerce store via Opayo (formally SagePay).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sage-pay-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc0cca47d0274d8ef9b164f6fbec1cc\",\"slug\":\"woocommerce-gateway-sagepay-form\",\"id\":18599},{\"title\":\"EU VAT Number\",\"image\":\"\",\"excerpt\":\"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eu-vat-number\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"d2720c4b4bb8d6908e530355b7a2d734\",\"slug\":\"woocommerce-eu-vat-number\",\"id\":18592},{\"title\":\"Amazon S3 Storage\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/amazon.png\",\"excerpt\":\"Serve digital products via Amazon S3\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-s3-storage\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"473bf6f221b865eff165c97881b473bb\",\"slug\":\"woocommerce-amazon-s3-storage\",\"id\":18663},{\"title\":\"QuickBooks Commerce (formerly TradeGecko)\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/09\\/qbo-mark.png\",\"excerpt\":\"Get a wholesale and multichannel inventory &amp; order management platform for your WooCommerce store with QuickBooks Commerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-tradegecko\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"21da7811f7fc1f13ee19daa7415f0ff3\",\"slug\":\"woocommerce-tradegecko\",\"id\":245960},{\"title\":\"TaxJar\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/10\\/taxjar-logotype.png\",\"excerpt\":\"Save hours every month by putting your sales tax on autopilot. Automated, multi-state sales tax calculation, reporting, and filing for your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/taxjar\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"12072d8e-e933-4561-97b1-9db3c7eeed91\",\"slug\":\"taxjar-simplified-taxes-for-woocommerce\",\"id\":514914},{\"title\":\"WooCommerce Tab Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/11\\/Thumbnail-Tab-Manager-2.png\",\"excerpt\":\"Gives you complete control over your product page tabs, create local and global tabs using a visual drag-and-drop interface, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-tab-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"89a9ac74850855cfe772b4b4ee1e31e0\",\"slug\":\"woocommerce-tab-manager\",\"id\":132195},{\"title\":\"Cart Add-ons\",\"image\":\"\",\"excerpt\":\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/cart-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"3a8ef25334396206f5da4cf208adeda3\",\"slug\":\"woocommerce-cart-add-ons\",\"id\":18717},{\"title\":\"Shipping Multiple Addresses\",\"image\":\"\",\"excerpt\":\"Allow your customers to ship individual items in a single order to multiple addresses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping-multiple-addresses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa0eb6f777846d329952d5b891d6f8cc\",\"slug\":\"woocommerce-shipping-multiple-addresses\",\"id\":18741},{\"title\":\"Customer\\/Order\\/Coupon CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/07\\/Thumbnail-Customer-Order-Coupon-CSV-Import-Suite-2.png\",\"excerpt\":\"Import both customers and orders into WooCommerce from a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/customerorder-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb00ca8317a0f64dbe185c995e5ea3df\",\"slug\":\"woocommerce-customer-order-csv-import\",\"id\":18709},{\"title\":\"QuickBooks Sync for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/04\\/woocommerce-com-logo-1-hyhzbh.png\",\"excerpt\":\"Automatic two-way sync for orders, customers, products, inventory and more between WooCommerce and QuickBooks (Online, Desktop, or POS).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/quickbooks-sync-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c5e32e20-7c1f-4585-8b15-d930c2d842ac\",\"slug\":\"myworks-woo-sync-for-quickbooks-online\",\"id\":4065824},{\"title\":\"Coupon Shortcodes\",\"image\":\"\",\"excerpt\":\"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/coupon-shortcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"ac5d9d51-70b2-4d8f-8b89-24200eea1394\",\"slug\":\"woocommerce-coupon-shortcodes\",\"id\":244762},{\"title\":\"Worldpay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/WorldpayLogo2018.png\",\"excerpt\":\"Take payments via Worldpay Business Gateway.\\r\\n\\r\\n&nbsp;\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/worldpay\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc48c9d12dc0c43add4b099665a80b0\",\"slug\":\"woocommerce-gateway-worldpay\",\"id\":18646},{\"title\":\"Groups for WooCommerce\",\"image\":\"\",\"excerpt\":\"Sell Memberships with Groups and WooCommerce \\u2013\\u00a0the best Group Membership and Access Control solution for WordPress and WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/groups-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"aa2d455ed00566e4fb71bc9d53f2613b\",\"slug\":\"groups-woocommerce\",\"id\":18704},{\"title\":\"Per Product Shipping\",\"image\":\"\",\"excerpt\":\"Define separate shipping costs per product which are combined at checkout to provide a total shipping cost.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/per-product-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ba16bebba1d74992efc398d575bf269e\",\"slug\":\"woocommerce-shipping-per-product\",\"id\":18590},{\"title\":\"Jilt\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2017\\/12\\/Thumbnail-Jilt-3-s6qjnb.png\",\"excerpt\":\"All-in-one email marketing platform built for WooCommerce stores. Send newsletters, abandoned cart reminders, win-backs, welcome automations, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jilt\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b53aafb64dca33835e41ee06de7e9816\",\"slug\":\"jilt-for-woocommerce\",\"id\":2754876},{\"title\":\"Royal Mail\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/royalmail.png\",\"excerpt\":\"Offer Royal Mail shipping rates to your customers\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/royal-mail\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"03839cca1a16c4488fcb669aeb91a056\",\"slug\":\"woocommerce-shipping-royalmail\",\"id\":182719},{\"title\":\"Bulk Stock Management\",\"image\":\"\",\"excerpt\":\"Edit product and variation stock levels in bulk via this handy interface\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bulk-stock-management\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"02f4328d52f324ebe06a78eaaae7934f\",\"slug\":\"woocommerce-bulk-stock-management\",\"id\":18670},{\"title\":\"Intuit Payments Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/11\\/Thumbnail-Intuit-Payments-2-im8zes.png\",\"excerpt\":\"Allow customers to securely save multiple payment methods to their account for faster checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/intuit-qbms\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"56ee7c24d725409e3244401ed625b4f3\",\"slug\":\"woocommerce-gateway-intuit-qbms\",\"id\":272221},{\"title\":\"Cost of Goods\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/04\\/Thumbnail-Cost-of-Goods-2.png\",\"excerpt\":\"Easily track profit by including \\u00a0cost of goods in your reports\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-cost-of-goods\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9908a60a5feefec5e33b38359f5f6964\",\"slug\":\"woocommerce-cost-of-goods\",\"id\":185438},{\"title\":\"WooCommerce Email Customizer\",\"image\":\"\",\"excerpt\":\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-email-customizer\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"bd909fa97874d431f203b5336c7e8873\",\"slug\":\"woocommerce-email-customizer\",\"id\":853277},{\"title\":\"WooCommerce Quick View\",\"image\":\"\",\"excerpt\":\"Show a quick-view button to view product details and add to cart via lightbox popup\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-quick-view\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"619c6e57ce72c49c4b57e15b06eddb65\",\"slug\":\"woocommerce-quick-view\",\"id\":187509},{\"title\":\"Force Sells\",\"image\":\"\",\"excerpt\":\"Force products to be added to the cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/force-sells\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"3ebddfc491ca168a4ea4800b893302b0\",\"slug\":\"woocommerce-force-sells\",\"id\":18678},{\"title\":\"Local Pickup Plus\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Local-Pickup-Plus-2.png\",\"excerpt\":\"Let customers pick up products from specific locations, select a pickup date, and more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/local-pickup-plus\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"4d6fbe9e8968a669d11cec40b85a0caa\",\"slug\":\"woocommerce-shipping-local-pickup-plus\",\"id\":18696},{\"title\":\"WooCommerce Purchase Order Gateway\",\"image\":\"\",\"excerpt\":\"Receive purchase orders via your WooCommerce-powered online store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-purchase-order\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"573a92318244ece5facb449d63e74874\",\"slug\":\"woocommerce-gateway-purchase-order\",\"id\":478542},{\"title\":\"WooCommerce Wishlists\",\"image\":\"\",\"excerpt\":\"WooCommerce Wishlists allows guests and customers to create and add products to an unlimited number of Wishlists.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-wishlists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/wishlist-demos\\/\",\"price\":\"&#36;79.00\",\"hash\":\"6bd20993ea96333eab6931ec2adc6d63\",\"slug\":\"woocommerce-wishlists\",\"id\":171144},{\"title\":\"Returns and Warranty Requests\",\"image\":\"\",\"excerpt\":\"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns \\/ exchanges from their account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/warranty-requests\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9b4c41102e6b61ea5f558e16f9b63e25\",\"slug\":\"woocommerce-warranty\",\"id\":228315},{\"title\":\"Elavon Converge Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/07\\/Thumbnail-Elavon-3-ijkwkr.png\",\"excerpt\":\"Take credit card payments with Elavon, the fourth largest merchant acquirer in North America.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/elavon-vm-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"2732aedb77a13149b4db82d484d3bb22\",\"slug\":\"woocommerce-gateway-elavon\",\"id\":18722}]}\";s:8:\"response\";a:2:{s:4:\"code\";i:200;s:7:\"message\";s:2:\"OK\";}s:7:\"cookies\";a:0:{}s:8:\"filename\";N;s:13:\"http_response\";O:25:\"WP_HTTP_Requests_Response\":5:{s:11:\"\0*\0response\";O:17:\"Requests_Response\":10:{s:4:\"body\";s:48161:\"{\"products\":[{\"title\":\"WooCommerce Google Analytics\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/GA-Dark.png\",\"excerpt\":\"Understand your customers and increase revenue with world\\u2019s leading analytics platform - integrated with WooCommerce for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2d21f7de14dfb8e9885a4622be701ddf\",\"slug\":\"woocommerce-google-analytics-integration\",\"id\":1442927},{\"title\":\"WooCommerce Tax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Tax-Dark.png\",\"excerpt\":\"Get live rates, discounted labels, tracking numbers, and more \\u2013 without leaving your dashboard.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/tax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":3220291},{\"title\":\"Stripe\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Stripe-Dark-1.png\",\"excerpt\":\"Accept all major debit and credit cards as well as local payment methods with Stripe.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/stripe\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"50bb7a985c691bb943a9da4d2c8b5efd\",\"slug\":\"woocommerce-gateway-stripe\",\"id\":18627},{\"title\":\"Jetpack\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Jetpack-Dark.png\",\"excerpt\":\"Power up and protect your store with Jetpack\\r\\n\\r\\nFor free security, insights and monitoring, connect to Jetpack. It\'s everything you need for a strong, secure start.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jetpack\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"d5bfef9700b62b2b132c74c74c3193eb\",\"slug\":\"jetpack\",\"id\":2725249},{\"title\":\"Facebook for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Facebook-Dark.png\",\"excerpt\":\"Get the Official Facebook for WooCommerce plugin for three powerful ways to help grow your business.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/facebook\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"0ea4fe4c2d7ca6338f8a322fb3e4e187\",\"slug\":\"facebook-for-woocommerce\",\"id\":2127297},{\"title\":\"Amazon Pay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Amazon-Pay-Dark.png\",\"excerpt\":\"Amazon Pay is embedded in your WooCommerce store. Transactions take place via\\u00a0Amazon widgets, so the buyer never leaves your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/pay-with-amazon\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9865e043bbbe4f8c9735af31cb509b53\",\"slug\":\"woocommerce-gateway-amazon-payments-advanced\",\"id\":238816},{\"title\":\"Square for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Square-Dark.png\",\"excerpt\":\"Accepting payments is easy with Square. Clear rates, fast deposits (1-2 business days). Sell online and in person, and sync all payments, items and inventory.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/square\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e907be8b86d7df0c8f8e0d0020b52638\",\"slug\":\"woocommerce-square\",\"id\":1770503},{\"title\":\"WooCommerce Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Dark-1.png\",\"excerpt\":\"Save time and money with WooCommerce Shipping. Print labels right from your WooCommerce dashboard at the lowest USPS rates.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":2165910},{\"title\":\"WooCommerce Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Pay-Dark.png\",\"excerpt\":\"The only payment method designed exclusively for WooCommerce, by WooCommerce. Securely accept major credit and debit cards on your site. View and manage your transactions within your WordPress dashboard.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"8c6319ca-8f41-4e69-be63-6b15ee37773b\",\"slug\":\"woocommerce-payments\",\"id\":5278104},{\"title\":\"ShipStation Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Shipstation-Dark.png\",\"excerpt\":\"Fulfill all your Woo orders (and wherever else you sell) quickly and easily using ShipStation. Try it free for 30 days today!\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipstation-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9de8640767ba64237808ed7f245a49bb\",\"slug\":\"woocommerce-shipstation-integration\",\"id\":18734},{\"title\":\"WooCommerce Subscriptions\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Subscriptions-Dark.png\",\"excerpt\":\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscriptions\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"6115e6d7e297b623a169fdcf5728b224\",\"slug\":\"woocommerce-subscriptions\",\"id\":27147},{\"title\":\"Mailchimp for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/09\\/logo-mailchimp-dark-v2.png\",\"excerpt\":\"Increase traffic, drive repeat purchases, and personalize your marketing when you connect to Mailchimp.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/mailchimp-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b4481616ebece8b1ff68fc59b90c1a91\",\"slug\":\"mailchimp-for-woocommerce\",\"id\":2545166},{\"title\":\"PayPal Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Dark.png\",\"excerpt\":\"PayPal Checkout now with Smart Payment Buttons\\u2122, dynamically displays, PayPal, Venmo, PayPal Credit, or other local payment options in a single stack giving customers the choice to pay with their preferred option.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"69e6cba62ac4021df9e117cc3f716d07\",\"slug\":\"woocommerce-gateway-paypal-express-checkout\",\"id\":1597922},{\"title\":\"PayFast Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Payfast-Dark-1.png\",\"excerpt\":\"Take payments on your WooCommerce store via PayFast (redirect method).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/payfast-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"557bf07293ad916f20c207c6c9cd15ff\",\"slug\":\"woocommerce-payfast-gateway\",\"id\":18596},{\"title\":\"Product Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-Add-Ons-Dark.png\",\"excerpt\":\"Offer add-ons like gift wrapping, special messages or other special options for your products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"147d0077e591e16db9d0d67daeb8c484\",\"slug\":\"woocommerce-product-addons\",\"id\":18618},{\"title\":\"Google Ads &#038; Marketing by Kliken\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/02\\/GA-for-Woo-Logo-374x192px-qu3duk.png\",\"excerpt\":\"Get in front of shoppers and drive traffic to your store so you can grow your business with Smart Shopping Campaigns and free listings.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-ads-and-marketing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"bf66e173-a220-4da7-9512-b5728c20fc16\",\"slug\":\"kliken-marketing-for-google\",\"id\":3866145},{\"title\":\"Braintree for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/02\\/braintree-black-copy.png\",\"excerpt\":\"Accept PayPal, credit cards and debit cards with a single payment gateway solution \\u2014 PayPal Powered by Braintree.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-powered-by-braintree\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"27f010c8e34ca65b205ddec88ad14536\",\"slug\":\"woocommerce-gateway-paypal-powered-by-braintree\",\"id\":1489837},{\"title\":\"WooCommerce Memberships\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/06\\/Thumbnail-Memberships-2.png\",\"excerpt\":\"Give members access to restricted content or products, for a fee or for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-memberships\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"9288e7609ad0b487b81ef6232efa5cfc\",\"slug\":\"woocommerce-memberships\",\"id\":958589},{\"title\":\"USPS Shipping Method\",\"image\":\"\",\"excerpt\":\"Get shipping rates from the USPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/usps-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"83d1524e8f5f1913e58889f83d442c32\",\"slug\":\"woocommerce-shipping-usps\",\"id\":18657},{\"title\":\"Product Bundles\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-PB.png?v=1\",\"excerpt\":\"Offer personalized product bundles, bulk discount packages and assembled\\u00a0products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-bundles\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa2518b5-ab19-4b75-bde9-60ca51e20f28\",\"slug\":\"woocommerce-product-bundles\",\"id\":18716},{\"title\":\"UPS Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/UPS-Shipping-Method-Dark.png\",\"excerpt\":\"Get shipping rates from the UPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ups-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8dae58502913bac0fbcdcaba515ea998\",\"slug\":\"woocommerce-shipping-ups\",\"id\":18665},{\"title\":\"Table Rate Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Product-Table-Rate-Shipping-Dark.png\",\"excerpt\":\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/table-rate-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"3034ed8aff427b0f635fe4c86bbf008a\",\"slug\":\"woocommerce-table-rate-shipping\",\"id\":18718},{\"title\":\"Checkout Field Editor\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Checkout-Field-Editor-Dark.png\",\"excerpt\":\"Optimize your checkout process by adding, removing or editing fields to suit your needs.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-field-editor\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"2b8029f0d7cdd1118f4d843eb3ab43ff\",\"slug\":\"woocommerce-checkout-field-editor\",\"id\":184594},{\"title\":\"Shipment Tracking\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Tracking-Dark-1.png\",\"excerpt\":\"Add shipment tracking information to your orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipment-tracking\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"1968e199038a8a001c9f9966fd06bf88\",\"slug\":\"woocommerce-shipment-tracking\",\"id\":18693},{\"title\":\"Authorize.Net\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/Thumbnail-Authorize.Net-3-cdclct.png\",\"excerpt\":\"Authorize.Net gateway with support for pre-orders and subscriptions.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/authorize-net\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8b61524fe53add7fdd1a8d1b00b9327d\",\"slug\":\"woocommerce-gateway-authorize-net-cim\",\"id\":178481},{\"title\":\"WooCommerce Customer \\/ Order \\/ Coupon Export\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-Customer-Order-Coupon-Export-2.png\",\"excerpt\":\"Export customers, orders, and coupons from WooCommerce manually or on an automated schedule.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ordercustomer-csv-export\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"914de15813a903c767b55445608bf290\",\"slug\":\"woocommerce-customer-order-csv-export\",\"id\":18652},{\"title\":\"WooCommerce Bookings\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Dark.png\",\"excerpt\":\"Allow customers to book appointments, make reservations or rent equipment without leaving your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/hotel\\/\",\"price\":\"&#36;249.00\",\"hash\":\"911c438934af094c2b38d5560b9f50f3\",\"slug\":\"WooCommerce Bookings\",\"id\":390890},{\"title\":\"Amazon and eBay Integration for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/10\\/wooapplogoretina.png\",\"excerpt\":\"Sell on Amazon and eBay directly from your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-ebay-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e4000666-9275-4c71-8619-be61fb41c9f9\",\"slug\":\"woocommerce-amazon-ebay-integration\",\"id\":3545890},{\"title\":\"LiveChat for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2015\\/11\\/LC_woo_regular-zmiaym.png\",\"excerpt\":\"Live Chat and messaging platform for sales and support -- increase average order value and overall sales through live conversations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/livechat\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.livechat.com\\/livechat-for-ecommerce\\/?a=woocommerce&amp;utm_source=woocommerce.com&amp;utm_medium=integration&amp;utm_campaign=woocommerce.com\",\"price\":\"&#36;0.00\",\"hash\":\"5344cc1f-ed4a-4d00-beff-9d67f6d372f3\",\"slug\":\"livechat-woocommerce\",\"id\":1348888},{\"title\":\"Smart Coupons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/10\\/wc-product-smart-coupons.png\",\"excerpt\":\"Everything you need for discounts, coupons, credits, gift cards, product giveaways, offers, and promotions. Most popular and complete coupons plugin for WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/smart-coupons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demo.storeapps.org\\/?demo=sc\",\"price\":\"&#36;99.00\",\"hash\":\"05c45f2aa466106a466de4402fff9dde\",\"slug\":\"woocommerce-smart-coupons\",\"id\":18729},{\"title\":\"Dynamic Pricing\",\"image\":\"\",\"excerpt\":\"Bulk discounts, role-based pricing and much more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/dynamic-pricing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"9a41775bb33843f52c93c922b0053986\",\"slug\":\"woocommerce-dynamic-pricing\",\"id\":18643},{\"title\":\"Min\\/Max Quantities\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Min-Max-Qua-Dark.png\",\"excerpt\":\"Specify minimum and maximum allowed product quantities for orders to be completed.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/minmax-quantities\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"2b5188d90baecfb781a5aa2d6abb900a\",\"slug\":\"woocommerce-min-max-quantities\",\"id\":18616},{\"title\":\"WooCommerce Print Invoices &amp; Packing lists\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/03\\/Thumbnail-Print-Invoices-Packing-lists-2.png\",\"excerpt\":\"Generate invoices, packing slips, and pick lists for your WooCommerce orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/print-invoices-packing-lists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"465de1126817cdfb42d97ebca7eea717\",\"slug\":\"woocommerce-pip\",\"id\":18666},{\"title\":\"Name Your Price\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/09\\/nyp-icon-dark-v83owf.png\",\"excerpt\":\"Allow customers to define the product price. Also useful for accepting user-set donations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/name-your-price\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"31b4e11696cd99a3c0572975a84f1c08\",\"slug\":\"woocommerce-name-your-price\",\"id\":18738},{\"title\":\"FedEx Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/01\\/FedEx_Logo_Wallpaper.jpeg\",\"excerpt\":\"Get shipping rates from the FedEx API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/fedex-shipping-module\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1a48b598b47a81559baadef15e320f64\",\"slug\":\"woocommerce-shipping-fedex\",\"id\":18620},{\"title\":\"WooCommerce Zapier\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/woocommerce-zapier-logo.png\",\"excerpt\":\"Integrate with 2000+ cloud apps and services today.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-zapier\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;59.00\",\"hash\":\"0782bdbe932c00f4978850268c6cfe40\",\"slug\":\"woocommerce-zapier\",\"id\":243589},{\"title\":\"Product CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-CSV-Import-Dark.png\",\"excerpt\":\"Import, merge, and export products and variations to and from WooCommerce using a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"7ac9b00a1fe980fb61d28ab54d167d0d\",\"slug\":\"woocommerce-product-csv-import-suite\",\"id\":18680},{\"title\":\"Follow-Ups\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Follow-Ups-Dark.png\",\"excerpt\":\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/follow-up-emails\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"05ece68fe94558e65278fe54d9ec84d2\",\"slug\":\"woocommerce-follow-up-emails\",\"id\":18686},{\"title\":\"PayPal Payments Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Payments-Pro-Dark.png\",\"excerpt\":\"Take credit card payments directly on your checkout using PayPal Pro.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/paypal-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6d23ba7f0e0198937c0029f9e865b40e\",\"slug\":\"woocommerce-gateway-paypal-pro\",\"id\":18594},{\"title\":\"Google Product Feed\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2011\\/11\\/logo-regular-lscryp.png\",\"excerpt\":\"Allows you to create real-time product &amp; review feeds to supply product information to Google Merchant Center for setting up Google Product Ads. Also supports Bing Merchant Centre.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-product-feed\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d55b4f852872025741312839f142447e\",\"slug\":\"woocommerce-product-feeds\",\"id\":18619},{\"title\":\"Gravity Forms Product Add-ons\",\"image\":\"\",\"excerpt\":\"Powerful product add-ons, Gravity style\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/gravity-forms-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/gravity-forms\\/\",\"price\":\"&#36;99.00\",\"hash\":\"a6ac0ab1a1536e3a357ccf24c0650ed0\",\"slug\":\"woocommerce-gravityforms-product-addons\",\"id\":18633},{\"title\":\"Composite Products\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CP.png?v=1\",\"excerpt\":\"Create product kit builders and custom product configurators using existing products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/composite-products\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"0343e0115bbcb97ccd98442b8326a0af\",\"slug\":\"woocommerce-composite-products\",\"id\":216836},{\"title\":\"Product Vendors\",\"image\":\"\",\"excerpt\":\"Turn your store into a multi-vendor marketplace\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-vendors\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"a97d99fccd651bbdd728f4d67d492c31\",\"slug\":\"woocommerce-product-vendors\",\"id\":219982},{\"title\":\"WooCommerce Paid Courses\",\"image\":\"\",\"excerpt\":\"Sell your online courses using the most popular eCommerce platform on the web \\u2013 WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paid-courses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"bad2a02a063555b7e2bee59924690763\",\"slug\":\"woothemes-sensei\",\"id\":152116},{\"title\":\"WooCommerce AvaTax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2016\\/01\\/Thumbnail-Avalara-3-vfulwb.png\",\"excerpt\":\"Get 100% accurate sales tax calculations and on time tax return filing. No more tracking sales tax rates, rules, or jurisdictional boundaries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-avatax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"57077a4b28ba71cacf692bcf4a1a7f60\",\"slug\":\"woocommerce-avatax\",\"id\":1389326},{\"title\":\"WooCommerce Accommodation Bookings\",\"image\":\"\",\"excerpt\":\"Book accommodation using WooCommerce and the WooCommerce Bookings extension.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-accommodation-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"99b2a7a4af90b6cefd2a733b3b1f78e7\",\"slug\":\"woocommerce-accommodation-bookings\",\"id\":1412069},{\"title\":\"WooCommerce Brands\",\"image\":\"\",\"excerpt\":\"Create, assign and list brands for products, and allow customers to view by brand.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/brands\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"8a88c7cbd2f1e73636c331c7a86f818c\",\"slug\":\"woocommerce-brands\",\"id\":18737},{\"title\":\"Xero\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/08\\/xero2.png\",\"excerpt\":\"Save time with automated sync between WooCommerce and your Xero account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/xero\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"f0dd29d338d3c67cf6cee88eddf6869b\",\"slug\":\"woocommerce-xero\",\"id\":18733},{\"title\":\"Catalog Visibility Options\",\"image\":\"\",\"excerpt\":\"Transform WooCommerce into an online catalog by removing eCommerce functionality\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/catalog-visibility-options\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"12e791110365fdbb5865c8658907967e\",\"slug\":\"woocommerce-catalog-visibility-options\",\"id\":18648},{\"title\":\"Klarna Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/01\\/Partner_marketing_Klarna_Checkout_Black-1.png\",\"excerpt\":\"Klarna Checkout is a full checkout experience embedded on your site with Pay Now, Pay Later and Slice It. No credit card numbers, no passwords, no worries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/klarna-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.krokedil.se\\/klarnacheckout\\/\",\"price\":\"&#36;0.00\",\"hash\":\"90f8ce584e785fcd8c2d739fd4f40d78\",\"slug\":\"klarna-checkout-for-woocommerce\",\"id\":2754152},{\"title\":\"Advanced Notifications\",\"image\":\"\",\"excerpt\":\"Easily setup \\\"new order\\\" and stock email notifications for multiple recipients of your choosing.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/advanced-notifications\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"112372c44b002fea2640bd6bfafbca27\",\"slug\":\"woocommerce-advanced-notifications\",\"id\":18740},{\"title\":\"eWAY\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/eway-logo-3000-2000.jpg\",\"excerpt\":\"Take credit card payments securely via eWay (SG, MY, HK, AU, and NZ) keeping customers on your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2c497769d98d025e0d340cd0b5ea5da1\",\"slug\":\"woocommerce-gateway-eway\",\"id\":18604},{\"title\":\"WooCommerce Points and Rewards\",\"image\":\"\",\"excerpt\":\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-points-and-rewards\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"1649b6cca5da8b923b01ca56b5cdd246\",\"slug\":\"woocommerce-points-and-rewards\",\"id\":210259},{\"title\":\"Sequential Order Numbers Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Sequential-Order-Numbers-Pro-2.png\",\"excerpt\":\"Tame your order numbers! Advanced &amp; sequential order numbers with optional prefixes \\/ suffixes\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sequential-order-numbers-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"0b18a2816e016ba9988b93b1cd8fe766\",\"slug\":\"woocommerce-sequential-order-numbers-pro\",\"id\":18688},{\"title\":\"WooCommerce Checkout Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/07\\/Thumbnail-Checkout-Add-Ons-2.png\",\"excerpt\":\"Highlight relevant products, offers like free shipping and other up-sells during checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8fdca00b4000b7a8cc26371d0e470a8f\",\"slug\":\"woocommerce-checkout-add-ons\",\"id\":466854},{\"title\":\"WooCommerce Subscription Downloads\",\"image\":\"\",\"excerpt\":\"Offer additional downloads to your subscribers, via downloadable products listed in your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscription-downloads\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5be9e21c13953253e4406d2a700382ec\",\"slug\":\"woocommerce-subscription-downloads\",\"id\":420458},{\"title\":\"AutomateWoo\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-AutomateWoo-Dark-1.png\",\"excerpt\":\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/automatewoo\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"ba9299b8-1dba-4aa0-a313-28bc1755cb88\",\"slug\":\"automatewoo\",\"id\":4652610},{\"title\":\"Australia Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/australia-post.gif\",\"excerpt\":\"Get shipping rates for your WooCommerce store from the Australia Post API, which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/australia-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1dbd4dc6bd91a9cda1bd6b9e7a5e4f43\",\"slug\":\"woocommerce-shipping-australia-post\",\"id\":18622},{\"title\":\"WooCommerce Pre-Orders\",\"image\":\"\",\"excerpt\":\"Allow customers to order products before they are available.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-pre-orders\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"b2dc75e7d55e6f5bbfaccb59830f66b7\",\"slug\":\"woocommerce-pre-orders\",\"id\":178477},{\"title\":\"WooCommerce Google Analytics Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2016\\/01\\/Thumbnail-GAPro-3-b3imif.png\",\"excerpt\":\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d8aed8b7306b509eec1589e59abe319f\",\"slug\":\"woocommerce-google-analytics-pro\",\"id\":1312497},{\"title\":\"First Data\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/02\\/Thumbnail-FirstData-3-c5ssqi.png\",\"excerpt\":\"FirstData gateway for WooCommerce\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/firstdata\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb3e32663ec0810592eaf0d097796230\",\"slug\":\"woocommerce-gateway-firstdata\",\"id\":18645},{\"title\":\"Conditional Shipping and Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CSP.png?v=1\",\"excerpt\":\"Use conditional logic to restrict the shipping and payment options available on your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/conditional-shipping-and-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1f56ff002fa830b77017b0107505211a\",\"slug\":\"woocommerce-conditional-shipping-and-payments\",\"id\":680253},{\"title\":\"Canada Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/canada-post.png\",\"excerpt\":\"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/canada-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ac029cdf3daba20b20c7b9be7dc00e0e\",\"slug\":\"woocommerce-shipping-canada-post\",\"id\":18623},{\"title\":\"WooSlider\",\"image\":\"\",\"excerpt\":\"WooSlider is the ultimate responsive slideshow WordPress slider plugin\\r\\n\\r\\n\\u00a0\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/wooslider\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/www.wooslider.com\\/\",\"price\":\"&#36;49.00\",\"hash\":\"209d98f3ccde6cc3de7e8732a2b20b6a\",\"slug\":\"wooslider\",\"id\":46506},{\"title\":\"WooCommerce Order Status Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/02\\/Thumbnail-Order-Status-Manager-2.png\",\"excerpt\":\"Create, edit, and delete completely custom order statuses and integrate them seamlessly into your order management flow.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"51fd9ab45394b4cad5a0ebf58d012342\",\"slug\":\"woocommerce-order-status-manager\",\"id\":588398},{\"title\":\"WooCommerce One Page Checkout\",\"image\":\"\",\"excerpt\":\"Create special pages where customers can choose products, checkout &amp; pay all on the one page.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-one-page-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"c9ba8f8352cd71b5508af5161268619a\",\"slug\":\"woocommerce-one-page-checkout\",\"id\":527886},{\"title\":\"WooCommerce Social Login\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/08\\/Thumbnail-Social-Login-2.png\",\"excerpt\":\"Enable Social Login for seamless checkout and account creation.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-social-login\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demos.skyverge.com\\/woocommerce-social-login\\/\",\"price\":\"&#36;79.00\",\"hash\":\"b231cd6367a79cc8a53b7d992d77525d\",\"slug\":\"woocommerce-social-login\",\"id\":473617},{\"title\":\"WooCommerce Product Search\",\"image\":\"\",\"excerpt\":\"The perfect search engine helps customers to find and buy products quickly \\u2013 essential for every WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-product-search\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.itthinx.com\\/wps\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c84cc8ca16ddac3408e6b6c5871133a8\",\"slug\":\"woocommerce-product-search\",\"id\":512174},{\"title\":\"Variation Swatches and Photos\",\"image\":\"\",\"excerpt\":\"Show color and image swatches instead of dropdowns for variable products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/variation-swatches-and-photos\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/swatches-and-photos\\/\",\"price\":\"&#36;99.00\",\"hash\":\"37bea8d549df279c8278878d081b062f\",\"slug\":\"woocommerce-variation-swatches-and-photos\",\"id\":18697},{\"title\":\"WooCommerce Additional Variation Images\",\"image\":\"\",\"excerpt\":\"Add gallery images per variation on variable products within WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-additional-variation-images\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/storefront\\/product\\/woo-single-1\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c61dd6de57dcecb32bd7358866de4539\",\"slug\":\"woocommerce-additional-variation-images\",\"id\":477384},{\"title\":\"WooCommerce Order Status Control\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/06\\/Thumbnail-Order-Status-Control-2.png\",\"excerpt\":\"Use this extension to automatically change the order status to \\\"completed\\\" after successful payment.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-control\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"32400e509c7c36dcc1cd368e8267d981\",\"slug\":\"woocommerce-order-status-control\",\"id\":439037},{\"title\":\"WooCommerce Deposits\",\"image\":\"\",\"excerpt\":\"Enable customers to pay for products using a deposit or a payment plan.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-deposits\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;179.00\",\"hash\":\"de192a6cf12c4fd803248da5db700762\",\"slug\":\"woocommerce-deposits\",\"id\":977087},{\"title\":\"WooCommerce Blocks\",\"image\":\"\",\"excerpt\":\"WooCommerce Blocks offers a range of Gutenberg blocks you can use to build and customise your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gutenberg-products-block\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c2e9f13a-f90c-4ffe-a8a5-b432399ec263\",\"slug\":\"woo-gutenberg-products-block\",\"id\":3076677},{\"title\":\"Opayo (Formerly SagePay)\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/Opayo_logo_RGB.png\",\"excerpt\":\"Take payments on your WooCommerce store via Opayo (formally SagePay).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sage-pay-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc0cca47d0274d8ef9b164f6fbec1cc\",\"slug\":\"woocommerce-gateway-sagepay-form\",\"id\":18599},{\"title\":\"EU VAT Number\",\"image\":\"\",\"excerpt\":\"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eu-vat-number\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"d2720c4b4bb8d6908e530355b7a2d734\",\"slug\":\"woocommerce-eu-vat-number\",\"id\":18592},{\"title\":\"Amazon S3 Storage\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/amazon.png\",\"excerpt\":\"Serve digital products via Amazon S3\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-s3-storage\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"473bf6f221b865eff165c97881b473bb\",\"slug\":\"woocommerce-amazon-s3-storage\",\"id\":18663},{\"title\":\"QuickBooks Commerce (formerly TradeGecko)\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/09\\/qbo-mark.png\",\"excerpt\":\"Get a wholesale and multichannel inventory &amp; order management platform for your WooCommerce store with QuickBooks Commerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-tradegecko\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"21da7811f7fc1f13ee19daa7415f0ff3\",\"slug\":\"woocommerce-tradegecko\",\"id\":245960},{\"title\":\"TaxJar\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/10\\/taxjar-logotype.png\",\"excerpt\":\"Save hours every month by putting your sales tax on autopilot. Automated, multi-state sales tax calculation, reporting, and filing for your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/taxjar\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"12072d8e-e933-4561-97b1-9db3c7eeed91\",\"slug\":\"taxjar-simplified-taxes-for-woocommerce\",\"id\":514914},{\"title\":\"WooCommerce Tab Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/11\\/Thumbnail-Tab-Manager-2.png\",\"excerpt\":\"Gives you complete control over your product page tabs, create local and global tabs using a visual drag-and-drop interface, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-tab-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"89a9ac74850855cfe772b4b4ee1e31e0\",\"slug\":\"woocommerce-tab-manager\",\"id\":132195},{\"title\":\"Cart Add-ons\",\"image\":\"\",\"excerpt\":\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/cart-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"3a8ef25334396206f5da4cf208adeda3\",\"slug\":\"woocommerce-cart-add-ons\",\"id\":18717},{\"title\":\"Shipping Multiple Addresses\",\"image\":\"\",\"excerpt\":\"Allow your customers to ship individual items in a single order to multiple addresses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping-multiple-addresses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa0eb6f777846d329952d5b891d6f8cc\",\"slug\":\"woocommerce-shipping-multiple-addresses\",\"id\":18741},{\"title\":\"Customer\\/Order\\/Coupon CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/07\\/Thumbnail-Customer-Order-Coupon-CSV-Import-Suite-2.png\",\"excerpt\":\"Import both customers and orders into WooCommerce from a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/customerorder-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb00ca8317a0f64dbe185c995e5ea3df\",\"slug\":\"woocommerce-customer-order-csv-import\",\"id\":18709},{\"title\":\"QuickBooks Sync for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/04\\/woocommerce-com-logo-1-hyhzbh.png\",\"excerpt\":\"Automatic two-way sync for orders, customers, products, inventory and more between WooCommerce and QuickBooks (Online, Desktop, or POS).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/quickbooks-sync-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c5e32e20-7c1f-4585-8b15-d930c2d842ac\",\"slug\":\"myworks-woo-sync-for-quickbooks-online\",\"id\":4065824},{\"title\":\"Coupon Shortcodes\",\"image\":\"\",\"excerpt\":\"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/coupon-shortcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"ac5d9d51-70b2-4d8f-8b89-24200eea1394\",\"slug\":\"woocommerce-coupon-shortcodes\",\"id\":244762},{\"title\":\"Worldpay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/WorldpayLogo2018.png\",\"excerpt\":\"Take payments via Worldpay Business Gateway.\\r\\n\\r\\n&nbsp;\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/worldpay\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc48c9d12dc0c43add4b099665a80b0\",\"slug\":\"woocommerce-gateway-worldpay\",\"id\":18646},{\"title\":\"Groups for WooCommerce\",\"image\":\"\",\"excerpt\":\"Sell Memberships with Groups and WooCommerce \\u2013\\u00a0the best Group Membership and Access Control solution for WordPress and WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/groups-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"aa2d455ed00566e4fb71bc9d53f2613b\",\"slug\":\"groups-woocommerce\",\"id\":18704},{\"title\":\"Per Product Shipping\",\"image\":\"\",\"excerpt\":\"Define separate shipping costs per product which are combined at checkout to provide a total shipping cost.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/per-product-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ba16bebba1d74992efc398d575bf269e\",\"slug\":\"woocommerce-shipping-per-product\",\"id\":18590},{\"title\":\"Jilt\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2017\\/12\\/Thumbnail-Jilt-3-s6qjnb.png\",\"excerpt\":\"All-in-one email marketing platform built for WooCommerce stores. Send newsletters, abandoned cart reminders, win-backs, welcome automations, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jilt\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b53aafb64dca33835e41ee06de7e9816\",\"slug\":\"jilt-for-woocommerce\",\"id\":2754876},{\"title\":\"Royal Mail\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/royalmail.png\",\"excerpt\":\"Offer Royal Mail shipping rates to your customers\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/royal-mail\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"03839cca1a16c4488fcb669aeb91a056\",\"slug\":\"woocommerce-shipping-royalmail\",\"id\":182719},{\"title\":\"Bulk Stock Management\",\"image\":\"\",\"excerpt\":\"Edit product and variation stock levels in bulk via this handy interface\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bulk-stock-management\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"02f4328d52f324ebe06a78eaaae7934f\",\"slug\":\"woocommerce-bulk-stock-management\",\"id\":18670},{\"title\":\"Intuit Payments Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/11\\/Thumbnail-Intuit-Payments-2-im8zes.png\",\"excerpt\":\"Allow customers to securely save multiple payment methods to their account for faster checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/intuit-qbms\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"56ee7c24d725409e3244401ed625b4f3\",\"slug\":\"woocommerce-gateway-intuit-qbms\",\"id\":272221},{\"title\":\"Cost of Goods\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/04\\/Thumbnail-Cost-of-Goods-2.png\",\"excerpt\":\"Easily track profit by including \\u00a0cost of goods in your reports\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-cost-of-goods\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9908a60a5feefec5e33b38359f5f6964\",\"slug\":\"woocommerce-cost-of-goods\",\"id\":185438},{\"title\":\"WooCommerce Email Customizer\",\"image\":\"\",\"excerpt\":\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-email-customizer\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"bd909fa97874d431f203b5336c7e8873\",\"slug\":\"woocommerce-email-customizer\",\"id\":853277},{\"title\":\"WooCommerce Quick View\",\"image\":\"\",\"excerpt\":\"Show a quick-view button to view product details and add to cart via lightbox popup\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-quick-view\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"619c6e57ce72c49c4b57e15b06eddb65\",\"slug\":\"woocommerce-quick-view\",\"id\":187509},{\"title\":\"Force Sells\",\"image\":\"\",\"excerpt\":\"Force products to be added to the cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/force-sells\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"3ebddfc491ca168a4ea4800b893302b0\",\"slug\":\"woocommerce-force-sells\",\"id\":18678},{\"title\":\"Local Pickup Plus\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Local-Pickup-Plus-2.png\",\"excerpt\":\"Let customers pick up products from specific locations, select a pickup date, and more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/local-pickup-plus\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"4d6fbe9e8968a669d11cec40b85a0caa\",\"slug\":\"woocommerce-shipping-local-pickup-plus\",\"id\":18696},{\"title\":\"WooCommerce Purchase Order Gateway\",\"image\":\"\",\"excerpt\":\"Receive purchase orders via your WooCommerce-powered online store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-purchase-order\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"573a92318244ece5facb449d63e74874\",\"slug\":\"woocommerce-gateway-purchase-order\",\"id\":478542},{\"title\":\"WooCommerce Wishlists\",\"image\":\"\",\"excerpt\":\"WooCommerce Wishlists allows guests and customers to create and add products to an unlimited number of Wishlists.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-wishlists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/wishlist-demos\\/\",\"price\":\"&#36;79.00\",\"hash\":\"6bd20993ea96333eab6931ec2adc6d63\",\"slug\":\"woocommerce-wishlists\",\"id\":171144},{\"title\":\"Returns and Warranty Requests\",\"image\":\"\",\"excerpt\":\"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns \\/ exchanges from their account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/warranty-requests\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9b4c41102e6b61ea5f558e16f9b63e25\",\"slug\":\"woocommerce-warranty\",\"id\":228315},{\"title\":\"Elavon Converge Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/07\\/Thumbnail-Elavon-3-ijkwkr.png\",\"excerpt\":\"Take credit card payments with Elavon, the fourth largest merchant acquirer in North America.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/elavon-vm-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"2732aedb77a13149b4db82d484d3bb22\",\"slug\":\"woocommerce-gateway-elavon\",\"id\":18722}]}\";s:3:\"raw\";s:48779:\"HTTP/1.1 200 OK
Server: nginx
Date: Wed, 04 Nov 2020 19:43:49 GMT
Content-Type: application/json; charset=UTF-8
Content-Length: 11432
Connection: close
X-Robots-Tag: noindex
Link: <https://woocommerce.com/wp-json/>; rel=\"https://api.w.org/\"
X-Content-Type-Options: nosniff
Access-Control-Expose-Headers: X-WP-Total, X-WP-TotalPages, Link
Access-Control-Allow-Headers: Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type
Cache-Control: max-age=60
Allow: GET
Content-Encoding: gzip
X-rq: arn1 87 207 3156
Age: 59
X-Cache: hit
Vary: Accept-Encoding, Origin
Accept-Ranges: bytes

{\"products\":[{\"title\":\"WooCommerce Google Analytics\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/GA-Dark.png\",\"excerpt\":\"Understand your customers and increase revenue with world\\u2019s leading analytics platform - integrated with WooCommerce for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2d21f7de14dfb8e9885a4622be701ddf\",\"slug\":\"woocommerce-google-analytics-integration\",\"id\":1442927},{\"title\":\"WooCommerce Tax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Tax-Dark.png\",\"excerpt\":\"Get live rates, discounted labels, tracking numbers, and more \\u2013 without leaving your dashboard.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/tax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":3220291},{\"title\":\"Stripe\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Stripe-Dark-1.png\",\"excerpt\":\"Accept all major debit and credit cards as well as local payment methods with Stripe.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/stripe\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"50bb7a985c691bb943a9da4d2c8b5efd\",\"slug\":\"woocommerce-gateway-stripe\",\"id\":18627},{\"title\":\"Jetpack\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Jetpack-Dark.png\",\"excerpt\":\"Power up and protect your store with Jetpack\\r\\n\\r\\nFor free security, insights and monitoring, connect to Jetpack. It\'s everything you need for a strong, secure start.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jetpack\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"d5bfef9700b62b2b132c74c74c3193eb\",\"slug\":\"jetpack\",\"id\":2725249},{\"title\":\"Facebook for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Facebook-Dark.png\",\"excerpt\":\"Get the Official Facebook for WooCommerce plugin for three powerful ways to help grow your business.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/facebook\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"0ea4fe4c2d7ca6338f8a322fb3e4e187\",\"slug\":\"facebook-for-woocommerce\",\"id\":2127297},{\"title\":\"Amazon Pay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Amazon-Pay-Dark.png\",\"excerpt\":\"Amazon Pay is embedded in your WooCommerce store. Transactions take place via\\u00a0Amazon widgets, so the buyer never leaves your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/pay-with-amazon\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9865e043bbbe4f8c9735af31cb509b53\",\"slug\":\"woocommerce-gateway-amazon-payments-advanced\",\"id\":238816},{\"title\":\"Square for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Square-Dark.png\",\"excerpt\":\"Accepting payments is easy with Square. Clear rates, fast deposits (1-2 business days). Sell online and in person, and sync all payments, items and inventory.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/square\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e907be8b86d7df0c8f8e0d0020b52638\",\"slug\":\"woocommerce-square\",\"id\":1770503},{\"title\":\"WooCommerce Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Dark-1.png\",\"excerpt\":\"Save time and money with WooCommerce Shipping. Print labels right from your WooCommerce dashboard at the lowest USPS rates.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":2165910},{\"title\":\"WooCommerce Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Pay-Dark.png\",\"excerpt\":\"The only payment method designed exclusively for WooCommerce, by WooCommerce. Securely accept major credit and debit cards on your site. View and manage your transactions within your WordPress dashboard.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"8c6319ca-8f41-4e69-be63-6b15ee37773b\",\"slug\":\"woocommerce-payments\",\"id\":5278104},{\"title\":\"ShipStation Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Shipstation-Dark.png\",\"excerpt\":\"Fulfill all your Woo orders (and wherever else you sell) quickly and easily using ShipStation. Try it free for 30 days today!\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipstation-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9de8640767ba64237808ed7f245a49bb\",\"slug\":\"woocommerce-shipstation-integration\",\"id\":18734},{\"title\":\"WooCommerce Subscriptions\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Subscriptions-Dark.png\",\"excerpt\":\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscriptions\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"6115e6d7e297b623a169fdcf5728b224\",\"slug\":\"woocommerce-subscriptions\",\"id\":27147},{\"title\":\"Mailchimp for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/09\\/logo-mailchimp-dark-v2.png\",\"excerpt\":\"Increase traffic, drive repeat purchases, and personalize your marketing when you connect to Mailchimp.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/mailchimp-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b4481616ebece8b1ff68fc59b90c1a91\",\"slug\":\"mailchimp-for-woocommerce\",\"id\":2545166},{\"title\":\"PayPal Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Dark.png\",\"excerpt\":\"PayPal Checkout now with Smart Payment Buttons\\u2122, dynamically displays, PayPal, Venmo, PayPal Credit, or other local payment options in a single stack giving customers the choice to pay with their preferred option.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"69e6cba62ac4021df9e117cc3f716d07\",\"slug\":\"woocommerce-gateway-paypal-express-checkout\",\"id\":1597922},{\"title\":\"PayFast Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Payfast-Dark-1.png\",\"excerpt\":\"Take payments on your WooCommerce store via PayFast (redirect method).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/payfast-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"557bf07293ad916f20c207c6c9cd15ff\",\"slug\":\"woocommerce-payfast-gateway\",\"id\":18596},{\"title\":\"Product Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-Add-Ons-Dark.png\",\"excerpt\":\"Offer add-ons like gift wrapping, special messages or other special options for your products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"147d0077e591e16db9d0d67daeb8c484\",\"slug\":\"woocommerce-product-addons\",\"id\":18618},{\"title\":\"Google Ads &#038; Marketing by Kliken\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/02\\/GA-for-Woo-Logo-374x192px-qu3duk.png\",\"excerpt\":\"Get in front of shoppers and drive traffic to your store so you can grow your business with Smart Shopping Campaigns and free listings.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-ads-and-marketing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"bf66e173-a220-4da7-9512-b5728c20fc16\",\"slug\":\"kliken-marketing-for-google\",\"id\":3866145},{\"title\":\"Braintree for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/02\\/braintree-black-copy.png\",\"excerpt\":\"Accept PayPal, credit cards and debit cards with a single payment gateway solution \\u2014 PayPal Powered by Braintree.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-powered-by-braintree\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"27f010c8e34ca65b205ddec88ad14536\",\"slug\":\"woocommerce-gateway-paypal-powered-by-braintree\",\"id\":1489837},{\"title\":\"WooCommerce Memberships\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/06\\/Thumbnail-Memberships-2.png\",\"excerpt\":\"Give members access to restricted content or products, for a fee or for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-memberships\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"9288e7609ad0b487b81ef6232efa5cfc\",\"slug\":\"woocommerce-memberships\",\"id\":958589},{\"title\":\"USPS Shipping Method\",\"image\":\"\",\"excerpt\":\"Get shipping rates from the USPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/usps-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"83d1524e8f5f1913e58889f83d442c32\",\"slug\":\"woocommerce-shipping-usps\",\"id\":18657},{\"title\":\"Product Bundles\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-PB.png?v=1\",\"excerpt\":\"Offer personalized product bundles, bulk discount packages and assembled\\u00a0products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-bundles\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa2518b5-ab19-4b75-bde9-60ca51e20f28\",\"slug\":\"woocommerce-product-bundles\",\"id\":18716},{\"title\":\"UPS Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/UPS-Shipping-Method-Dark.png\",\"excerpt\":\"Get shipping rates from the UPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ups-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8dae58502913bac0fbcdcaba515ea998\",\"slug\":\"woocommerce-shipping-ups\",\"id\":18665},{\"title\":\"Table Rate Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Product-Table-Rate-Shipping-Dark.png\",\"excerpt\":\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/table-rate-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"3034ed8aff427b0f635fe4c86bbf008a\",\"slug\":\"woocommerce-table-rate-shipping\",\"id\":18718},{\"title\":\"Checkout Field Editor\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Checkout-Field-Editor-Dark.png\",\"excerpt\":\"Optimize your checkout process by adding, removing or editing fields to suit your needs.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-field-editor\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"2b8029f0d7cdd1118f4d843eb3ab43ff\",\"slug\":\"woocommerce-checkout-field-editor\",\"id\":184594},{\"title\":\"Shipment Tracking\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Tracking-Dark-1.png\",\"excerpt\":\"Add shipment tracking information to your orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipment-tracking\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"1968e199038a8a001c9f9966fd06bf88\",\"slug\":\"woocommerce-shipment-tracking\",\"id\":18693},{\"title\":\"Authorize.Net\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/Thumbnail-Authorize.Net-3-cdclct.png\",\"excerpt\":\"Authorize.Net gateway with support for pre-orders and subscriptions.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/authorize-net\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8b61524fe53add7fdd1a8d1b00b9327d\",\"slug\":\"woocommerce-gateway-authorize-net-cim\",\"id\":178481},{\"title\":\"WooCommerce Customer \\/ Order \\/ Coupon Export\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-Customer-Order-Coupon-Export-2.png\",\"excerpt\":\"Export customers, orders, and coupons from WooCommerce manually or on an automated schedule.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ordercustomer-csv-export\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"914de15813a903c767b55445608bf290\",\"slug\":\"woocommerce-customer-order-csv-export\",\"id\":18652},{\"title\":\"WooCommerce Bookings\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Dark.png\",\"excerpt\":\"Allow customers to book appointments, make reservations or rent equipment without leaving your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/hotel\\/\",\"price\":\"&#36;249.00\",\"hash\":\"911c438934af094c2b38d5560b9f50f3\",\"slug\":\"WooCommerce Bookings\",\"id\":390890},{\"title\":\"Amazon and eBay Integration for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/10\\/wooapplogoretina.png\",\"excerpt\":\"Sell on Amazon and eBay directly from your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-ebay-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e4000666-9275-4c71-8619-be61fb41c9f9\",\"slug\":\"woocommerce-amazon-ebay-integration\",\"id\":3545890},{\"title\":\"LiveChat for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2015\\/11\\/LC_woo_regular-zmiaym.png\",\"excerpt\":\"Live Chat and messaging platform for sales and support -- increase average order value and overall sales through live conversations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/livechat\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.livechat.com\\/livechat-for-ecommerce\\/?a=woocommerce&amp;utm_source=woocommerce.com&amp;utm_medium=integration&amp;utm_campaign=woocommerce.com\",\"price\":\"&#36;0.00\",\"hash\":\"5344cc1f-ed4a-4d00-beff-9d67f6d372f3\",\"slug\":\"livechat-woocommerce\",\"id\":1348888},{\"title\":\"Smart Coupons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/10\\/wc-product-smart-coupons.png\",\"excerpt\":\"Everything you need for discounts, coupons, credits, gift cards, product giveaways, offers, and promotions. Most popular and complete coupons plugin for WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/smart-coupons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demo.storeapps.org\\/?demo=sc\",\"price\":\"&#36;99.00\",\"hash\":\"05c45f2aa466106a466de4402fff9dde\",\"slug\":\"woocommerce-smart-coupons\",\"id\":18729},{\"title\":\"Dynamic Pricing\",\"image\":\"\",\"excerpt\":\"Bulk discounts, role-based pricing and much more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/dynamic-pricing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"9a41775bb33843f52c93c922b0053986\",\"slug\":\"woocommerce-dynamic-pricing\",\"id\":18643},{\"title\":\"Min\\/Max Quantities\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Min-Max-Qua-Dark.png\",\"excerpt\":\"Specify minimum and maximum allowed product quantities for orders to be completed.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/minmax-quantities\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"2b5188d90baecfb781a5aa2d6abb900a\",\"slug\":\"woocommerce-min-max-quantities\",\"id\":18616},{\"title\":\"WooCommerce Print Invoices &amp; Packing lists\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/03\\/Thumbnail-Print-Invoices-Packing-lists-2.png\",\"excerpt\":\"Generate invoices, packing slips, and pick lists for your WooCommerce orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/print-invoices-packing-lists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"465de1126817cdfb42d97ebca7eea717\",\"slug\":\"woocommerce-pip\",\"id\":18666},{\"title\":\"Name Your Price\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/09\\/nyp-icon-dark-v83owf.png\",\"excerpt\":\"Allow customers to define the product price. Also useful for accepting user-set donations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/name-your-price\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"31b4e11696cd99a3c0572975a84f1c08\",\"slug\":\"woocommerce-name-your-price\",\"id\":18738},{\"title\":\"FedEx Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/01\\/FedEx_Logo_Wallpaper.jpeg\",\"excerpt\":\"Get shipping rates from the FedEx API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/fedex-shipping-module\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1a48b598b47a81559baadef15e320f64\",\"slug\":\"woocommerce-shipping-fedex\",\"id\":18620},{\"title\":\"WooCommerce Zapier\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/woocommerce-zapier-logo.png\",\"excerpt\":\"Integrate with 2000+ cloud apps and services today.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-zapier\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;59.00\",\"hash\":\"0782bdbe932c00f4978850268c6cfe40\",\"slug\":\"woocommerce-zapier\",\"id\":243589},{\"title\":\"Product CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-CSV-Import-Dark.png\",\"excerpt\":\"Import, merge, and export products and variations to and from WooCommerce using a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"7ac9b00a1fe980fb61d28ab54d167d0d\",\"slug\":\"woocommerce-product-csv-import-suite\",\"id\":18680},{\"title\":\"Follow-Ups\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Follow-Ups-Dark.png\",\"excerpt\":\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/follow-up-emails\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"05ece68fe94558e65278fe54d9ec84d2\",\"slug\":\"woocommerce-follow-up-emails\",\"id\":18686},{\"title\":\"PayPal Payments Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Payments-Pro-Dark.png\",\"excerpt\":\"Take credit card payments directly on your checkout using PayPal Pro.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/paypal-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6d23ba7f0e0198937c0029f9e865b40e\",\"slug\":\"woocommerce-gateway-paypal-pro\",\"id\":18594},{\"title\":\"Google Product Feed\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2011\\/11\\/logo-regular-lscryp.png\",\"excerpt\":\"Allows you to create real-time product &amp; review feeds to supply product information to Google Merchant Center for setting up Google Product Ads. Also supports Bing Merchant Centre.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-product-feed\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d55b4f852872025741312839f142447e\",\"slug\":\"woocommerce-product-feeds\",\"id\":18619},{\"title\":\"Gravity Forms Product Add-ons\",\"image\":\"\",\"excerpt\":\"Powerful product add-ons, Gravity style\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/gravity-forms-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/gravity-forms\\/\",\"price\":\"&#36;99.00\",\"hash\":\"a6ac0ab1a1536e3a357ccf24c0650ed0\",\"slug\":\"woocommerce-gravityforms-product-addons\",\"id\":18633},{\"title\":\"Composite Products\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CP.png?v=1\",\"excerpt\":\"Create product kit builders and custom product configurators using existing products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/composite-products\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"0343e0115bbcb97ccd98442b8326a0af\",\"slug\":\"woocommerce-composite-products\",\"id\":216836},{\"title\":\"Product Vendors\",\"image\":\"\",\"excerpt\":\"Turn your store into a multi-vendor marketplace\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-vendors\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"a97d99fccd651bbdd728f4d67d492c31\",\"slug\":\"woocommerce-product-vendors\",\"id\":219982},{\"title\":\"WooCommerce Paid Courses\",\"image\":\"\",\"excerpt\":\"Sell your online courses using the most popular eCommerce platform on the web \\u2013 WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paid-courses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"bad2a02a063555b7e2bee59924690763\",\"slug\":\"woothemes-sensei\",\"id\":152116},{\"title\":\"WooCommerce AvaTax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2016\\/01\\/Thumbnail-Avalara-3-vfulwb.png\",\"excerpt\":\"Get 100% accurate sales tax calculations and on time tax return filing. No more tracking sales tax rates, rules, or jurisdictional boundaries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-avatax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"57077a4b28ba71cacf692bcf4a1a7f60\",\"slug\":\"woocommerce-avatax\",\"id\":1389326},{\"title\":\"WooCommerce Accommodation Bookings\",\"image\":\"\",\"excerpt\":\"Book accommodation using WooCommerce and the WooCommerce Bookings extension.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-accommodation-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"99b2a7a4af90b6cefd2a733b3b1f78e7\",\"slug\":\"woocommerce-accommodation-bookings\",\"id\":1412069},{\"title\":\"WooCommerce Brands\",\"image\":\"\",\"excerpt\":\"Create, assign and list brands for products, and allow customers to view by brand.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/brands\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"8a88c7cbd2f1e73636c331c7a86f818c\",\"slug\":\"woocommerce-brands\",\"id\":18737},{\"title\":\"Xero\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/08\\/xero2.png\",\"excerpt\":\"Save time with automated sync between WooCommerce and your Xero account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/xero\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"f0dd29d338d3c67cf6cee88eddf6869b\",\"slug\":\"woocommerce-xero\",\"id\":18733},{\"title\":\"Catalog Visibility Options\",\"image\":\"\",\"excerpt\":\"Transform WooCommerce into an online catalog by removing eCommerce functionality\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/catalog-visibility-options\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"12e791110365fdbb5865c8658907967e\",\"slug\":\"woocommerce-catalog-visibility-options\",\"id\":18648},{\"title\":\"Klarna Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/01\\/Partner_marketing_Klarna_Checkout_Black-1.png\",\"excerpt\":\"Klarna Checkout is a full checkout experience embedded on your site with Pay Now, Pay Later and Slice It. No credit card numbers, no passwords, no worries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/klarna-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.krokedil.se\\/klarnacheckout\\/\",\"price\":\"&#36;0.00\",\"hash\":\"90f8ce584e785fcd8c2d739fd4f40d78\",\"slug\":\"klarna-checkout-for-woocommerce\",\"id\":2754152},{\"title\":\"Advanced Notifications\",\"image\":\"\",\"excerpt\":\"Easily setup \\\"new order\\\" and stock email notifications for multiple recipients of your choosing.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/advanced-notifications\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"112372c44b002fea2640bd6bfafbca27\",\"slug\":\"woocommerce-advanced-notifications\",\"id\":18740},{\"title\":\"eWAY\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/eway-logo-3000-2000.jpg\",\"excerpt\":\"Take credit card payments securely via eWay (SG, MY, HK, AU, and NZ) keeping customers on your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2c497769d98d025e0d340cd0b5ea5da1\",\"slug\":\"woocommerce-gateway-eway\",\"id\":18604},{\"title\":\"WooCommerce Points and Rewards\",\"image\":\"\",\"excerpt\":\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-points-and-rewards\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"1649b6cca5da8b923b01ca56b5cdd246\",\"slug\":\"woocommerce-points-and-rewards\",\"id\":210259},{\"title\":\"Sequential Order Numbers Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Sequential-Order-Numbers-Pro-2.png\",\"excerpt\":\"Tame your order numbers! Advanced &amp; sequential order numbers with optional prefixes \\/ suffixes\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sequential-order-numbers-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"0b18a2816e016ba9988b93b1cd8fe766\",\"slug\":\"woocommerce-sequential-order-numbers-pro\",\"id\":18688},{\"title\":\"WooCommerce Checkout Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/07\\/Thumbnail-Checkout-Add-Ons-2.png\",\"excerpt\":\"Highlight relevant products, offers like free shipping and other up-sells during checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8fdca00b4000b7a8cc26371d0e470a8f\",\"slug\":\"woocommerce-checkout-add-ons\",\"id\":466854},{\"title\":\"WooCommerce Subscription Downloads\",\"image\":\"\",\"excerpt\":\"Offer additional downloads to your subscribers, via downloadable products listed in your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscription-downloads\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5be9e21c13953253e4406d2a700382ec\",\"slug\":\"woocommerce-subscription-downloads\",\"id\":420458},{\"title\":\"AutomateWoo\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-AutomateWoo-Dark-1.png\",\"excerpt\":\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/automatewoo\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"ba9299b8-1dba-4aa0-a313-28bc1755cb88\",\"slug\":\"automatewoo\",\"id\":4652610},{\"title\":\"Australia Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/australia-post.gif\",\"excerpt\":\"Get shipping rates for your WooCommerce store from the Australia Post API, which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/australia-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1dbd4dc6bd91a9cda1bd6b9e7a5e4f43\",\"slug\":\"woocommerce-shipping-australia-post\",\"id\":18622},{\"title\":\"WooCommerce Pre-Orders\",\"image\":\"\",\"excerpt\":\"Allow customers to order products before they are available.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-pre-orders\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"b2dc75e7d55e6f5bbfaccb59830f66b7\",\"slug\":\"woocommerce-pre-orders\",\"id\":178477},{\"title\":\"WooCommerce Google Analytics Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2016\\/01\\/Thumbnail-GAPro-3-b3imif.png\",\"excerpt\":\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d8aed8b7306b509eec1589e59abe319f\",\"slug\":\"woocommerce-google-analytics-pro\",\"id\":1312497},{\"title\":\"First Data\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/02\\/Thumbnail-FirstData-3-c5ssqi.png\",\"excerpt\":\"FirstData gateway for WooCommerce\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/firstdata\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb3e32663ec0810592eaf0d097796230\",\"slug\":\"woocommerce-gateway-firstdata\",\"id\":18645},{\"title\":\"Conditional Shipping and Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CSP.png?v=1\",\"excerpt\":\"Use conditional logic to restrict the shipping and payment options available on your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/conditional-shipping-and-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1f56ff002fa830b77017b0107505211a\",\"slug\":\"woocommerce-conditional-shipping-and-payments\",\"id\":680253},{\"title\":\"Canada Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/canada-post.png\",\"excerpt\":\"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/canada-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ac029cdf3daba20b20c7b9be7dc00e0e\",\"slug\":\"woocommerce-shipping-canada-post\",\"id\":18623},{\"title\":\"WooSlider\",\"image\":\"\",\"excerpt\":\"WooSlider is the ultimate responsive slideshow WordPress slider plugin\\r\\n\\r\\n\\u00a0\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/wooslider\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/www.wooslider.com\\/\",\"price\":\"&#36;49.00\",\"hash\":\"209d98f3ccde6cc3de7e8732a2b20b6a\",\"slug\":\"wooslider\",\"id\":46506},{\"title\":\"WooCommerce Order Status Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/02\\/Thumbnail-Order-Status-Manager-2.png\",\"excerpt\":\"Create, edit, and delete completely custom order statuses and integrate them seamlessly into your order management flow.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"51fd9ab45394b4cad5a0ebf58d012342\",\"slug\":\"woocommerce-order-status-manager\",\"id\":588398},{\"title\":\"WooCommerce One Page Checkout\",\"image\":\"\",\"excerpt\":\"Create special pages where customers can choose products, checkout &amp; pay all on the one page.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-one-page-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"c9ba8f8352cd71b5508af5161268619a\",\"slug\":\"woocommerce-one-page-checkout\",\"id\":527886},{\"title\":\"WooCommerce Social Login\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/08\\/Thumbnail-Social-Login-2.png\",\"excerpt\":\"Enable Social Login for seamless checkout and account creation.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-social-login\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demos.skyverge.com\\/woocommerce-social-login\\/\",\"price\":\"&#36;79.00\",\"hash\":\"b231cd6367a79cc8a53b7d992d77525d\",\"slug\":\"woocommerce-social-login\",\"id\":473617},{\"title\":\"WooCommerce Product Search\",\"image\":\"\",\"excerpt\":\"The perfect search engine helps customers to find and buy products quickly \\u2013 essential for every WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-product-search\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.itthinx.com\\/wps\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c84cc8ca16ddac3408e6b6c5871133a8\",\"slug\":\"woocommerce-product-search\",\"id\":512174},{\"title\":\"Variation Swatches and Photos\",\"image\":\"\",\"excerpt\":\"Show color and image swatches instead of dropdowns for variable products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/variation-swatches-and-photos\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/swatches-and-photos\\/\",\"price\":\"&#36;99.00\",\"hash\":\"37bea8d549df279c8278878d081b062f\",\"slug\":\"woocommerce-variation-swatches-and-photos\",\"id\":18697},{\"title\":\"WooCommerce Additional Variation Images\",\"image\":\"\",\"excerpt\":\"Add gallery images per variation on variable products within WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-additional-variation-images\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/storefront\\/product\\/woo-single-1\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c61dd6de57dcecb32bd7358866de4539\",\"slug\":\"woocommerce-additional-variation-images\",\"id\":477384},{\"title\":\"WooCommerce Order Status Control\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/06\\/Thumbnail-Order-Status-Control-2.png\",\"excerpt\":\"Use this extension to automatically change the order status to \\\"completed\\\" after successful payment.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-control\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"32400e509c7c36dcc1cd368e8267d981\",\"slug\":\"woocommerce-order-status-control\",\"id\":439037},{\"title\":\"WooCommerce Deposits\",\"image\":\"\",\"excerpt\":\"Enable customers to pay for products using a deposit or a payment plan.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-deposits\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;179.00\",\"hash\":\"de192a6cf12c4fd803248da5db700762\",\"slug\":\"woocommerce-deposits\",\"id\":977087},{\"title\":\"WooCommerce Blocks\",\"image\":\"\",\"excerpt\":\"WooCommerce Blocks offers a range of Gutenberg blocks you can use to build and customise your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gutenberg-products-block\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c2e9f13a-f90c-4ffe-a8a5-b432399ec263\",\"slug\":\"woo-gutenberg-products-block\",\"id\":3076677},{\"title\":\"Opayo (Formerly SagePay)\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/Opayo_logo_RGB.png\",\"excerpt\":\"Take payments on your WooCommerce store via Opayo (formally SagePay).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sage-pay-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc0cca47d0274d8ef9b164f6fbec1cc\",\"slug\":\"woocommerce-gateway-sagepay-form\",\"id\":18599},{\"title\":\"EU VAT Number\",\"image\":\"\",\"excerpt\":\"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eu-vat-number\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"d2720c4b4bb8d6908e530355b7a2d734\",\"slug\":\"woocommerce-eu-vat-number\",\"id\":18592},{\"title\":\"Amazon S3 Storage\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/amazon.png\",\"excerpt\":\"Serve digital products via Amazon S3\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-s3-storage\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"473bf6f221b865eff165c97881b473bb\",\"slug\":\"woocommerce-amazon-s3-storage\",\"id\":18663},{\"title\":\"QuickBooks Commerce (formerly TradeGecko)\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/09\\/qbo-mark.png\",\"excerpt\":\"Get a wholesale and multichannel inventory &amp; order management platform for your WooCommerce store with QuickBooks Commerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-tradegecko\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"21da7811f7fc1f13ee19daa7415f0ff3\",\"slug\":\"woocommerce-tradegecko\",\"id\":245960},{\"title\":\"TaxJar\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/10\\/taxjar-logotype.png\",\"excerpt\":\"Save hours every month by putting your sales tax on autopilot. Automated, multi-state sales tax calculation, reporting, and filing for your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/taxjar\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"12072d8e-e933-4561-97b1-9db3c7eeed91\",\"slug\":\"taxjar-simplified-taxes-for-woocommerce\",\"id\":514914},{\"title\":\"WooCommerce Tab Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/11\\/Thumbnail-Tab-Manager-2.png\",\"excerpt\":\"Gives you complete control over your product page tabs, create local and global tabs using a visual drag-and-drop interface, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-tab-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"89a9ac74850855cfe772b4b4ee1e31e0\",\"slug\":\"woocommerce-tab-manager\",\"id\":132195},{\"title\":\"Cart Add-ons\",\"image\":\"\",\"excerpt\":\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/cart-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"3a8ef25334396206f5da4cf208adeda3\",\"slug\":\"woocommerce-cart-add-ons\",\"id\":18717},{\"title\":\"Shipping Multiple Addresses\",\"image\":\"\",\"excerpt\":\"Allow your customers to ship individual items in a single order to multiple addresses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping-multiple-addresses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa0eb6f777846d329952d5b891d6f8cc\",\"slug\":\"woocommerce-shipping-multiple-addresses\",\"id\":18741},{\"title\":\"Customer\\/Order\\/Coupon CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/07\\/Thumbnail-Customer-Order-Coupon-CSV-Import-Suite-2.png\",\"excerpt\":\"Import both customers and orders into WooCommerce from a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/customerorder-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb00ca8317a0f64dbe185c995e5ea3df\",\"slug\":\"woocommerce-customer-order-csv-import\",\"id\":18709},{\"title\":\"QuickBooks Sync for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/04\\/woocommerce-com-logo-1-hyhzbh.png\",\"excerpt\":\"Automatic two-way sync for orders, customers, products, inventory and more between WooCommerce and QuickBooks (Online, Desktop, or POS).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/quickbooks-sync-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c5e32e20-7c1f-4585-8b15-d930c2d842ac\",\"slug\":\"myworks-woo-sync-for-quickbooks-online\",\"id\":4065824},{\"title\":\"Coupon Shortcodes\",\"image\":\"\",\"excerpt\":\"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/coupon-shortcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"ac5d9d51-70b2-4d8f-8b89-24200eea1394\",\"slug\":\"woocommerce-coupon-shortcodes\",\"id\":244762},{\"title\":\"Worldpay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/WorldpayLogo2018.png\",\"excerpt\":\"Take payments via Worldpay Business Gateway.\\r\\n\\r\\n&nbsp;\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/worldpay\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc48c9d12dc0c43add4b099665a80b0\",\"slug\":\"woocommerce-gateway-worldpay\",\"id\":18646},{\"title\":\"Groups for WooCommerce\",\"image\":\"\",\"excerpt\":\"Sell Memberships with Groups and WooCommerce \\u2013\\u00a0the best Group Membership and Access Control solution for WordPress and WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/groups-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"aa2d455ed00566e4fb71bc9d53f2613b\",\"slug\":\"groups-woocommerce\",\"id\":18704},{\"title\":\"Per Product Shipping\",\"image\":\"\",\"excerpt\":\"Define separate shipping costs per product which are combined at checkout to provide a total shipping cost.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/per-product-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ba16bebba1d74992efc398d575bf269e\",\"slug\":\"woocommerce-shipping-per-product\",\"id\":18590},{\"title\":\"Jilt\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2017\\/12\\/Thumbnail-Jilt-3-s6qjnb.png\",\"excerpt\":\"All-in-one email marketing platform built for WooCommerce stores. Send newsletters, abandoned cart reminders, win-backs, welcome automations, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jilt\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b53aafb64dca33835e41ee06de7e9816\",\"slug\":\"jilt-for-woocommerce\",\"id\":2754876},{\"title\":\"Royal Mail\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/royalmail.png\",\"excerpt\":\"Offer Royal Mail shipping rates to your customers\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/royal-mail\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"03839cca1a16c4488fcb669aeb91a056\",\"slug\":\"woocommerce-shipping-royalmail\",\"id\":182719},{\"title\":\"Bulk Stock Management\",\"image\":\"\",\"excerpt\":\"Edit product and variation stock levels in bulk via this handy interface\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bulk-stock-management\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"02f4328d52f324ebe06a78eaaae7934f\",\"slug\":\"woocommerce-bulk-stock-management\",\"id\":18670},{\"title\":\"Intuit Payments Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/11\\/Thumbnail-Intuit-Payments-2-im8zes.png\",\"excerpt\":\"Allow customers to securely save multiple payment methods to their account for faster checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/intuit-qbms\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"56ee7c24d725409e3244401ed625b4f3\",\"slug\":\"woocommerce-gateway-intuit-qbms\",\"id\":272221},{\"title\":\"Cost of Goods\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/04\\/Thumbnail-Cost-of-Goods-2.png\",\"excerpt\":\"Easily track profit by including \\u00a0cost of goods in your reports\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-cost-of-goods\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9908a60a5feefec5e33b38359f5f6964\",\"slug\":\"woocommerce-cost-of-goods\",\"id\":185438},{\"title\":\"WooCommerce Email Customizer\",\"image\":\"\",\"excerpt\":\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-email-customizer\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"bd909fa97874d431f203b5336c7e8873\",\"slug\":\"woocommerce-email-customizer\",\"id\":853277},{\"title\":\"WooCommerce Quick View\",\"image\":\"\",\"excerpt\":\"Show a quick-view button to view product details and add to cart via lightbox popup\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-quick-view\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"619c6e57ce72c49c4b57e15b06eddb65\",\"slug\":\"woocommerce-quick-view\",\"id\":187509},{\"title\":\"Force Sells\",\"image\":\"\",\"excerpt\":\"Force products to be added to the cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/force-sells\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"3ebddfc491ca168a4ea4800b893302b0\",\"slug\":\"woocommerce-force-sells\",\"id\":18678},{\"title\":\"Local Pickup Plus\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Local-Pickup-Plus-2.png\",\"excerpt\":\"Let customers pick up products from specific locations, select a pickup date, and more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/local-pickup-plus\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"4d6fbe9e8968a669d11cec40b85a0caa\",\"slug\":\"woocommerce-shipping-local-pickup-plus\",\"id\":18696},{\"title\":\"WooCommerce Purchase Order Gateway\",\"image\":\"\",\"excerpt\":\"Receive purchase orders via your WooCommerce-powered online store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-purchase-order\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"573a92318244ece5facb449d63e74874\",\"slug\":\"woocommerce-gateway-purchase-order\",\"id\":478542},{\"title\":\"WooCommerce Wishlists\",\"image\":\"\",\"excerpt\":\"WooCommerce Wishlists allows guests and customers to create and add products to an unlimited number of Wishlists.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-wishlists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/wishlist-demos\\/\",\"price\":\"&#36;79.00\",\"hash\":\"6bd20993ea96333eab6931ec2adc6d63\",\"slug\":\"woocommerce-wishlists\",\"id\":171144},{\"title\":\"Returns and Warranty Requests\",\"image\":\"\",\"excerpt\":\"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns \\/ exchanges from their account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/warranty-requests\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9b4c41102e6b61ea5f558e16f9b63e25\",\"slug\":\"woocommerce-warranty\",\"id\":228315},{\"title\":\"Elavon Converge Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/07\\/Thumbnail-Elavon-3-ijkwkr.png\",\"excerpt\":\"Take credit card payments with Elavon, the fourth largest merchant acquirer in North America.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/elavon-vm-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"2732aedb77a13149b4db82d484d3bb22\",\"slug\":\"woocommerce-gateway-elavon\",\"id\":18722}]}\";s:7:\"headers\";O:25:\"Requests_Response_Headers\":1:{s:7:\"\0*\0data\";a:17:{s:6:\"server\";a:1:{i:0;s:5:\"nginx\";}s:4:\"date\";a:1:{i:0;s:29:\"Wed, 04 Nov 2020 19:43:49 GMT\";}s:12:\"content-type\";a:1:{i:0;s:31:\"application/json; charset=UTF-8\";}s:14:\"content-length\";a:1:{i:0;s:5:\"11432\";}s:12:\"x-robots-tag\";a:1:{i:0;s:7:\"noindex\";}s:4:\"link\";a:1:{i:0;s:60:\"<https://woocommerce.com/wp-json/>; rel=\"https://api.w.org/\"\";}s:22:\"x-content-type-options\";a:1:{i:0;s:7:\"nosniff\";}s:29:\"access-control-expose-headers\";a:1:{i:0;s:33:\"X-WP-Total, X-WP-TotalPages, Link\";}s:28:\"access-control-allow-headers\";a:1:{i:0;s:73:\"Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type\";}s:13:\"cache-control\";a:1:{i:0;s:10:\"max-age=60\";}s:5:\"allow\";a:1:{i:0;s:3:\"GET\";}s:16:\"content-encoding\";a:1:{i:0;s:4:\"gzip\";}s:4:\"x-rq\";a:1:{i:0;s:16:\"arn1 87 207 3156\";}s:3:\"age\";a:1:{i:0;s:2:\"59\";}s:7:\"x-cache\";a:1:{i:0;s:3:\"hit\";}s:4:\"vary\";a:1:{i:0;s:23:\"Accept-Encoding, Origin\";}s:13:\"accept-ranges\";a:1:{i:0;s:5:\"bytes\";}}}s:11:\"status_code\";i:200;s:16:\"protocol_version\";d:1.1;s:7:\"success\";b:1;s:9:\"redirects\";i:0;s:3:\"url\";s:59:\"https://woocommerce.com/wp-json/wccom-extensions/1.0/search\";s:7:\"history\";a:0:{}s:7:\"cookies\";O:19:\"Requests_Cookie_Jar\":1:{s:10:\"\0*\0cookies\";a:0:{}}}s:11:\"\0*\0filename\";N;s:4:\"data\";N;s:7:\"headers\";N;s:6:\"status\";N;}}","no");
INSERT INTO `wp_options` VALUES("349","_transient_woocommerce_reports-transient-version","1604519030","yes");
INSERT INTO `wp_options` VALUES("350","_transient_timeout_orders-all-statuses","1605123830","no");
INSERT INTO `wp_options` VALUES("351","_transient_orders-all-statuses","a:2:{s:7:\"version\";s:10:\"1604519030\";s:5:\"value\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("352","_transient_timeout_woocommerce_admin_low_out_of_stock_count","1604522630","no");
INSERT INTO `wp_options` VALUES("353","_transient_woocommerce_admin_low_out_of_stock_count","0","no");
INSERT INTO `wp_options` VALUES("354","_transient_timeout_wc_onboarding_themes","1604605432","no");
INSERT INTO `wp_options` VALUES("355","_transient_wc_onboarding_themes","a:26:{s:12:\"twentytwenty\";a:6:{s:4:\"slug\";s:12:\"twentytwenty\";s:5:\"title\";s:13:\"Twenty Twenty\";s:5:\"price\";s:4:\"0.00\";s:12:\"is_installed\";b:1;s:5:\"image\";s:62:\"http://mozar.loc/wp-content/themes/twentytwenty/screenshot.png\";s:23:\"has_woocommerce_support\";b:1;}s:10:\"storefront\";a:11:{s:5:\"title\";s:10:\"Storefront\";s:5:\"image\";s:77:\"https://woocommerce.com/wp-content/themes/woo/images/storefront/feature-1.jpg\";s:7:\"excerpt\";s:161:\"Storefront is an intuitive &amp; flexible, free theme offering deep integration with WooCommerce.

It\'s the perfect platform for your next WooCommerce project.\";s:4:\"link\";s:103:\"https://woocommerce.com/products/storefront/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:42:\"https://themes.woocommerce.com/storefront/\";s:5:\"price\";s:9:\"&#36;0.00\";s:4:\"hash\";s:32:\"5714dad8f8d0b930bd6cc9c99657b930\";s:4:\"slug\";s:10:\"storefront\";s:2:\"id\";i:565154;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"agency\";a:11:{s:5:\"title\";s:6:\"Agency\";s:5:\"image\";s:65:\"https://woocommerce.com/wp-content/uploads/2020/10/logo.png?w=600\";s:7:\"excerpt\";s:134:\"Agency is a Gutenberg and WooCommerce optimized WordPress theme for marketing, advertising, and creative agencies. Sell your services!\";s:4:\"link\";s:99:\"https://woocommerce.com/products/agency/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:0:\"\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"4a3a3a22-a5f0-4fa4-8c09-4f37575602ef\";s:4:\"slug\";s:6:\"agency\";s:2:\"id\";i:6674855;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"rhodes\";a:11:{s:5:\"title\";s:6:\"Rhodes\";s:5:\"image\";s:66:\"https://woocommerce.com/wp-content/uploads/2020/09/rhodes-home.jpg\";s:7:\"excerpt\";s:193:\"The perfect WooCommerce theme for retailers. Whether you\'re selling high-street fashion, beauty products, or home accessories, Rhodes will just stand out of the way letting your products shine.\";s:4:\"link\";s:99:\"https://woocommerce.com/products/rhodes/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:34:\"https://www.cssigniter.com/rhodes/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"b95c0103-23b9-43f3-af49-ee7eaa35e49b\";s:4:\"slug\";s:6:\"rhodes\";s:2:\"id\";i:6509339;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:11:\"restoration\";a:11:{s:5:\"title\";s:11:\"Restoration\";s:5:\"image\";s:78:\"https://woocommerce.com/wp-content/uploads/2020/09/restoration-woocommerce.jpg\";s:7:\"excerpt\";s:90:\"An elegant and sophisticated mobile-first, Gutenberg-powered theme for WooCommerce stores.\";s:4:\"link\";s:104:\"https://woocommerce.com/products/restoration/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:35:\"https://restoration.fuelthemes.net/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"e793e6af-f338-4e92-b268-e0576ddb137b\";s:4:\"slug\";s:11:\"restoration\";s:2:\"id\";i:6454820;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"matthew\";a:11:{s:5:\"title\";s:7:\"Matthew\";s:5:\"image\";s:71:\"https://woocommerce.com/wp-content/uploads/2020/06/screenshot.png?w=620\";s:7:\"excerpt\";s:145:\"Matthew is a Gutenberg-powered WooCommerce theme designed for building a professional online store so that you can sell goods or services online.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/matthew/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:38:\"https://demo.themesharbor.com/matthew/\";s:5:\"price\";s:11:\"&#36;129.00\";s:4:\"hash\";s:36:\"b3983408-c4f6-4751-8bd7-ae65ae34cf3b\";s:4:\"slug\";s:7:\"matthew\";s:2:\"id\";i:6214538;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:11:\"fifthavenue\";a:11:{s:5:\"title\";s:12:\"Fifth Avenue\";s:5:\"image\";s:78:\"https://woocommerce.com/wp-content/uploads/2020/06/fifthavenue-woocommerce.jpg\";s:7:\"excerpt\";s:103:\"Beautiful Gutenberg powered WooCommerce theme designed to be easily customized for all types of stores.\";s:4:\"link\";s:105:\"https://woocommerce.com/products/fifth-avenue/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:35:\"https://fifthavenue.fuelthemes.net/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"9e093a9f-3d49-4fcd-bec7-c87b097d9df8\";s:4:\"slug\";s:11:\"fifthavenue\";s:2:\"id\";i:5989481;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"artisan\";a:11:{s:5:\"title\";s:7:\"Artisan\";s:5:\"image\";s:67:\"https://woocommerce.com/wp-content/uploads/2020/03/artisan-home.jpg\";s:7:\"excerpt\";s:79:\"Sell your hand-crafted products online using the Artisan Theme for WooCommerce.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/artisan/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://organicthemes.com/demo/artisan/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"64529812-81f6-4efd-9686-ecb34e527421\";s:4:\"slug\";s:7:\"artisan\";s:2:\"id\";i:5576887;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"threads\";a:11:{s:5:\"title\";s:7:\"Threads\";s:5:\"image\";s:67:\"https://woocommerce.com/wp-content/uploads/2019/07/threads-home.jpg\";s:7:\"excerpt\";s:79:\"Create a stunning website for your apparel brand using Threads for WooCommerce.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/threads/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://organicthemes.com/demo/threads/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"7ca579a6-6aaf-498c-9ee7-e15280ace9e9\";s:4:\"slug\";s:7:\"threads\";s:2:\"id\";i:4663191;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:10:\"block-shop\";a:11:{s:5:\"title\";s:10:\"Block Shop\";s:5:\"image\";s:79:\"https://woocommerce.com/wp-content/uploads/2019/08/block-shop-theme-preview.jpg\";s:7:\"excerpt\";s:154:\"A hassle-free Block-Editor-Era theme for your next WooCommerce project.

&nbsp;

Pre-sale questions? Ask Get Bowtied: http://m.me/getbowtied

&nbsp;\";s:4:\"link\";s:103:\"https://woocommerce.com/products/block-shop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:34:\"https://blockshop.wp-theme.design/\";s:5:\"price\";s:10:\"&#36;59.00\";s:4:\"hash\";s:36:\"21fa433c-6c31-4be7-83ab-8d2cc8986130\";s:4:\"slug\";s:10:\"block-shop\";s:2:\"id\";i:4660093;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"bistro\";a:11:{s:5:\"title\";s:6:\"Bistro\";s:5:\"image\";s:61:\"https://woocommerce.com/wp-content/uploads/2016/07/bistro.png\";s:7:\"excerpt\";s:174:\"Bistro is a Storefront child theme designed for stores selling organic goods and other consumables. It features a friendly and warm design that lends itself to this industry.\";s:4:\"link\";s:99:\"https://woocommerce.com/products/bistro/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:37:\"https://themes.woocommerce.com/bistro\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"58e753f91fddf40abe8ebe4486f8c378\";s:4:\"slug\";s:6:\"bistro\";s:2:\"id\";i:1822936;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:10:\"stationery\";a:11:{s:5:\"title\";s:10:\"Stationery\";s:5:\"image\";s:65:\"https://woocommerce.com/wp-content/uploads/2016/04/stationery.jpg\";s:7:\"excerpt\";s:186:\"Stationery is a Storefront child theme designed for stores selling office supplies and/or arts &amp; crafts. The design has subtle tactile decorations while also being clean and elegant.\";s:4:\"link\";s:103:\"https://woocommerce.com/products/stationery/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:42:\"https://themes.woocommerce.com/stationery/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"b939225b8b8ccdc7b14ffb6d7eab2ac2\";s:4:\"slug\";s:10:\"stationery\";s:2:\"id\";i:1629126;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"petshop\";a:11:{s:5:\"title\";s:7:\"Petshop\";s:5:\"image\";s:62:\"https://woocommerce.com/wp-content/uploads/2016/03/petshop.png\";s:7:\"excerpt\";s:181:\"Petshop is a Storefront child theme designed for stores selling products in the pet industry. The design is organic and friendly, featuring many details that point to pet ownership.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/petshop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://themes.woocommerce.com/petshop/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"8060743c9031974326850f539aba5196\";s:4:\"slug\";s:7:\"petshop\";s:2:\"id\";i:1587689;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:5:\"hotel\";a:11:{s:5:\"title\";s:5:\"Hotel\";s:5:\"image\";s:69:\"https://woocommerce.com/wp-content/uploads/2016/03/hotel-featured.jpg\";s:7:\"excerpt\";s:246:\"Hotel is designed for businesses selling time, services and accommodation, offering unique integration with WooCommerce Bookings and Accommodation Bookings. The design is bold yet simple, allowing your content and imagery to do all the talking.\";s:4:\"link\";s:98:\"https://woocommerce.com/products/hotel/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:37:\"https://themes.woocommerce.com/hotel/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"0b0df891aa46f289f4e49bae2389bb04\";s:4:\"slug\";s:5:\"hotel\";s:2:\"id\";i:1554532;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:8:\"bookshop\";a:11:{s:5:\"title\";s:8:\"Bookshop\";s:5:\"image\";s:63:\"https://woocommerce.com/wp-content/uploads/2016/02/featured.png\";s:7:\"excerpt\";s:183:\"Bookshop comes with a unique homepage layout that prominently displays product categories and a variety of products in an arrangement that is popular with bookstores and collectibles.\";s:4:\"link\";s:101:\"https://woocommerce.com/products/bookshop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:40:\"https://themes.woocommerce.com/bookshop/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"9fe861227e3e82fde8fe5d7e8cc3340e\";s:4:\"slug\";s:8:\"bookshop\";s:2:\"id\";i:1508713;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"arcade\";a:11:{s:5:\"title\";s:6:\"Arcade\";s:5:\"image\";s:61:\"https://woocommerce.com/wp-content/uploads/2016/01/arcade.png\";s:7:\"excerpt\";s:216:\"Upgrade your video game shops look and feel with Arcade. It\'s bold and modern design will engage visitors and the unique homepage layout will present them with a variety of products as soon as they hit your homepage.\";s:4:\"link\";s:99:\"https://woocommerce.com/products/arcade/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:38:\"https://themes.woocommerce.com/arcade/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"5af09d4e590eec977c6b9519b517f479\";s:4:\"slug\";s:6:\"arcade\";s:2:\"id\";i:1418260;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:9:\"homestore\";a:11:{s:5:\"title\";s:9:\"Homestore\";s:5:\"image\";s:64:\"https://woocommerce.com/wp-content/uploads/2015/12/homestore.jpg\";s:7:\"excerpt\";s:166:\"Give your Department Store a classic look with Homestore. Its clean and efficient design will work well whether you\'re a boutique independent or a high street giant.\";s:4:\"link\";s:102:\"https://woocommerce.com/products/homestore/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:41:\"https://themes.woocommerce.com/homestore/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"d79fe7a1beba26523aafa6ce6d3e1e85\";s:4:\"slug\";s:9:\"homestore\";s:2:\"id\";i:1365559;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:8:\"pharmacy\";a:11:{s:5:\"title\";s:8:\"Pharmacy\";s:5:\"image\";s:63:\"https://woocommerce.com/wp-content/uploads/2015/12/pharmacy.jpg\";s:7:\"excerpt\";s:235:\"Give your health store a professional, trust-worthy design with the Pharmacy Storefront Child Theme. Built upon our rock solid Storefront Parent theme you\'ll also enjoy reliable integration with current and future WooCommerce releases.\";s:4:\"link\";s:101:\"https://woocommerce.com/products/pharmacy/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:40:\"https://themes.woocommerce.com/pharmacy/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"ebeff3c0f89cd3169fb6b3e7e137e513\";s:4:\"slug\";s:8:\"pharmacy\";s:2:\"id\";i:1365557;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"toyshop\";a:11:{s:5:\"title\";s:7:\"ToyShop\";s:5:\"image\";s:62:\"https://woocommerce.com/wp-content/uploads/2015/09/toyshop.jpg\";s:7:\"excerpt\";s:269:\"Add some fun to your store with ToyShop. The engaging and colorful design of ToyShop makes it a perfect child theme or any store that sells exciting products that are aimed at customers that like to have fun. The outdoorsy style would even be perfect for a flower shop.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/toyshop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://themes.woocommerce.com/toyshop/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"3e2520021b41ee49a55b93362aaced98\";s:4:\"slug\";s:7:\"toyshop\";s:2:\"id\";i:1230716;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"outlet\";a:11:{s:5:\"title\";s:6:\"Outlet\";s:5:\"image\";s:61:\"https://woocommerce.com/wp-content/uploads/2015/09/outlet.jpg\";s:7:\"excerpt\";s:221:\"Overclock your tech store with Outlet! Whether you sell boutique iPad jewellery or the nuts and bolts of hardware itself, Outlet will give your shop a stylish look and feel while enjoying the stability of Storefront core.\";s:4:\"link\";s:99:\"https://woocommerce.com/products/outlet/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:38:\"https://themes.woocommerce.com/outlet/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"4c311cb3a3131570946b8799715a0991\";s:4:\"slug\";s:6:\"outlet\";s:2:\"id\";i:1212805;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"proshop\";a:11:{s:5:\"title\";s:7:\"ProShop\";s:5:\"image\";s:62:\"https://woocommerce.com/wp-content/uploads/2015/06/proshop.jpg\";s:7:\"excerpt\";s:176:\"Unlock the true potential of your sports clothing and equipment store with ProShop! It\'s metropolitan design provides an active aesthetic giving your store oodles of character.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/proshop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://themes.woocommerce.com/proshop/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"1d51b8633bbd1782dc17fce15f8bd2af\";s:4:\"slug\";s:7:\"proshop\";s:2:\"id\";i:1000757;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:8:\"galleria\";a:11:{s:5:\"title\";s:8:\"Galleria\";s:5:\"image\";s:68:\"https://woocommerce.com/wp-content/uploads/2015/05/galleria-hero.png\";s:7:\"excerpt\";s:162:\"Galleria is a Storefront child theme perfect for fashion and design stores. Stylish and minimalist, it gives sites a classy look and keeps products center stage.\";s:4:\"link\";s:101:\"https://woocommerce.com/products/galleria/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:40:\"https://themes.woocommerce.com/galleria/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"2429c1dde521031cd053886b15844bbf\";s:4:\"slug\";s:8:\"galleria\";s:2:\"id\";i:887931;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:4:\"deli\";a:11:{s:5:\"title\";s:4:\"Deli\";s:5:\"image\";s:59:\"https://woocommerce.com/wp-content/uploads/2015/03/deli.jpg\";s:7:\"excerpt\";s:135:\"Deli is a Storefront child theme featuring a texturised, earthy design, perfect for stores selling natural, organic or hand made goods.\";s:4:\"link\";s:97:\"https://woocommerce.com/products/deli/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:36:\"https://themes.woocommerce.com/deli/\";s:5:\"price\";s:9:\"&#36;0.00\";s:4:\"hash\";s:32:\"83c6db94c8ebf9da56b59fb97f724e88\";s:4:\"slug\";s:4:\"deli\";s:2:\"id\";i:784823;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:8:\"boutique\";a:11:{s:5:\"title\";s:8:\"Boutique\";s:5:\"image\";s:63:\"https://woocommerce.com/wp-content/uploads/2015/01/boutique.png\";s:7:\"excerpt\";s:168:\"Boutique is a simple, traditionally designed Storefront child theme, ideal for small stores or boutiques. Add your logo, create a unique color scheme and start selling!\";s:4:\"link\";s:101:\"https://woocommerce.com/products/boutique/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:40:\"https://themes.woocommerce.com/boutique/\";s:5:\"price\";s:9:\"&#36;0.00\";s:4:\"hash\";s:32:\"71815288e266d58031727d48d6deee25\";s:4:\"slug\";s:8:\"boutique\";s:2:\"id\";i:605777;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:14:\"twentynineteen\";a:6:{s:4:\"slug\";s:14:\"twentynineteen\";s:5:\"title\";s:15:\"Twenty Nineteen\";s:5:\"price\";s:4:\"0.00\";s:12:\"is_installed\";b:1;s:5:\"image\";s:64:\"http://mozar.loc/wp-content/themes/twentynineteen/screenshot.png\";s:23:\"has_woocommerce_support\";b:0;}s:15:\"twentyseventeen\";a:6:{s:4:\"slug\";s:15:\"twentyseventeen\";s:5:\"title\";s:16:\"Twenty Seventeen\";s:5:\"price\";s:4:\"0.00\";s:12:\"is_installed\";b:1;s:5:\"image\";s:65:\"http://mozar.loc/wp-content/themes/twentyseventeen/screenshot.png\";s:23:\"has_woocommerce_support\";b:0;}}","no");
INSERT INTO `wp_options` VALUES("357","_transient_timeout_wc_report_orders_stats_e475757f034ec6eaa7d0de0140bf23e3","1605123837","no");
INSERT INTO `wp_options` VALUES("358","_transient_timeout_wc_report_orders_stats_5ccac6263322a57f8c038f88a4f091ef","1605123837","no");
INSERT INTO `wp_options` VALUES("359","_transient_wc_report_orders_stats_e475757f034ec6eaa7d0de0140bf23e3","a:2:{s:7:\"version\";s:10:\"1604519030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2020-45\";s:10:\"date_start\";s:19:\"2020-11-03 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2020-11-02 21:00:00\";s:8:\"date_end\";s:19:\"2020-11-03 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2020-11-03 20:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no");
INSERT INTO `wp_options` VALUES("360","_transient_wc_report_orders_stats_5ccac6263322a57f8c038f88a4f091ef","a:2:{s:7:\"version\";s:10:\"1604519030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2020-45\";s:10:\"date_start\";s:19:\"2020-11-04 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2020-11-03 21:00:00\";s:8:\"date_end\";s:19:\"2020-11-04 22:43:00\";s:12:\"date_end_gmt\";s:19:\"2020-11-04 19:43:00\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no");
INSERT INTO `wp_options` VALUES("361","_transient_timeout_wc_report_orders_stats_42b887ecec945bdc9ce534d8566a786a","1605123837","no");
INSERT INTO `wp_options` VALUES("362","_transient_wc_report_orders_stats_42b887ecec945bdc9ce534d8566a786a","a:2:{s:7:\"version\";s:10:\"1604519030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2020-45\";s:10:\"date_start\";s:19:\"2020-11-03 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2020-11-02 21:00:00\";s:8:\"date_end\";s:19:\"2020-11-03 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2020-11-03 20:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no");
INSERT INTO `wp_options` VALUES("363","_transient_timeout_wc_report_orders_stats_39ec0b7fc38dea92d102f9c58e21c748","1605123837","no");
INSERT INTO `wp_options` VALUES("364","_transient_wc_report_orders_stats_39ec0b7fc38dea92d102f9c58e21c748","a:2:{s:7:\"version\";s:10:\"1604519030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2020-45\";s:10:\"date_start\";s:19:\"2020-11-04 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2020-11-03 21:00:00\";s:8:\"date_end\";s:19:\"2020-11-04 22:43:00\";s:12:\"date_end_gmt\";s:19:\"2020-11-04 19:43:00\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no");
INSERT INTO `wp_options` VALUES("366","_transient_timeout_wc_report_orders_stats_4e909c0a5ebc4236c73490a8fd11e12f","1605123856","no");
INSERT INTO `wp_options` VALUES("367","_transient_wc_report_orders_stats_4e909c0a5ebc4236c73490a8fd11e12f","a:2:{s:7:\"version\";s:10:\"1604519030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2020-45\";s:10:\"date_start\";s:19:\"2020-11-04 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2020-11-03 21:00:00\";s:8:\"date_end\";s:19:\"2020-11-04 22:44:00\";s:12:\"date_end_gmt\";s:19:\"2020-11-04 19:44:00\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no");
INSERT INTO `wp_options` VALUES("368","_transient_timeout_wc_report_orders_stats_b2a7fe5c96cd4e08e374bb38b9deb6a3","1605123856","no");
INSERT INTO `wp_options` VALUES("369","_transient_wc_report_orders_stats_b2a7fe5c96cd4e08e374bb38b9deb6a3","a:2:{s:7:\"version\";s:10:\"1604519030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2020-45\";s:10:\"date_start\";s:19:\"2020-11-04 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2020-11-03 21:00:00\";s:8:\"date_end\";s:19:\"2020-11-04 22:44:00\";s:12:\"date_end_gmt\";s:19:\"2020-11-04 19:44:00\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no");
INSERT INTO `wp_options` VALUES("371","woocommerce_onboarding_profile","a:1:{s:7:\"skipped\";b:1;}","yes");
INSERT INTO `wp_options` VALUES("372","woocommerce_task_list_welcome_modal_dismissed","yes","yes");
INSERT INTO `wp_options` VALUES("373","action_scheduler_migration_status","complete","yes");
INSERT INTO `wp_options` VALUES("384","wpseo","a:38:{s:8:\"tracking\";b:0;s:22:\"license_server_version\";b:0;s:15:\"ms_defaults_set\";b:0;s:40:\"ignore_search_engines_discouraged_notice\";b:0;s:19:\"indexing_first_time\";b:1;s:18:\"indexation_started\";b:0;s:15:\"indexing_reason\";s:13:\"first_install\";s:31:\"indexables_indexation_completed\";b:1;s:7:\"version\";s:6:\"15.2.1\";s:16:\"previous_version\";s:0:\"\";s:20:\"disableadvanced_meta\";b:1;s:30:\"enable_headless_rest_endpoints\";b:1;s:17:\"ryte_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1604519671;s:13:\"myyoast-oauth\";b:0;s:26:\"semrush_integration_active\";b:1;s:14:\"semrush_tokens\";a:0:{}s:20:\"semrush_country_code\";s:2:\"us\";s:19:\"permalink_structure\";s:0:\"\";s:8:\"home_url\";s:0:\"\";s:18:\"dynamic_permalinks\";b:0;s:21:\"custom_taxonomy_slugs\";a:0:{}s:29:\"enable_enhanced_slack_sharing\";b:1;s:25:\"zapier_integration_active\";b:1;}","yes");
INSERT INTO `wp_options` VALUES("385","yoast_migrations_free","a:1:{s:7:\"version\";s:6:\"15.2.1\";}","yes");
INSERT INTO `wp_options` VALUES("386","wpseo_titles","a:99:{s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:45:\"%%name%%, Автор в %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:64:\"Вы искали %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:57:\"Страница не найдена %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:84:\"Сообщение %%POSTLINK%% появились сначала на %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:54:\"Ошибка 404: страница не найдена\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:19:\"Архивы для\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:31:\"Главная страница\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:17:\"Вы искали\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:11:\"person_logo\";s:0:\"\";s:14:\"person_logo_id\";i:0;s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:15:\"company_logo_id\";i:0;s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:7:\"company\";s:25:\"company_or_person_user_id\";b:0;s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:21:\"schema-page-type-post\";s:7:\"WebPage\";s:24:\"schema-article-type-post\";s:7:\"Article\";s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";i:0;s:21:\"schema-page-type-page\";s:7:\"WebPage\";s:24:\"schema-article-type-page\";s:4:\"None\";s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";i:0;s:27:\"schema-page-type-attachment\";s:7:\"WebPage\";s:30:\"schema-article-type-attachment\";s:4:\"None\";s:13:\"title-product\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:16:\"metadesc-product\";s:0:\"\";s:15:\"noindex-product\";b:0;s:26:\"display-metabox-pt-product\";b:1;s:26:\"post_types-product-maintax\";i:0;s:24:\"schema-page-type-product\";s:7:\"WebPage\";s:27:\"schema-article-type-product\";s:4:\"None\";s:23:\"title-ptarchive-product\";s:54:\"Архив %%pt_plural%% %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-ptarchive-product\";s:0:\"\";s:25:\"bctitle-ptarchive-product\";s:0:\"\";s:25:\"noindex-ptarchive-product\";b:0;s:18:\"title-tax-category\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;s:21:\"title-tax-product_cat\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_cat\";s:0:\"\";s:31:\"display-metabox-tax-product_cat\";b:1;s:23:\"noindex-tax-product_cat\";b:0;s:29:\"taxonomy-product_cat-ptparent\";i:0;s:21:\"title-tax-product_tag\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_tag\";s:0:\"\";s:31:\"display-metabox-tax-product_tag\";b:1;s:23:\"noindex-tax-product_tag\";b:0;s:29:\"taxonomy-product_tag-ptparent\";i:0;s:32:\"title-tax-product_shipping_class\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:35:\"metadesc-tax-product_shipping_class\";s:0:\"\";s:42:\"display-metabox-tax-product_shipping_class\";b:1;s:34:\"noindex-tax-product_shipping_class\";b:0;s:40:\"taxonomy-product_shipping_class-ptparent\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("387","wpseo_social","a:19:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:13:\"wikipedia_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("388","wpseo_flush_rewrite","1","yes");
INSERT INTO `wp_options` VALUES("402","_transient_timeout_wpseo_total_unindexed_posts","1604606140","no");
INSERT INTO `wp_options` VALUES("403","_transient_wpseo_total_unindexed_posts","0","no");
INSERT INTO `wp_options` VALUES("404","_transient_timeout_wpseo_total_unindexed_terms","1604606140","no");
INSERT INTO `wp_options` VALUES("405","_transient_wpseo_total_unindexed_terms","0","no");
INSERT INTO `wp_options` VALUES("406","_transient_timeout_wpseo_total_unindexed_post_type_archives","1604606140","no");
INSERT INTO `wp_options` VALUES("407","_transient_wpseo_total_unindexed_post_type_archives","0","no");
INSERT INTO `wp_options` VALUES("408","_transient_timeout_wpseo_unindexed_post_link_count","1604606140","no");
INSERT INTO `wp_options` VALUES("409","_transient_wpseo_unindexed_post_link_count","0","no");
INSERT INTO `wp_options` VALUES("410","_transient_timeout_wpseo_unindexed_term_link_count","1604606140","no");
INSERT INTO `wp_options` VALUES("411","_transient_wpseo_unindexed_term_link_count","0","no");
INSERT INTO `wp_options` VALUES("414","_transient_timeout__woocommerce_helper_subscriptions","1604520800","no");
INSERT INTO `wp_options` VALUES("415","_transient__woocommerce_helper_subscriptions","a:0:{}","no");
INSERT INTO `wp_options` VALUES("416","_transient_timeout__woocommerce_helper_updates","1604563100","no");
INSERT INTO `wp_options` VALUES("417","_transient__woocommerce_helper_updates","a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1604519900;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}","no");
INSERT INTO `wp_options` VALUES("434","_transient_doing_cron","1604521990.9697151184082031250000","yes");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("3","5","_wp_attached_file","woocommerce-placeholder.png");
INSERT INTO `wp_postmeta` VALUES("4","5","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("5","1","_wp_old_slug","%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_posts` VALUES("1","1","2020-11-04 22:09:18","2020-11-04 19:09:18","<!-- wp:paragraph -->
<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>
<!-- /wp:paragraph -->","Привет, мир!","","publish","open","open","","privet-mir","","","2020-11-04 22:09:18","2020-11-04 19:09:18","","0","http://mozar.loc/?p=1","0","post","","1");
INSERT INTO `wp_posts` VALUES("2","1","2020-11-04 22:09:18","2020-11-04 19:09:18","<!-- wp:paragraph -->
<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...или так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>Перейдите <a href=\"http://mozar.loc/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>
<!-- /wp:paragraph -->","Пример страницы","","publish","closed","open","","sample-page","","","2020-11-04 22:09:18","2020-11-04 19:09:18","","0","http://mozar.loc/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("3","1","2020-11-04 22:09:18","2020-11-04 19:09:18","<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Наш адрес сайта: http://mozar.loc.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие персональные данные мы собираем и с какой целью</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Комментарии</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Медиафайлы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Формы контактов</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Куки</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Встраиваемое содержимое других вебсайтов</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Веб-аналитика</h3><!-- /wp:heading --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ваша контактная информация</h2><!-- /wp:heading --><!-- wp:heading --><h2>Дополнительная информация</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Как мы защищаем ваши данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие принимаются процедуры против взлома данных</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>От каких третьих сторон мы получаем данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Требования к раскрытию отраслевых нормативных требований</h3><!-- /wp:heading -->","Политика конфиденциальности","","draft","closed","open","","privacy-policy","","","2020-11-04 22:09:18","2020-11-04 19:09:18","","0","http://mozar.loc/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("4","1","2020-11-04 22:09:38","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2020-11-04 22:09:38","0000-00-00 00:00:00","","0","http://mozar.loc/?p=4","0","post","","0");
INSERT INTO `wp_posts` VALUES("5","1","2020-11-04 22:43:30","2020-11-04 19:43:30","","woocommerce-placeholder","","inherit","open","closed","","woocommerce-placeholder","","","2020-11-04 22:43:30","2020-11-04 19:43:30","","0","http://mozar.loc/wp-content/uploads/2020/11/woocommerce-placeholder.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("6","1","2020-11-04 22:43:37","2020-11-04 19:43:37","","Магазин","","publish","closed","closed","","shop","","","2020-11-04 22:43:37","2020-11-04 19:43:37","","0","http://mozar.loc/shop/","0","page","","0");
INSERT INTO `wp_posts` VALUES("7","1","2020-11-04 22:43:37","2020-11-04 19:43:37","<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->","Корзина","","publish","closed","closed","","cart","","","2020-11-04 22:43:37","2020-11-04 19:43:37","","0","http://mozar.loc/cart/","0","page","","0");
INSERT INTO `wp_posts` VALUES("8","1","2020-11-04 22:43:37","2020-11-04 19:43:37","<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->","Оформление заказа","","publish","closed","closed","","checkout","","","2020-11-04 22:43:37","2020-11-04 19:43:37","","0","http://mozar.loc/checkout/","0","page","","0");
INSERT INTO `wp_posts` VALUES("9","1","2020-11-04 22:43:38","2020-11-04 19:43:38","<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->","Мой аккаунт","","publish","closed","closed","","my-account","","","2020-11-04 22:43:38","2020-11-04 19:43:38","","0","http://mozar.loc/my-account/","0","page","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("3","3","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("4","4","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("5","5","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("6","6","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("7","7","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("8","8","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("9","9","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("10","10","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("11","11","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("12","12","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("13","13","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("14","14","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("15","15","product_cat","","0","0");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_terms` VALUES("1","Без рубрики","bez-rubriki","0");
INSERT INTO `wp_terms` VALUES("2","simple","simple","0");
INSERT INTO `wp_terms` VALUES("3","grouped","grouped","0");
INSERT INTO `wp_terms` VALUES("4","variable","variable","0");
INSERT INTO `wp_terms` VALUES("5","external","external","0");
INSERT INTO `wp_terms` VALUES("6","exclude-from-search","exclude-from-search","0");
INSERT INTO `wp_terms` VALUES("7","exclude-from-catalog","exclude-from-catalog","0");
INSERT INTO `wp_terms` VALUES("8","featured","featured","0");
INSERT INTO `wp_terms` VALUES("9","outofstock","outofstock","0");
INSERT INTO `wp_terms` VALUES("10","rated-1","rated-1","0");
INSERT INTO `wp_terms` VALUES("11","rated-2","rated-2","0");
INSERT INTO `wp_terms` VALUES("12","rated-3","rated-3","0");
INSERT INTO `wp_terms` VALUES("13","rated-4","rated-4","0");
INSERT INTO `wp_terms` VALUES("14","rated-5","rated-5","0");
INSERT INTO `wp_terms` VALUES("15","Uncategorized","uncategorized","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","admin");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("16","1","session_tokens","a:1:{s:64:\"e0b912db77c573c114f99f7e536f99dda1c9ad644d0e21ed11cb41e31c5f4d36\";a:4:{s:10:\"expiration\";i:1605726576;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:133:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36 OPR/72.0.3815.186\";s:5:\"login\";i:1604516976;}}");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","4");
INSERT INTO `wp_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `wp_usermeta` VALUES("19","1","_woocommerce_tracks_anon_id","woo:dK+GnzCAzXTq6fbqkgBgn9bV");
INSERT INTO `wp_usermeta` VALUES("20","1","last_update","1604519063");
INSERT INTO `wp_usermeta` VALUES("21","1","woocommerce_admin_activity_panel_inbox_last_read","1604519062407");
INSERT INTO `wp_usermeta` VALUES("22","1","wp_yoast_notifications","a:3:{i:0;a:2:{s:7:\"message\";O:61:\"Yoast\\WP\\SEO\\Presenters\\Admin\\Indexing_Notification_Presenter\":3:{s:18:\"\0*\0total_unindexed\";i:24;s:9:\"\0*\0reason\";s:13:\"first_install\";s:20:\"\0*\0short_link_helper\";O:38:\"Yoast\\WP\\SEO\\Helpers\\Short_Link_Helper\":2:{s:17:\"\0*\0options_helper\";O:35:\"Yoast\\WP\\SEO\\Helpers\\Options_Helper\":0:{}s:17:\"\0*\0product_helper\";O:35:\"Yoast\\WP\\SEO\\Helpers\\Product_Helper\":0:{}}}s:7:\"options\";a:10:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:13:\"wpseo-reindex\";s:4:\"user\";O:7:\"WP_User\":8:{s:4:\"data\";O:8:\"stdClass\":10:{s:2:\"ID\";s:1:\"1\";s:10:\"user_login\";s:5:\"admin\";s:9:\"user_pass\";s:34:\"$P$Bt5nUmid.gbFdVA46nwNHeUqkaK5j21\";s:13:\"user_nicename\";s:5:\"admin\";s:10:\"user_email\";s:20:\"dimisiusis@gmail.com\";s:8:\"user_url\";s:16:\"http://mozar.loc\";s:15:\"user_registered\";s:19:\"2020-11-04 19:09:17\";s:19:\"user_activation_key\";s:0:\"\";s:11:\"user_status\";s:1:\"0\";s:12:\"display_name\";s:5:\"admin\";}s:2:\"ID\";i:1;s:4:\"caps\";a:1:{s:13:\"administrator\";b:1;}s:7:\"cap_key\";s:15:\"wp_capabilities\";s:5:\"roles\";a:1:{i:0;s:13:\"administrator\";}s:7:\"allcaps\";a:116:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:20:\"wpseo_manage_options\";b:1;s:13:\"administrator\";b:1;}s:6:\"filter\";N;s:16:\"\0WP_User\0site_id\";i:1;}s:5:\"nonce\";N;s:8:\"priority\";d:0.8;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:1;a:2:{s:7:\"message\";s:403:\"<strong>Новое в Yoast SEO 15.2:</strong>You’re now able to optimize URLs for more visibility when shared on Slack! <a href=\"https://yoa.st/yoast15-2?php_version=7.3&#038;platform=wordpress&#038;platform_version=5.5.3&#038;software=free&#038;software_version=15.2.1&#038;days_active=0-1&#038;user_language=ru_RU\" target=\"_blank\">Читать полностью о версии 15.2 здесь</a>\";s:7:\"options\";a:10:{s:4:\"type\";s:7:\"updated\";s:2:\"id\";s:20:\"wpseo-plugin-updated\";s:4:\"user\";O:7:\"WP_User\":8:{s:4:\"data\";O:8:\"stdClass\":10:{s:2:\"ID\";s:1:\"1\";s:10:\"user_login\";s:5:\"admin\";s:9:\"user_pass\";s:34:\"$P$Bt5nUmid.gbFdVA46nwNHeUqkaK5j21\";s:13:\"user_nicename\";s:5:\"admin\";s:10:\"user_email\";s:20:\"dimisiusis@gmail.com\";s:8:\"user_url\";s:16:\"http://mozar.loc\";s:15:\"user_registered\";s:19:\"2020-11-04 19:09:17\";s:19:\"user_activation_key\";s:0:\"\";s:11:\"user_status\";s:1:\"0\";s:12:\"display_name\";s:5:\"admin\";}s:2:\"ID\";i:1;s:4:\"caps\";a:1:{s:13:\"administrator\";b:1;}s:7:\"cap_key\";s:15:\"wp_capabilities\";s:5:\"roles\";a:1:{i:0;s:13:\"administrator\";}s:7:\"allcaps\";a:116:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:20:\"wpseo_manage_options\";b:1;s:13:\"administrator\";b:1;}s:6:\"filter\";N;s:16:\"\0WP_User\0site_id\";i:1;}s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:1:{s:13:\"dismiss_value\";s:6:\"15.2.1\";}s:13:\"dismissal_key\";s:20:\"wpseo-plugin-updated\";s:12:\"capabilities\";a:1:{i:0;s:20:\"wpseo_manage_options\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:2;a:2:{s:7:\"message\";s:578:\"Yoast SEO и WooCommerce могут работать лучше, если вы добавите вспомогательный плагин. Пожалуйста, установите Yoast WooCommerce SEO, чтобы сделать вашу жизнь проще. <a href=\"https://yoa.st/1o0?php_version=7.3&platform=wordpress&platform_version=5.5.3&software=free&software_version=15.2.1&days_active=0-1&user_language=ru_RU\" aria-label=\"Больше информации о Yoast WooCommerce SEO\" target=\"_blank\" rel=\"noopener noreferrer\">Больше информации</a>.\";s:7:\"options\";a:10:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:44:\"wpseo-suggested-plugin-yoast-woocommerce-seo\";s:4:\"user\";r:161;s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:15:\"install_plugins\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_users` VALUES("1","admin","$P$Bt5nUmid.gbFdVA46nwNHeUqkaK5j21","admin","dimisiusis@gmail.com","http://mozar.loc","2020-11-04 19:09:17","","0","admin");


DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;

CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_wc_admin_note_actions` VALUES("1","1","connect","Подключить","?page=wc-addons&section=helper","unactioned","0","");
INSERT INTO `wp_wc_admin_note_actions` VALUES("2","2","continue-profiler","Продолжить настройку магазина","http://mozar.loc/wp-admin/admin.php?page=wc-admin&path=/setup-wizard","unactioned","1","");
INSERT INTO `wp_wc_admin_note_actions` VALUES("3","2","skip-profiler","Пропустить установку","http://mozar.loc/wp-admin/admin.php?page=wc-admin&reset_profiler=0","actioned","0","");
INSERT INTO `wp_wc_admin_note_actions` VALUES("4","3","yes-please","Да, пожалуйста!","https://woocommerce.us8.list-manage.com/subscribe/post?u=2c1434dc56f9506bf3c3ecd21&amp;id=13860df971&amp;SIGNUPPAGE=plugin","actioned","0","");
INSERT INTO `wp_wc_admin_note_actions` VALUES("5","4","open-marketing-hub","Открыть маркетинговый центр","http://mozar.loc/wp-admin/admin.php?page=wc-admin&path=/marketing","actioned","0","");
INSERT INTO `wp_wc_admin_note_actions` VALUES("15","5","set-up-concierge","Schedule free session","https://wordpress.com/me/concierge","actioned","1","");
INSERT INTO `wp_wc_admin_note_actions` VALUES("16","6","learn-more","Learn more","https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox","unactioned","1","");
INSERT INTO `wp_wc_admin_note_actions` VALUES("17","7","learn-more-ecomm-unique-shopping-experience","Learn more","https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox","actioned","1","");


DROP TABLE IF EXISTS `wp_wc_admin_notes`;

CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT 0,
  `layout` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_wc_admin_notes` VALUES("1","wc-admin-wc-helper-connection","info","en_US","Подключиться к WooCommerce.com","Подключайтесь, чтобы получать важные уведомления о продукте и обновления.","{}","unactioned","woocommerce-admin","2020-11-04 19:43:47","","0","plain","","0","info");
INSERT INTO `wp_wc_admin_notes` VALUES("2","wc-admin-onboarding-profiler-reminder","update","en_US","Добро пожаловать в WooCommerce! Настройте свой магазин и начните продавать","Мы поможем вам пройти самые важные этапы, чтобы ваш магазин заработал.","{}","unactioned","woocommerce-admin","2020-11-04 19:43:47","","0","plain","","0","info");
INSERT INTO `wp_wc_admin_notes` VALUES("3","wc-admin-onboarding-email-marketing","info","en_US","Советы, обновления продуктов и новые идеи","Мы готовы вам помочь — получайте советы, новости о продуктах и вдохновляющие идеи прямо на почту.","{}","unactioned","woocommerce-admin","2020-11-04 19:43:48","","0","plain","","0","info");
INSERT INTO `wp_wc_admin_notes` VALUES("4","wc-admin-marketing-intro","info","en_US","Найдите свою аудиторию","Расширяйте базу заказчиков и увеличивайте продажи с помощью маркетинговых инструментов для WooCommerce.","{}","unactioned","woocommerce-admin","2020-11-04 19:43:49","","0","plain","","0","info");
INSERT INTO `wp_wc_admin_notes` VALUES("5","ecomm-need-help-setting-up-your-store","info","en_US","Need help setting up your Store?","Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.","{}","pending","woocommerce.com","2020-11-04 10:43:49","","0","plain","","0","info");
INSERT INTO `wp_wc_admin_notes` VALUES("6","woocommerce-services","info","en_US","WooCommerce Shipping & Tax","WooCommerce Shipping &amp; Tax helps get your store “ready to sell” as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.","{}","pending","woocommerce.com","2020-11-04 10:43:49","","0","plain","","0","info");
INSERT INTO `wp_wc_admin_notes` VALUES("7","ecomm-unique-shopping-experience","info","en_US","For a shopping experience as unique as your customers","Product Add-Ons allow your customers to personalize products while they’re shopping on your online store. No more follow-up email requests—customers get what they want, before they’re done checking out. Learn more about this extension that comes included in your plan.","{}","pending","woocommerce.com","2020-11-04 10:43:50","","0","plain","","0","info");


DROP TABLE IF EXISTS `wp_wc_category_lookup`;

CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_wc_category_lookup` VALUES("15","15");


DROP TABLE IF EXISTS `wp_wc_customer_lookup`;

CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wc_download_log`;

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`),
  CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;

CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT 0,
  `product_gross_revenue` double NOT NULL DEFAULT 0,
  `coupon_amount` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double NOT NULL DEFAULT 0,
  `shipping_tax_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wc_order_stats`;

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT 0,
  `total_sales` double NOT NULL DEFAULT 0,
  `tax_total` double NOT NULL DEFAULT 0,
  `shipping_total` double NOT NULL DEFAULT 0,
  `net_total` double NOT NULL DEFAULT 0,
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;

CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT 0,
  `order_tax` double NOT NULL DEFAULT 0,
  `total_tax` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wc_reserved_stock`;

CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT 0,
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_wc_tax_rate_classes` VALUES("1","Пониженная ставка","%d0%bf%d0%be%d0%bd%d0%b8%d0%b6%d0%b5%d0%bd%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d0%b0%d0%b2%d0%ba%d0%b0");
INSERT INTO `wp_wc_tax_rate_classes` VALUES("2","Нулевая ставка","%d0%bd%d1%83%d0%bb%d0%b5%d0%b2%d0%b0%d1%8f-%d1%81%d1%82%d0%b0%d0%b2%d0%ba%d0%b0");


DROP TABLE IF EXISTS `wp_wc_webhooks`;

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT 0,
  `pending_delivery` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_log`;

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_items`;

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_sessions`;

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_woocommerce_sessions` VALUES("1","1","a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:734:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2020-11-04T19:44:23+00:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"GB\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"GB\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:20:\"dimisiusis@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}","1604691895");


DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT 0,
  `tax_rate_shipping` int(1) NOT NULL DEFAULT 1,
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_yoast_indexable`;

CREATE TABLE `wp_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permalink_hash` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object_id` int(11) unsigned DEFAULT NULL,
  `object_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_sub_type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` int(11) unsigned DEFAULT NULL,
  `post_parent` int(11) unsigned DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `breadcrumb_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT 0,
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary_focus_keyword` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT 0,
  `is_robots_noindex` tinyint(1) DEFAULT 0,
  `is_robots_nofollow` tinyint(1) DEFAULT 0,
  `is_robots_noarchive` tinyint(1) DEFAULT 0,
  `is_robots_noimageindex` tinyint(1) DEFAULT 0,
  `is_robots_nosnippet` tinyint(1) DEFAULT 0,
  `twitter_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image_source` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_image` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_image_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_image_source` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_image_meta` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  `language` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schema_page_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schema_article_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_yoast_indexable` VALUES("1","http://mozar.loc/author/admin/","30:99f0be3115fef0c9c667c2cd4953d821","1","user","","","","","","","","","0","0","","","","","","0","0","","","","","","https://0.gravatar.com/avatar/06674c6ccda0bc118340e7caeaa0e5a4?s=500&d=mm&r=g","","","gravatar-image","","","https://0.gravatar.com/avatar/06674c6ccda0bc118340e7caeaa0e5a4?s=500&d=mm&r=g","","gravatar-image","","","","","2020-11-04 19:54:35","2020-11-04 19:54:36","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("2","http://mozar.loc/wp-content/uploads/woocommerce-placeholder.png","63:4fd4d64ea726cf972263d525cd889e3f","5","post","attachment","1","0","","","woocommerce-placeholder","inherit","0","0","0","","","","","0","0","","0","","","","","http://mozar.loc/wp-content/uploads/woocommerce-placeholder.png","","5","attachment-image","","","http://mozar.loc/wp-content/uploads/woocommerce-placeholder.png","5","attachment-image","{\"width\":1200,\"height\":1200,\"url\":\"http://mozar.loc/wp-content/uploads/woocommerce-placeholder.png\",\"path\":\"F:\\\\OSPanel\\\\domains\\\\mozar.loc/wp-content/uploads/woocommerce-placeholder.png\",\"size\":\"full\",\"id\":5,\"alt\":\"\",\"pixels\":1440000,\"type\":\"image/png\"}","0","","","2020-11-04 19:54:35","2020-11-04 19:54:35","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("3","http://mozar.loc/?page_id=3","27:ec310ca87cb7c5e2556412d319f07f38","3","post","page","1","0","","","Политика конфиденциальности","draft","0","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2020-11-04 19:54:35","2020-11-04 19:54:35","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("4","http://mozar.loc/sample-page/","29:13f8109f5bb5d4361f7dfc2a3545e936","2","post","page","1","0","","","Пример страницы","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","1","","","2020-11-04 19:54:35","2020-11-04 19:54:35","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("5","http://mozar.loc/shop/","22:d9c9abf5ac22d494ada46eaec6267d44","6","post","page","1","0","","","Магазин","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2020-11-04 19:54:35","2020-11-04 19:54:35","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("6","http://mozar.loc/cart/","22:89a5df4f51c77c4649cc0fc0f786aaf6","7","post","page","1","0","","","Корзина","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2020-11-04 19:54:35","2020-11-04 19:54:35","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("7","http://mozar.loc/checkout/","26:7f3e280f40c59e9ac1cb39214e38d3b8","8","post","page","1","0","","","Оформление заказа","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2020-11-04 19:54:35","2020-11-04 19:54:35","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("8","http://mozar.loc/my-account/","28:b2a972dae20759a83e9f8380dc51f009","9","post","page","1","0","","","Мой аккаунт","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2020-11-04 19:54:35","2020-11-04 19:54:36","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("9","http://mozar.loc/?p=4","21:5bac8123116ca7de6a394093dacabe51","4","post","post","1","0","","","Черновик","auto-draft","0","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2020-11-04 19:54:36","2020-11-04 19:54:36","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("10","http://mozar.loc/2020/11/04/privet-mir/","39:59ffa5cf1fe5ade2431f0ddb02142d26","1","post","post","1","0","","","Привет, мир!","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2020-11-04 19:54:36","2020-11-04 19:54:36","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("11","http://mozar.loc/category/bez-rubriki/","38:39b0fbc5251927e541fa35c0f58a5e80","1","term","category","","","","","Без рубрики","","","0","","","","","","","0","","","","","","","","","","","","","","","","","0","","","2020-11-04 19:54:36","2020-11-04 19:54:37","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("12","http://mozar.loc/product-category/uncategorized/","48:a61fabc90680a204c1f9e383152b200a","15","term","product_cat","","","","","Uncategorized","","","0","","","","","","","0","","","","","","","","","","","","","","","","","0","","","2020-11-04 19:54:36","2020-11-04 19:54:37","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("13","","","","system-page","404","","","Страница не найдена %%sep%% %%sitename%%","","Ошибка 404: страница не найдена","","","0","","","","","","","0","1","0","0","0","0","","","","","","","","","","","","","","","2020-11-04 19:54:36","2020-11-04 19:54:36","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("14","","","","system-page","search-result","","","Вы искали %%searchphrase%% %%page%% %%sep%% %%sitename%%","","","","","0","","","","","","","0","1","0","0","0","0","","","","","","","","","","","","","","","2020-11-04 19:54:36","2020-11-04 19:54:36","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("15","","","","date-archive","","","","%%date%% %%page%% %%sep%% %%sitename%%","","","","0","0","","","","","","","0","1","0","0","0","0","","","","","","","","","","","","","","","2020-11-04 19:54:36","2020-11-04 19:54:36","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("16","http://mozar.loc/","17:6879f877f9f87a999165dbe201e31ff7","","home-page","","","","%%sitename%% %%page%% %%sep%% %%sitedesc%%","Ещё один сайт на WordPress","Главная страница","","","0","","","","","","","0","0","0","0","0","0","","","","","","","","","","","","","","","2020-11-04 19:54:36","2020-11-04 19:54:36","1","","","","","0");
INSERT INTO `wp_yoast_indexable` VALUES("17","http://mozar.loc/shop/","22:d9c9abf5ac22d494ada46eaec6267d44","","post-type-archive","product","","","Архив %%pt_plural%% %%page%% %%sep%% %%sitename%%","","Товары","","1","0","","","","","","","0","0","0","0","0","0","","","","","","","","","","","","","","","2020-11-04 19:54:36","2020-11-04 19:54:36","1","","","","","0");


DROP TABLE IF EXISTS `wp_yoast_indexable_hierarchy`;

CREATE TABLE `wp_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_yoast_migrations`;

CREATE TABLE `wp_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wp_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_yoast_migrations` VALUES("1","20171228151840");
INSERT INTO `wp_yoast_migrations` VALUES("2","20171228151841");
INSERT INTO `wp_yoast_migrations` VALUES("3","20190529075038");
INSERT INTO `wp_yoast_migrations` VALUES("4","20191011111109");
INSERT INTO `wp_yoast_migrations` VALUES("5","20200408101900");
INSERT INTO `wp_yoast_migrations` VALUES("6","20200420073606");
INSERT INTO `wp_yoast_migrations` VALUES("7","20200428123747");
INSERT INTO `wp_yoast_migrations` VALUES("8","20200428194858");
INSERT INTO `wp_yoast_migrations` VALUES("9","20200429105310");
INSERT INTO `wp_yoast_migrations` VALUES("10","20200430075614");
INSERT INTO `wp_yoast_migrations` VALUES("11","20200430150130");
INSERT INTO `wp_yoast_migrations` VALUES("12","20200507054848");
INSERT INTO `wp_yoast_migrations` VALUES("13","20200513133401");
INSERT INTO `wp_yoast_migrations` VALUES("14","20200609154515");
INSERT INTO `wp_yoast_migrations` VALUES("15","20200616130143");
INSERT INTO `wp_yoast_migrations` VALUES("16","20200617122511");
INSERT INTO `wp_yoast_migrations` VALUES("17","20200702141921");
INSERT INTO `wp_yoast_migrations` VALUES("18","20200728095334");


DROP TABLE IF EXISTS `wp_yoast_primary_term`;

CREATE TABLE `wp_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(11) unsigned NOT NULL,
  `term_id` int(11) unsigned NOT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_yoast_seo_links`;

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `wp_yoast_seo_links` VALUES("1","http://mozar.loc/wp-admin/","2","","internal","4","","","","","","");


